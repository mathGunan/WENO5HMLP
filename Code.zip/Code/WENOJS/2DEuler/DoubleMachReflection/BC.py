import numpy as np


def apply_DMR_bc(U_phys, x_coords_in, t, gamma=1.4, nghost=3):
    """
    专门为双马赫反射 (DMR) 问题定制的边界条件填充函数。
    【标准规范】：接收未拓展的物理内场守恒变量 U_phys，并在函数内部自动创建并填充包含幽灵层的拓展数组 U_ext。

    参数:
        U_phys       : ndarray, shape (4, Ny, Nx) -> 纯物理内场（未拓展）的守恒变量数组
        x_coords_in  : ndarray, shape (Nx,) -> 纯物理内场（未拓展）的中心点 X 方向空间坐标
        t            : float -> 当前绝对物理时间 (t >= 0)
        gamma        : 比热比，默认 1.4
        nghost       : 需要向外拓展的幽灵层厚度 (默认为 3，完美匹配五阶格式)

    返回:
        U_ext        : ndarray, shape (4, Ny + 2*nghost, Nx + 2*nghost) -> 拓展并填充完毕的完全体守恒变量
        x_coords_ext : ndarray, shape (Nx + 2*nghost,) -> 拓展后的全场 X 坐标（包含左右幽灵层）
    """
    n_vars, Ny, Nx = U_phys.shape
    assert n_vars == 4, "2D Euler 应包含 4 个守恒变量"

    # =========================================================================
    # 1. 在函数内部自动构建全场（包含幽灵层）的网格尺寸与空间坐标
    # =========================================================================
    Ny_ext = Ny + 2 * nghost
    Nx_ext = Nx + 2 * nghost

    # 根据内场的 X 坐标以及网格间距，向左右两边外推幽灵层的物理坐标
    dx = x_coords_in[1] - x_coords_in[0] if Nx > 1 else 1.0 / Nx
    x_left_ghost = [x_coords_in[0] - (nghost - i) * dx for i in range(nghost)]
    x_right_ghost = [x_coords_in[-1] + (i + 1) * dx for i in range(nghost)]
    x_coords_ext = np.concatenate([x_left_ghost, x_coords_in, x_right_ghost])

    # 申请全场拓展数组的内存空间
    U_ext = np.zeros((4, Ny_ext, Nx_ext))

    # 【核心对齐】：将您的 U_phys 精准地拷贝到拓展全场数组的中心“内场区”
    U_ext[:, nghost:nghost + Ny, nghost:nghost + Nx] = U_phys

    # =========================================================================
    # 2. 定义双马赫反射的标准解析物理状态 (马赫数 Ms = 10, 激波倾角 60 度)
    # =========================================================================
    # 状态 L (激波后方高压强间断状态 - Shocked State)
    rho_L = 8.0
    u_L = 8.25 * np.sqrt(3.0) / 2.0  # 约 7.1447
    v_L = -8.25 * 0.5  # -4.125
    p_L = 116.5
    E_L = p_L / (gamma - 1.0) + 0.5 * rho_L * (u_L ** 2 + v_L ** 2)
    U_L = np.array([rho_L, rho_L * u_L, rho_L * v_L, E_L])

    # 状态 R (激波前方静止未扰动状态 - Unshocked State)
    rho_R = 1.4
    u_R = 0.0
    v_R = 0.0
    p_R = 1.0
    E_R = p_R / (gamma - 1.0) + 0.5 * rho_R * (u_R ** 2 + v_R ** 2)
    U_R = np.array([rho_R, rho_R * u_R, rho_R * v_R, E_R])

    # =========================================================================
    # 3. 左边界 (x = 0) 填充 -> 严格的完全流入条件 (常驻状态 L)
    # =========================================================================
    for i in range(nghost):
        U_ext[:, :, i] = U_L[:, np.newaxis]

    # =========================================================================
    # 4. 右边界 (x = 4.0) 填充 -> 完全流出条件 (Outflow / 零梯度连续外推)
    # =========================================================================
    for i in range(nghost):
        # 幽灵层逐层向外复制内场最边缘边界单元的值
        U_ext[:, :, Nx_ext - nghost + i] = U_ext[:, :, Nx_ext - nghost - 1]

    # =========================================================================
    # 5. 下边界 (y = 0) 填充 -> 分段固壁反射与高压流入
    # =========================================================================
    # 先执行全下边界的理想滑移固壁反射 (关于第一层内场格心的对称/反称映射)
    for j in range(nghost):
        jj_ghost = nghost - 1 - j
        jj_internal = nghost + j

        U_ext[0, jj_ghost, :] = U_ext[0, jj_internal, :]  # 密度对称
        U_ext[1, jj_ghost, :] = U_ext[1, jj_internal, :]  # x动量对称
        U_ext[2, jj_ghost, :] = -U_ext[2, jj_internal, :]  # y动量反称 (确保固壁处 v=0)
        U_ext[3, jj_ghost, :] = U_ext[3, jj_internal, :]  # 总能对称

    # 特殊修饰：在下边界 x < 1/6 的流入区间，强行覆写为全场状态 L
    is_left_of_wall = x_coords_ext < (1.0 / 6.0)
    for j in range(nghost):
        jj_ghost = nghost - 1 - j
        U_ext[:, jj_ghost, is_left_of_wall] = U_L[:, np.newaxis]

    # =========================================================================
    # 6. 上边界 (y = 1.0) 填充 -> 动态时空解析激波精确跟踪条件
    # =========================================================================
    # 激波前沿扫过上边界（y=1.0）的实时 X 坐标交界截断点：
    x_front = (1.0 / 6.0) + (1.0 / np.sqrt(3.0)) + (20.0 / np.sqrt(3.0)) * t

    # 动态判定当前全场哪些 X 坐标在激波前，哪些在激波后
    is_shocked_top = x_coords_ext < x_front

    for j in range(nghost):
        jj_ghost = Ny_ext - nghost + j
        # 激波左侧（击波后）：填入强状态 L
        U_ext[:, jj_ghost, is_shocked_top] = U_L[:, np.newaxis]
        # 激波右侧（击波前）：填入未扰动状态 R
        U_ext[:, jj_ghost, ~is_shocked_top] = U_R[:, np.newaxis]

    # =========================================================================
    # 7. 全局边界底层物理防御（最后一道物理锁，强切变处防爆专用）
    # =========================================================================
    U_ext[0] = np.maximum(U_ext[0], 1e-10)
    p_ext = (gamma - 1.0) * (U_ext[3] - 0.5 * (U_ext[1] ** 2 + U_ext[2] ** 2) / U_ext[0])
    if np.any(p_ext < 1e-10):
        p_safe = np.maximum(p_ext, 1e-10)
        U_ext[3] = p_safe / (gamma - 1.0) + 0.5 * (U_ext[1] ** 2 + U_ext[2] ** 2) / U_ext[0]

    return U_ext, x_coords_ext