import csv
import time
import numpy as np
import torch
from RK3 import SolverWeno5Rk3_MLP  # 严格导入已对齐新版接口的推进器
from IC import double_mach_IC  # 显式导入矩阵化加速后的初始条件
from BC import apply_DMR_bc  # 严格导入内部完成构建、全新加固的边界函数
from model import *
from helperfunction import *

gamma = 1.4


def compute_single_run(Nx, Ny, model, device, T_final=0.2):
    """
    单次网格规模的 WENO5-MLP 神经网络版 Double Mach Reflection 问题计算算子（规范化接口与防爆版）
    """
    nx = Nx
    ny = Ny
    Lx = 4.0
    Ly = 1.0
    dx = Lx / nx
    dy = Ly / ny
    epsilon = 1e-6  # WENO5 非线性权重防溢出的平滑小量

    # 1. 提取纯物理内场的一维坐标轴（新版 apply_DMR_bc 边界拓展所需）
    x_axis_in = np.linspace(dx / 2, 4.0 - dx / 2, nx)
    y_axis_in = np.linspace(dy / 2, 1.0 - dy / 2, ny)

    # 2. 生成二维网格中心坐标（indexing='xy' 产出形状 (ny, nx)）
    Xc, Yc = np.meshgrid(x_axis_in, y_axis_in, indexing='xy')

    # 3. 初始条件 (双马赫反射高精细未扰动流场初始化)
    U = double_mach_IC(Xc, Yc)  # shape (4, ny, nx)

    # 时间推进初始化
    t = 0.0
    iteration = 0
    start_time = time.time()

    # 冻结 PyTorch 梯度引擎，加速特征推理与 troubled-point 判定过程
    with torch.no_grad():
        while t < T_final:
            # 【严格保持您的逻辑】：计算时间步长前，先利用新版边界函数扩展数组
            # 内部自动创建拓展内存、映射内场、精准跟踪 t 时刻的上边界激波
            U_extended, _ = apply_DMR_bc(U_phys=U, x_coords_in=x_axis_in, t=t, gamma=gamma, nghost=3)

            # 利用完全体扩展数组计算当前步的安全时步 dt
            dt = compute_time_step(U_extended, dx, dy)

            if t + dt > T_final:
                dt = T_final - t

            # 【标准挂载】：调用已经对齐时间子步、无多余嵌套的新版显式 TVD-RK3 求解器
            # 内部在每个 Runge-Kutta 子步都会自动调用 apply_DMR_bc 更新对应的动态边界
            U = SolverWeno5Rk3_MLP(
                U_phys=U,
                x_coords_in=x_axis_in,
                dx=dx,
                dy=dy,
                dt=dt,
                model=model,
                device=device,
                gamma=gamma,
                Nx=Nx,
                Ny=Ny,
                t=t,
                threshold=0.5,  # troubled-point 判定阈值锁死，绝对不动
                nghost=3,
                epsilon=epsilon
            )
            t += dt
            iteration += 1

            # 每 50 步清爽输出进度并打印流场密度极值，便于监控发散趋势
            if iteration % 50 == 0 or t >= T_final:
                progress = (t / T_final) * 100
                min_rho = np.min(U[0])
                max_rho = np.max(U[0])
                print(f"[MLP] 网格规模 {Nx}x{Ny}: 进度 {progress:.1f}%, 迭代步数 {iteration}, "
                      f"物理时间 t={t:.4f}, 密度区间: [{min_rho:.4f}, {max_rho:.4f}]")

                # 实施底层安全熔断
                if np.isnan(min_rho):
                    print("❌ 检测到流场发散 (NaN)！熔断程序以保护计算资源。")
                    break

    cpu_time = time.time() - start_time
    print(f"WENO5-MLP 双马赫反射计算完成，总耗时: {cpu_time:.4f} 秒，总迭代次数: {iteration}")

    return Xc, Yc, U, cpu_time


def main():
    print("====================================================")
    print("  开启 2D Euler (WENO5-MLP + Roe) 双马赫反射模拟  ")
    print("====================================================")

    # 全局只加载一次神经网络模型与硬件后端
    model, device = get_model()
    model.eval()  # 显式切换为评估模式，冻结网络内部 Batch Normalization 或 Dropout 层行为
    print(f"当前计算后端硬件映射为: {device}")

    # 保持网格分辨率完全对齐 (4:1 标准长宽比)
    Nx = 240
    Ny = 60
    T_final = 0.2

    # 执行仿真计算（透传模型引用与底层后端）
    Xc, Yc, U_final, cpu_time = compute_single_run(Nx, Ny, model, device, T_final=T_final)

    # 提取最后时刻的 4 个完整守恒量分量
    rho_num = U_final[0, :, :]
    rhou_num = U_final[1, :, :]
    rhov_num = U_final[2, :, :]
    E_num = U_final[3, :, :]

    # 将二维流场展平为一维列以供高效保存
    x_flat = Xc.flatten()
    y_flat = Yc.flatten()
    rho_flat = rho_num.flatten()
    rhou_flat = rhou_num.flatten()
    rhov_flat = rhov_num.flatten()
    E_flat = E_num.flatten()

    # 规范化 CSV 物理命名
    csv_filename = f"Weno5MLP_DoubleMach_{Nx}x{Ny}_results.csv"

    with open(csv_filename, mode='w', newline='', encoding='utf-8') as f:
        writer = csv.writer(f)

        # 1. 写入全局 CPU 时间元数据（用于在论文中分析混合格式的高效性能）
        writer.writerow(["# Global Metadata", f"Total_CPU_Time_Seconds: {cpu_time:.6f}"])

        # 2. 写入守恒量列标题
        writer.writerow(["X", "Y", "Density(rho)", "Momentum_X(rho_u)", "Momentum_Y(rho_v)", "Energy(E)"])

        # 3. 逐行批量保存
        for i in range(len(x_flat)):
            writer.writerow([
                f"{x_flat[i]:.6e}",
                f"{y_flat[i]:.6e}",
                f"{rho_flat[i]:.6e}",
                f"{rhou_flat[i]:.6e}",
                f"{rhov_flat[i]:.6e}",
                f"{E_flat[i]:.6e}"
            ])

    print("----------------------------------------------------")
    print(f"WENO5-MLP 双马赫反射流场数据保存完毕。最终 CSV 文件路径: {csv_filename}")
    print("====================================================")


if __name__ == "__main__":
    main()