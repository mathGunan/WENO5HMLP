import csv
import time
import numpy as np
from RK3 import SolverWeno5Rk3  # 严格导入已对齐新版接口的纯 WENO5 推进器
from IC import double_mach_IC  # 显式导入高性能矩阵化初始条件
from BC import apply_DMR_bc  # 严格导入内部完成构建、全新加固的边界函数
from helperfunction import *

gamma = 1.4


def compute_single_run(Nx, Ny, T_final=0.2):
    """
    单次网格规模的纯五阶 WENO5 基准 Double Mach Reflection 问题计算算子
    """
    nx = Nx
    ny = Ny
    Lx = 4.0
    Ly = 1.0
    dx = Lx / nx
    dy = Ly / ny
    epsilon = 1e-6  # WENO5 非线性权重防溢出的平滑小量

    # 1. 提取纯物理内场的一维坐标轴（新版 apply_DMR_bc 边界拓展与坐标对齐所需）
    x_axis_in = np.linspace(dx / 2, 4.0 - dx / 2, nx)
    y_axis_in = np.linspace(dy / 2, 1.0 - dy / 2, ny)

    # 2. 生成二维网格中心坐标（indexing='xy' 产出形状 (ny, nx)）
    Xc, Yc = np.meshgrid(x_axis_in, y_axis_in, indexing='xy')

    # 3. 初始条件 (根据双马赫反射区域进行未扰动场初始化)
    U = double_mach_IC(Xc, Yc)  # shape (4, ny, nx)

    # 时间推进
    t = 0.0
    iteration = 0
    start_time = time.time()

    while t < T_final:
        # 【严格保持您的逻辑】：计算时间步长前，先利用新版边界函数扩展数组
        # 内部自动创建拓展内存、映射内场、精准跟踪 t 时刻的上边界动态激波
        U_extended, _ = apply_DMR_bc(U_phys=U, x_coords_in=x_axis_in, t=t, gamma=gamma, nghost=3)

        # 利用完全体扩展数组计算当前步的安全时步 dt
        dt = compute_time_step(U_extended, dx, dy)

        if t + dt > T_final:
            dt = T_final - t

        # 【标准挂载】：调用已经对齐时间子步、无多余嵌套的新版纯五阶 WENO5 + Roe 推进器
        # 内部在每个 Runge-Kutta 子步都会自动调用 apply_DMR_bc 更新对应的动态边界
        U = SolverWeno5Rk3(
            U_phys=U,
            x_coords_in=x_axis_in,
            dx=dx,
            dy=dy,
            dt=dt,
            gamma=gamma,
            Nx=Nx,
            Ny=Ny,
            t=t,
            nghost=3,
            epsilon=epsilon
        )
        t += dt
        iteration += 1

        # 仅在每 50 步迭代时执行一次高效的进度输出，并打印流场密度极值监控趋势
        if iteration % 50 == 0 or t >= T_final:
            progress = (t / T_final) * 100
            min_rho = np.min(U[0])
            max_rho = np.max(U[0])
            print(f"[Pure WENO5] 网格规模 {Nx}x{Ny}: 进度 {progress:.1f}%, 迭代步数 {iteration}, "
                  f"物理时间 t={t:.4f}, 密度区间: [{min_rho:.4f}, {max_rho:.4f}]")

            # 实施底层安全熔断
            if np.isnan(min_rho):
                print("❌ 检测到流场发散 (NaN)！熔断程序以保护计算资源。")
                break

    cpu_time = time.time() - start_time
    print(f"纯 WENO5 双马赫反射计算完成，总耗时: {cpu_time:.4f} 秒，总迭代次数: {iteration}")

    return Xc, Yc, U, cpu_time


def main():
    print("====================================================")
    print("  开启 2D Euler (Pure WENO5 + Roe) 双马赫反射基准计算  ")
    print("====================================================")

    # 保持网格分辨率完全对齐 (4:1 标准长宽比)
    # 论文最终大网格可切换至 480x120 或 960x240 进行精细计算
    Nx = 480
    Ny = 120
    T_final = 0.2

    # 执行仿真计算
    Xc, Yc, U_final, cpu_time = compute_single_run(Nx, Ny, T_final=T_final)

    # 提取最后时刻的 4 个完整守恒量分量
    rho_num = U_final[0, :, :]
    rhou_num = U_final[1, :, :]
    rhov_num = U_final[2, :, :]
    E_num = U_final[3, :, :]

    # 将二维空间网格及流场展平为一维列，以便标准 CSV 表格化存储
    x_flat = Xc.flatten()
    y_flat = Yc.flatten()
    rho_flat = rho_num.flatten()
    rhou_flat = rhou_num.flatten()
    rhov_flat = rhov_num.flatten()
    E_flat = E_num.flatten()

    # 规范化 CSV 命名，清晰标记为 PureWENO5 算法和 DoubleMach 问题
    csv_filename = f"PureWENO5_DoubleMach_{Nx}x{Ny}_results.csv"

    with open(csv_filename, mode='w', newline='', encoding='utf-8') as f:
        writer = csv.writer(f)

        # 1. 在 CSV 头部前两行写入全局元数据（保留总 CPU 时间以供后续效率对比）
        writer.writerow(["# Global Metadata", f"Total_CPU_Time_Seconds: {cpu_time:.6f}"])

        # 2. 写入标准的【守恒量】列标题
        writer.writerow(["X", "Y", "Density(rho)", "Momentum_X(rho_u)", "Momentum_Y(rho_v)", "Energy(E)"])

        # 3. 逐行写入流场各网格点上的位置与守恒量分量
        for i in range(len(x_flat)):
            writer.writerow([
                f"{x_flat[i]:.6e}",
                f"{y_flat[i]:.6e}",
                f"{rho_flat[i]:.6e}",
                f"{rhou_flat[i]:.6e}",
                f"{rhov_flat[i]:.6e}",
                f"{E_flat[i]:.6e}"
            ])

    print("----------------------------------------------------")
    print(f"纯 WENO5 双马赫反射基准流场数据保存完毕。最终 CSV 文件路径: {csv_filename}")
    print("====================================================")


if __name__ == "__main__":
    main()