import numpy as np
from ROEFLUX import compute_rhs_pure_weno5, compute_rhs_KXRCF, compute_rhs_2d_with_MLP
from BC import  *


def SolverWeno5Rk3(U_phys, x_coords_in, dx, dy, dt, gamma, Nx, Ny, t, nghost=3, epsilon=1e-6):
    """
    纯五阶 WENO5 + Roe 格式的全局三步 TVD-Runge-Kutta 时间推进器（双马赫反射特化版）。
    【标准规范】：严格对齐 U_phys 输入规范以及新版 apply_DMR_bc 边界函数。
    """
    # =========================================================================
    # === Stage 1 (t_stage = t) ===
    # =========================================================================
    # 1. 传入纯物理内场 U_phys，动态构建完全体的 U_ext
    U_ext, _ = apply_DMR_bc(U_phys, x_coords_in=x_coords_in, t=t, gamma=gamma, nghost=nghost)

    # 2. 计算纯 WENO5 的右端项残差，输出尺寸为纯内场 -> (4, Ny, Nx)
    rhs1 = compute_rhs_pure_weno5(
        U_ext=U_ext,
        dx=dx,
        dy=dy,
        gamma=gamma,
        nghost=nghost,
        epsilon=epsilon
    )
    # 3. 显式 Euler 前进更新
    U1 = U_phys + dt * rhs1

    # =========================================================================
    # === Stage 2 (t_stage = t + dt) ===
    # =========================================================================
    # 1. 传入中间物理态 U1，更新 t + dt 时刻的幽灵层边界
    U1_ext, _ = apply_DMR_bc(U1, x_coords_in=x_coords_in, t=t + dt, gamma=gamma, nghost=nghost)

    # 2. 计算 Stage 2 的右端项
    rhs2 = compute_rhs_pure_weno5(
        U_ext=U1_ext,
        dx=dx,
        dy=dy,
        gamma=gamma,
        nghost=nghost,
        epsilon=epsilon
    )
    # 3. 严格对齐 TVD-RK3 格式展开式
    U2 = 0.75 * U_phys + 0.25 * U1 + 0.25 * dt * rhs2

    # =========================================================================
    # === Stage 3 (t_stage = t + 0.5 * dt) ===
    # =========================================================================
    # 1. 传入中间物理态 U2，更新 t + 0.5*dt 核心半步时刻的幽灵层边界
    U2_ext, _ = apply_DMR_bc(U2, x_coords_in=x_coords_in, t=t + 0.5 * dt, gamma=gamma, nghost=nghost)

    # 2. 计算 Stage 3 的右端项
    rhs3 = compute_rhs_pure_weno5(
        U_ext=U2_ext,
        dx=dx,
        dy=dy,
        gamma=gamma,
        nghost=nghost,
        epsilon=epsilon
    )
    # 3. 计算最终完全步时刻的全新物理场内场 U_next
    U_next = (1.0 / 3.0) * U_phys + (2.0 / 3.0) * U2 + (2.0 / 3.0) * dt * rhs3

    return U_next


def SolverKXRCFRk3(U_phys, x_coords_in, dx, dy, dt, gamma, Nx, Ny, t, threshold=1.0, nghost=3, epsilon=1e-6):
    """
    二维 Euler 方程三阶 TVD-Runge-Kutta 时间推进器（双马赫反射 KXRCF 比熵判定版）。
    【标准规范】：严格对齐 U_phys 输入规范以及新版 apply_DMR_bc 边界函数。
    """
    # =========================================================================
    # === Stage 1 (t_stage = t) ===
    # =========================================================================
    # 1. 传入纯物理内场 U_phys，动态构建完全体的 U_ext
    U_ext, _ = apply_DMR_bc(U_phys, x_coords_in=x_coords_in, t=t, gamma=gamma, nghost=nghost)

    # 2. 计算 KXRCF 判定下的右端项残差，输出尺寸为纯内场 -> (4, Ny, Nx)
    rhs1 = compute_rhs_KXRCF(
        U_ext, dx, dy, gamma=gamma, threshold=threshold, nghost=nghost, epsilon=epsilon
    )
    # 3. 显式 Euler 前进更新
    U1 = U_phys + dt * rhs1

    # =========================================================================
    # === Stage 2 (t_stage = t + dt) ===
    # =========================================================================
    # 1. 传入中间物理态 U1，更新 t + dt 时刻的幽灵层边界
    U1_ext, _ = apply_DMR_bc(U1, x_coords_in=x_coords_in, t=t + dt, gamma=gamma, nghost=nghost)

    # 2. 计算 Stage 2 的右端项
    rhs2 = compute_rhs_KXRCF(
        U1_ext, dx, dy, gamma=gamma, threshold=threshold, nghost=nghost, epsilon=epsilon
    )
    # 3. 严格对齐 TVD-RK3 格式展开式
    U2 = 0.75 * U_phys + 0.25 * U1 + 0.25 * dt * rhs2

    # =========================================================================
    # === Stage 3 (t_stage = t + 0.5 * dt) ===
    # =========================================================================
    # 1. 传入中间物理态 U2，更新 t + 0.5*dt 核心半步时刻的幽灵层边界
    U2_ext, _ = apply_DMR_bc(U2, x_coords_in=x_coords_in, t=t + 0.5 * dt, gamma=gamma, nghost=nghost)

    # 2. 计算 Stage 3 的右端项
    rhs3 = compute_rhs_KXRCF(
        U2_ext, dx, dy, gamma=gamma, threshold=threshold, nghost=nghost, epsilon=epsilon
    )
    # 3. 计算最终完全步时刻的全新物理场内场 U_next
    U_next = (1.0 / 3.0) * U_phys + (2.0 / 3.0) * U2 + (2.0 / 3.0) * dt * rhs3

    return U_next


def SolverWeno5Rk3_MLP(U_phys, x_coords_in, dx, dy, dt, model, device, gamma, Nx, Ny, t, threshold=0.5, nghost=3,
                       epsilon=1e-6):
    """
    二维 Euler 方程三阶 TVD-Runge-Kutta 时间推进器（双马赫反射 MLP 神经网络判定版）。
    【标准规范】：严格对齐 U_phys 输入规范以及新版 apply_DMR_bc 边界函数。
    """

    # =========================================================================
    # === Stage 1 (t_stage = t) ===
    # =========================================================================
    # 1. 传入纯物理内场 U_phys，动态构建完全体的 U_ext 以及全场拓展坐标
    U_ext, _ = apply_DMR_bc(U_phys, x_coords_in=x_coords_in, t=t, gamma=gamma, nghost=nghost)

    # 2. 计算空间右端项残差，输出尺寸与 U_phys 严格一致 -> (4, Ny, Nx)
    rhs1 = compute_rhs_2d_with_MLP(
        U_ext=U_ext,
        dx=dx,
        dy=dy,
        model=model,
        device=device,
        gamma=gamma,
        threshold=threshold,
        nghost=nghost,
        epsilon=epsilon
    )
    # 3. 显式 Euler 前进更新
    U1 = U_phys + dt * rhs1

    # =========================================================================
    # === Stage 2 (t_stage = t + dt) ===
    # =========================================================================
    # 1. 传入中间物理态 U1，更新 t + dt 时刻的幽灵层边界
    U1_ext, _ = apply_DMR_bc(U1, x_coords_in=x_coords_in, t=t + dt, gamma=gamma, nghost=nghost)

    # 2. 计算 Stage 2 的右端项
    rhs2 = compute_rhs_2d_with_MLP(
        U_ext=U1_ext,
        dx=dx,
        dy=dy,
        model=model,
        device=device,
        gamma=gamma,
        threshold=threshold,
        nghost=nghost,
        epsilon=epsilon
    )
    # 3. 严格对齐 TVD-RK3 格式展开式
    U2 = 0.75 * U_phys + 0.25 * U1 + 0.25 * dt * rhs2

    # =========================================================================
    # === Stage 3 (t_stage = t + 0.5 * dt) ===
    # =========================================================================
    # 1. 传入中间物理态 U2，更新 t + 0.5*dt 核心半步时刻的幽灵层边界
    U2_ext, _ = apply_DMR_bc(U2, x_coords_in=x_coords_in, t=t + 0.5 * dt, gamma=gamma, nghost=nghost)

    # 2. 计算 Stage 3 的右端项
    rhs3 = compute_rhs_2d_with_MLP(
        U_ext=U2_ext,
        dx=dx,
        dy=dy,
        model=model,
        device=device,
        gamma=gamma,
        threshold=threshold,
        nghost=nghost,
        epsilon=epsilon
    )
    # 3. 计算最终完全步时刻的全新物理场内场 U_next
    U_next = (1.0 / 3.0) * U_phys + (2.0 / 3.0) * U2 + (2.0 / 3.0) * dt * rhs3

    return U_next