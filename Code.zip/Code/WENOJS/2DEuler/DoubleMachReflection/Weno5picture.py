import numpy as np
import matplotlib.pyplot as plt

# ------------------------
# 加载数据
# ------------------------
Nx = 120
Ny = 30
filename_prefix = f"Weno5DoubleMachRefelection_{Nx}x{Ny}_results"
npz_filename = f"{filename_prefix}.npz"

data = np.load(npz_filename)
rho = data['rho']  # 内部网格密度 (Ny, Nx)

print(f"密度数组形状: {rho.shape}")
print(f"密度最小值: {np.min(rho):.6f}")#密度最小值: 1.399998
print(f"密度最大值: {np.max(rho):.6f}")#密度最大值: 22.225319

# ------------------------
# 网格坐标
# ------------------------
Lx = 4.0
Ly = 1.0
dx = Lx / Nx
dy = Ly / Ny

x = np.linspace(dx/2, Lx-dx/2, Nx)
y = np.linspace(dy/2, Ly-dy/2, Ny)
X, Y = np.meshgrid(x, y, indexing='xy')#网格中心点坐标

# ------------------------
# 绘图
# ------------------------
levels = np.linspace(1.887, 22.9, 43,)
plt.figure(figsize=(8, 3))
cp = plt.contour(X, Y, rho, levels, cmap='viridis',linewidths=0.7)
# plt.colorbar(cp, label='Density')#颜色指示剂
# plt.xlabel('x')
# plt.ylabel('y')
# plt.title(f'2D Euler WENO5, Nx={Nx}, Ny={Ny}')

# 设置x轴范围从0到3
plt.xlim(0.0, 3.0)
plt.ylim(0.0, 1.0)
plt.tight_layout()
plt.savefig(f"{filename_prefix}.pdf",dpi=600)
plt.show()
