import torch
from helperfunction import *
from model import *
gamma=1.4

def compute_rhs_pure_weno5(U_ext, dx, dy, gamma=1.4, nghost=3, epsilon=1e-6):
    """
    二维 Euler 空间右端项 (RHS) 计算函数 —— 纯五阶 WENO5 格式（无间断探测器回退）。

    参数:
        U_ext   : ndarray, shape (4, Ny_ext, Nx_ext) -> 包含幽灵层的守恒变量
        dx, dy  : float -> 网格间距
        gamma   : float -> 比热比
        nghost  : int   -> 幽灵层数量
        epsilon : float -> WENO5 光滑指示器小量
    """
    n_vars, Ny_ext, Nx_ext = U_ext.shape
    assert n_vars == 4, "二维Euler应有4个守恒变量"
    Ny = Ny_ext - 2 * nghost
    Nx = Nx_ext - 2 * nghost

    # =========================================================================
    # 1. 全场中心点物理量及物理通量解算
    # =========================================================================
    rho = np.maximum(U_ext[0], 1e-14)
    u = U_ext[1] / rho
    v = U_ext[2] / rho
    E = U_ext[3]
    p = np.maximum((gamma - 1.0) * (E - 0.5 * rho * (u ** 2 + v ** 2)), 1e-14)
    H = (E + p) / rho

    F = np.zeros_like(U_ext)  # x方向通量
    G = np.zeros_like(U_ext)  # y方向通量
    F[0], F[1], F[2], F[3] = rho * u, rho * u ** 2 + p, rho * u * v, u * (E + p)
    G[0], G[1], G[2], G[3] = rho * v, rho * u * v, rho * v ** 2 + p, v * (E + p)

    F_hat = np.zeros((4, Ny, Nx + 1))  # x方向界面数值通量
    G_hat = np.zeros((4, Ny + 1, Nx))  # y方向界面数值通量

    # =========================================================================
    # 2. X 方向界面通量计算 (逐行处理)
    # =========================================================================
    for j in range(Ny):
        jj = j + nghost

        # 行内遍历所有 X 方向截面 i+1/2
        for i_face in range(Nx + 1):
            i_center = i_face + nghost
            iL, iR = i_center - 1, i_center

            # Roe 平均态计算
            rhoL, rhoR = rho[jj, iL], rho[jj, iR]
            uL, uR = u[jj, iL], u[jj, iR]
            vL, vR = v[jj, iL], v[jj, iR]
            HL, HR = H[jj, iL], H[jj, iR]

            rtL, rtR = np.sqrt(rhoL), np.sqrt(rhoR)
            denom = rtL + rtR
            u_t = (rtL * uL + rtR * uR) / denom
            v_t = (rtL * vL + rtR * vR) / denom
            H_t = (rtL * HL + rtR * HR) / denom
            a_t = np.sqrt(np.maximum((gamma - 1.0) * (H_t - 0.5 * (u_t ** 2 + v_t ** 2)), 1e-14))

            # 构造特征变换矩阵
            gamma1 = gamma - 1.0
            V_sq = u_t ** 2 + v_t ** 2
            R_mat = np.array([
                [1.0, 1.0, 0.0, 1.0],
                [u_t - a_t, u_t, 0.0, u_t + a_t],
                [v_t, v_t, 1.0, v_t],
                [H_t - u_t * a_t, 0.5 * V_sq, v_t, H_t + u_t * a_t]
            ])
            L_mat = np.array([
                [H_t + (a_t / gamma1) * (u_t - a_t), -(u_t + a_t / gamma1), -v_t, 1.0],
                [-2 * H_t + 4 * a_t ** 2 / gamma1, 2 * u_t, 2 * v_t, -2.0],
                [-2 * v_t * a_t ** 2 / gamma1, 0.0, 2 * a_t ** 2 / gamma1, 0.0],
                [H_t - (a_t / gamma1) * (u_t + a_t), -u_t + a_t / gamma1, -v_t, 1.0]
            ])
            L_mat = (gamma1 / (2.0 * a_t ** 2)) * L_mat

            # 投影到特征空间
            stencil = slice(i_center - 3, i_center + 3)
            W_stencil = L_mat @ U_ext[:, jj, stencil]
            G_stencil = L_mat @ F[:, jj, stencil]

            alpha_val = np.max(np.abs([u_t - a_t, u_t, u_t + a_t]))
            G_plus = 0.5 * (G_stencil + alpha_val * W_stencil)
            G_minus = 0.5 * (G_stencil - alpha_val * W_stencil)

            Gp_iL = np.zeros(4)
            Gm_iR = np.zeros(4)

            # 四个物理守恒通道全部强制进行五阶 WENO 重构
            for k in range(4):
                # --- 正通量左重构 (WENO5) ---
                g = G_plus[k, :]
                p1 = (2 * g[0] - 7 * g[1] + 11 * g[2]) / 6.0
                p2 = (-g[1] + 5 * g[2] + 2 * g[3]) / 6.0
                p3 = (2 * g[2] + 5 * g[3] - g[4]) / 6.0
                b1 = (13 / 12) * (g[0] - 2 * g[1] + g[2]) ** 2 + 0.25 * (g[0] - 4 * g[1] + 3 * g[2]) ** 2
                b2 = (13 / 12) * (g[1] - 2 * g[2] + g[3]) ** 2 + 0.25 * (g[1] - g[3]) ** 2
                b3 = (13 / 12) * (g[2] - 2 * g[3] + g[4]) ** 2 + 0.25 * (3 * g[2] - 4 * g[3] + g[4]) ** 2
                al1 = 0.1 / (epsilon + b1) ** 2
                al2 = 0.6 / (epsilon + b2) ** 2
                al3 = 0.3 / (epsilon + b3) ** 2
                w_sum = al1 + al2 + al3
                Gp_iL[k] = (al1 * p1 + al2 * p2 + al3 * p3) / w_sum

                # --- 负通量右重构 (WENO5) ---
                g = G_minus[k, :]
                p1 = (-g[1] + 5 * g[2] + 2 * g[3]) / 6.0
                p2 = (2 * g[2] + 5 * g[3] - g[4]) / 6.0
                p3 = (11 * g[3] - 7 * g[4] + 2 * g[5]) / 6.0
                b1 = (13 / 12) * (g[1] - 2 * g[2] + g[3]) ** 2 + 0.25 * (g[1] - 4 * g[2] + 3 * g[3]) ** 2
                b2 = (13 / 12) * (g[2] - 2 * g[3] + g[4]) ** 2 + 0.25 * (g[2] - g[4]) ** 2
                b3 = (13 / 12) * (g[3] - 2 * g[4] + g[5]) ** 2 + 0.25 * (3 * g[3] - 4 * g[4] + g[5]) ** 2
                al1 = 0.3 / (epsilon + b1) ** 2
                al2 = 0.6 / (epsilon + b2) ** 2
                al3 = 0.1 / (epsilon + b3) ** 2
                w_sum = al1 + al2 + al3
                Gm_iR[k] = (al1 * p1 + al2 * p2 + al3 * p3) / w_sum

            F_hat[:, j, i_face] = R_mat @ (Gp_iL + Gm_iR)

    # =========================================================================
    # 3. Y 方向界面通量计算 (逐列处理)
    # =========================================================================
    for i in range(Nx):
        ii = i + nghost

        # 列内遍历所有 Y 方向截面 j+1/2
        for j_face in range(Ny + 1):
            j_center = j_face + nghost
            jL, jR = j_center - 1, j_center

            rhoL, rhoR = rho[jL, ii], rho[jR, ii]
            uL, uR = u[jL, ii], u[jR, ii]
            vL, vR = v[jL, ii], v[jR, ii]
            HL, HR = H[jL, ii], H[jR, ii]

            rtL, rtR = np.sqrt(rhoL), np.sqrt(rhoR)
            denom = rtL + rtR
            u_t = (rtL * uL + rtR * uR) / denom
            v_t = (rtL * vL + rtR * vR) / denom
            H_t = (rtL * HL + rtR * HR) / denom
            a_t = np.sqrt(np.maximum((gamma - 1.0) * (H_t - 0.5 * (u_t ** 2 + v_t ** 2)), 1e-14))

            # 构造特征变换矩阵
            gamma1 = gamma - 1.0
            V_sq = u_t ** 2 + v_t ** 2
            R_mat = np.array([
                [1.0, 0.0, 1.0, 1.0],
                [u_t, 1.0, u_t, u_t],
                [v_t - a_t, 0.0, v_t, v_t + a_t],
                [H_t - v_t * a_t, v_t, 0.5 * V_sq, H_t + v_t * a_t]
            ])
            L_mat = np.array([
                [H_t + (a_t / gamma1) * (v_t - a_t), -u_t, -(v_t + a_t / gamma1), 1.0],
                [-2 * u_t * a_t ** 2 / gamma1, 2 * a_t ** 2 / gamma1, 0.0, 0.0],
                [-2 * H_t + 4 * a_t ** 2 / gamma1, 2 * u_t, 2 * v_t, -2.0],
                [H_t - (a_t / gamma1) * (v_t + a_t), -u_t, -v_t + a_t / gamma1, 1.0]
            ])
            L_mat = (gamma1 / (2.0 * a_t ** 2)) * L_mat

            # 投影到特征空间
            stencil = slice(j_center - 3, j_center + 3)
            W_stencil = L_mat @ U_ext[:, stencil, ii]
            G_stencil = L_mat @ G[:, stencil, ii]

            alpha_val = np.max(np.abs([v_t - a_t, v_t, v_t + a_t]))
            G_plus = 0.5 * (G_stencil + alpha_val * W_stencil)
            G_minus = 0.5 * (G_stencil - alpha_val * W_stencil)

            Gp_iL = np.zeros(4)
            Gm_iR = np.zeros(4)

            for k in range(4):
                # --- 正通量左(下)重构 (WENO5) ---
                g = G_plus[k, :]
                p1 = (2 * g[0] - 7 * g[1] + 11 * g[2]) / 6.0
                p2 = (-g[1] + 5 * g[2] + 2 * g[3]) / 6.0
                p3 = (2 * g[2] + 5 * g[3] - g[4]) / 6.0
                b1 = (13 / 12) * (g[0] - 2 * g[1] + g[2]) ** 2 + 0.25 * (g[0] - 4 * g[1] + 3 * g[2]) ** 2
                b2 = (13 / 12) * (g[1] - 2 * g[2] + g[3]) ** 2 + 0.25 * (g[1] - g[3]) ** 2
                b3 = (13 / 12) * (g[2] - 2 * g[3] + g[4]) ** 2 + 0.25 * (3 * g[2] - 4 * g[3] + g[4]) ** 2
                al1 = 0.1 / (epsilon + b1) ** 2
                al2 = 0.6 / (epsilon + b2) ** 2
                al3 = 0.3 / (epsilon + b3) ** 2
                w_sum = al1 + al2 + al3
                Gp_iL[k] = (al1 * p1 + al2 * p2 + al3 * p3) / w_sum

                # --- 负通量右(上)重构 (WENO5) ---
                g = G_minus[k, :]
                p1 = (-g[1] + 5 * g[2] + 2 * g[3]) / 6.0
                p2 = (2 * g[2] + 5 * g[3] - g[4]) / 6.0
                p3 = (11 * g[3] - 7 * g[4] + 2 * g[5]) / 6.0
                b1 = (13 / 12) * (g[1] - 2 * g[2] + g[3]) ** 2 + 0.25 * (g[1] - 4 * g[2] + 3 * g[3]) ** 2
                b2 = (13 / 12) * (g[2] - 2 * g[3] + g[4]) ** 2 + 0.25 * (g[2] - g[4]) ** 2
                b3 = (13 / 12) * (g[3] - 2 * g[4] + g[5]) ** 2 + 0.25 * (3 * g[3] - 4 * g[4] + g[5]) ** 2
                al1 = 0.3 / (epsilon + b1) ** 2
                al2 = 0.6 / (epsilon + b2) ** 2
                al3 = 0.1 / (epsilon + b3) ** 2
                w_sum = al1 + al2 + al3
                Gm_iR[k] = (al1 * p1 + al2 * p2 + al3 * p3) / w_sum

            G_hat[:, j_face, i] = R_mat @ (Gp_iL + Gm_iR)

    # =========================================================================
    # 4. 空间总残差守恒组合 (RHS = -dF/dx - dG/dy)
    # =========================================================================
    rhs = np.zeros((4, Ny, Nx))
    rhs -= (F_hat[:, :, 1:] - F_hat[:, :, :-1]) / dx
    rhs -= (G_hat[:, 1:, :] - G_hat[:, :-1, :]) / dy
    return rhs


def compute_rhs_KXRCF(U_ext, dx, dy, gamma=1.4, threshold=1.0, nghost=3, epsilon=1e-6):
    """
    二维 Euler 空间右端项 (RHS) 计算函数。
    【物理与文献严谨对齐】：完全继承一维比熵 KXRCF 探测器的物理逻辑，彻底废除逐通道或物理通量判定。

    参数:
        U_ext : ndarray, shape (4, Ny_ext, Nx_ext) -> 包含幽灵层的守恒变量
        dx, dy : float -> 网格间距
        threshold : float -> 间断捕捉学术标准阈值 (Li & Qiu 文献规范锁死 1.0)
    """
    n_vars, Ny_ext, Nx_ext = U_ext.shape
    assert n_vars == 4, "二维Euler应有4个守恒变量"
    Ny = Ny_ext - 2 * nghost
    Nx = Nx_ext - 2 * nghost

    # =========================================================================
    # 1. 全场中心点物理量及物理通量解算
    # =========================================================================
    rho = np.maximum(U_ext[0], 1e-14)
    u = U_ext[1] / rho
    v = U_ext[2] / rho
    E = U_ext[3]
    p = np.maximum((gamma - 1.0) * (E - 0.5 * rho * (u ** 2 + v ** 2)), 1e-14)
    H = (E + p) / rho

    F = np.zeros_like(U_ext)  # x方向通量
    G = np.zeros_like(U_ext)  # y方向通量
    F[0], F[1], F[2], F[3] = rho * u, rho * u ** 2 + p, rho * u * v, u * (E + p)
    G[0], G[1], G[2], G[3] = rho * v, rho * u * v, rho * v ** 2 + p, v * (E + p)

    # 计算全流场统一、尺度不变的物理热力学标量熵 (s = p / rho^gamma)
    entropy = p / np.maximum(rho ** gamma, 1e-12)

    F_hat = np.zeros((4, Ny, Nx + 1))  # x方向界面数值通量
    G_hat = np.zeros((4, Ny + 1, Nx))  # y方向界面数值通量

    # =========================================================================
    # 2. X 方向界面通量计算 (逐行处理，基于 X 方向一维标量熵判定)
    # =========================================================================
    nx_dir, ny_dir = 1.0, 0.0

    for j in range(Ny):
        jj = j + nghost

        # 预先解算该行对应的 X 方向一维不连续性判定序列 (对齐一维拓扑)
        prob_x = np.zeros(Nx + 2, dtype=np.float32)
        for i in range(Nx + 2):
            idx_ext = i + (nghost - 1)

            # 提取该物理网格在 X 方向的一维二次多项式系数
            u0_l = (entropy[jj, idx_ext - 2] + 22 * entropy[jj, idx_ext - 1] + entropy[jj, idx_ext]) / 24.0
            u1_l = (entropy[jj, idx_ext - 2 - 1] * 0.0 + entropy[jj, idx_ext] - entropy[jj, idx_ext - 2]) / 2.0  # 严格对齐
            u2_l = (entropy[jj, idx_ext - 2] - 2 * entropy[jj, idx_ext - 1] + entropy[jj, idx_ext]) / 2.0

            u0_c = (entropy[jj, idx_ext - 1] + 22 * entropy[jj, idx_ext] + entropy[jj, idx_ext + 1]) / 24.0
            u1_c = (entropy[jj, idx_ext + 1] - entropy[jj, idx_ext - 1]) / 2.0
            u2_c = (entropy[jj, idx_ext - 1] - 2 * entropy[jj, idx_ext] + entropy[jj, idx_ext + 1]) / 2.0

            u0_r = (entropy[jj, idx_ext] + 22 * entropy[jj, idx_ext + 1] + entropy[jj, idx_ext + 2]) / 24.0
            u1_r = (entropy[jj, idx_ext + 2] - entropy[jj, idx_ext]) / 2.0
            u2_r = (entropy[jj, idx_ext] - 2 * entropy[jj, idx_ext + 1] + entropy[jj, idx_ext + 2]) / 2.0

            edge_R_of_L = u0_l + 0.5 * u1_l + (1.0 / 6.0) * u2_l
            edge_L_of_C = u0_c - 0.5 * u1_c + (1.0 / 6.0) * u2_c
            edge_R_of_C = u0_c + 0.5 * u1_c + (1.0 / 6.0) * u2_c
            edge_L_of_R = u0_r - 0.5 * u1_r + (1.0 / 6.0) * u2_r

            max_jump = np.max([np.abs(edge_L_of_C - edge_R_of_L), np.abs(edge_L_of_R - edge_R_of_C)])
            denominator = (dx ** 2.5) * (np.abs(entropy[jj, idx_ext]) + 1e-10)

            prob_x[i] = 1.0 if (max_jump / denominator) <= threshold else 0.0

        # 行内遍历所有 X 方向截面 i+1/2
        for i_face in range(Nx + 1):
            i_center = i_face + nghost
            iL, iR = i_center - 1, i_center

            # Roe 平均态计算
            rhoL, rhoR = rho[jj, iL], rho[jj, iR]
            uL, uR = u[jj, iL], u[jj, iR]
            vL, vR = v[jj, iL], v[jj, iR]
            HL, HR = H[jj, iL], H[jj, iR]

            rtL, rtR = np.sqrt(rhoL), np.sqrt(rhoR)
            denom = rtL + rtR
            u_t = (rtL * uL + rtR * uR) / denom
            v_t = (rtL * vL + rtR * vR) / denom
            H_t = (rtL * HL + rtR * HR) / denom
            a_t = np.sqrt(np.maximum((gamma - 1.0) * (H_t - 0.5 * (u_t ** 2 + v_t ** 2)), 1e-14))

            # 构造特征变换矩阵 (基于您前文给出的 x方向完全复制Fortran解析表达式)
            gamma1 = gamma - 1.0
            V_sq = u_t ** 2 + v_t ** 2
            R_mat = np.array([
                [1.0, 1.0, 0.0, 1.0],
                [u_t - a_t, u_t, 0.0, u_t + a_t],
                [v_t, v_t, 1.0, v_t],
                [H_t - u_t * a_t, 0.5 * V_sq, v_t, H_t + u_t * a_t]
            ])
            L_mat = np.array([
                [H_t + (a_t / gamma1) * (u_t - a_t), -(u_t + a_t / gamma1), -v_t, 1.0],
                [-2 * H_t + 4 * a_t ** 2 / gamma1, 2 * u_t, 2 * v_t, -2.0],
                [-2 * v_t * a_t ** 2 / gamma1, 0.0, 2 * a_t ** 2 / gamma1, 0.0],
                [H_t - (a_t / gamma1) * (u_t + a_t), -u_t + a_t / gamma1, -v_t, 1.0]
            ])
            L_mat = (gamma1 / (2.0 * a_t ** 2)) * L_mat

            # 投影到特征空间
            stencil = slice(i_center - 3, i_center + 3)
            W_stencil = L_mat @ U_ext[:, jj, stencil]
            G_stencil = L_mat @ F[:, jj, stencil]

            alpha_val = np.max(np.abs([u_t - a_t, u_t, u_t + a_t]))
            G_plus = 0.5 * (G_stencil + alpha_val * W_stencil)
            G_minus = 0.5 * (G_stencil - alpha_val * W_stencil)

            Gp_iL = np.zeros(4)
            Gm_iR = np.zeros(4)

            # 四个物理守恒通道共享由标量比熵生成的 prob_x 探测算子
            for k in range(4):
                # --- 正通量左重构 ---
                if prob_x[i_face]:  # 走 Linear5 高阶重构
                    g = G_plus[k, :]
                    Gp_iL[k] = (2 * g[0] - 13 * g[1] + 47 * g[2] + 27 * g[3] - 3 * g[4]) / 60.0
                else:  # 回退到标准五阶 WENO5
                    g = G_plus[k, :]
                    p1 = (2 * g[0] - 7 * g[1] + 11 * g[2]) / 6.0
                    p2 = (-g[1] + 5 * g[2] + 2 * g[3]) / 6.0
                    p3 = (2 * g[2] + 5 * g[3] - g[4]) / 6.0
                    b1 = (13 / 12) * (g[0] - 2 * g[1] + g[2]) ** 2 + 0.25 * (g[0] - 4 * g[1] + 3 * g[2]) ** 2
                    b2 = (13 / 12) * (g[1] - 2 * g[2] + g[3]) ** 2 + 0.25 * (g[1] - g[3]) ** 2
                    b3 = (13 / 12) * (g[2] - 2 * g[3] + g[4]) ** 2 + 0.25 * (3 * g[2] - 4 * g[3] + g[4]) ** 2
                    al1 = 0.1 / (epsilon + b1) ** 2;
                    al2 = 0.6 / (epsilon + b2) ** 2;
                    al3 = 0.3 / (epsilon + b3) ** 2
                    w_sum = al1 + al2 + al3
                    Gp_iL[k] = (al1 * p1 + al2 * p2 + al3 * p3) / w_sum

                # --- 负通量右重构 ---
                if prob_x[i_face + 1]:  # 走 Linear5 右侧重构
                    g = G_minus[k, :]
                    Gm_iR[k] = (-3 * g[1] + 27 * g[2] + 47 * g[3] - 13 * g[4] + 2 * g[5]) / 60.0
                else:  # 回退到标准五阶 WENO5
                    g = G_minus[k, :]
                    p1 = (-g[1] + 5 * g[2] + 2 * g[3]) / 6.0
                    p2 = (2 * g[2] + 5 * g[3] - g[4]) / 6.0
                    p3 = (11 * g[3] - 7 * g[4] + 2 * g[5]) / 6.0
                    b1 = (13 / 12) * (g[1] - 2 * g[2] + g[3]) ** 2 + 0.25 * (g[1] - 4 * g[2] + 3 * g[3]) ** 2
                    b2 = (13 / 12) * (g[2] - 2 * g[3] + g[4]) ** 2 + 0.25 * (g[2] - g[4]) ** 2
                    b3 = (13 / 12) * (g[3] - 2 * g[4] + g[5]) ** 2 + 0.25 * (3 * g[3] - 4 * g[4] + g[5]) ** 2
                    al1 = 0.3 / (epsilon + b1) ** 2;
                    al2 = 0.6 / (epsilon + b2) ** 2;
                    al3 = 0.1 / (epsilon + b3) ** 2
                    w_sum = al1 + al2 + al3
                    Gm_iR[k] = (al1 * p1 + al2 * p2 + al3 * p3) / w_sum

            F_hat[:, j, i_face] = R_mat @ (Gp_iL + Gm_iR)

    # =========================================================================
    # 3. Y 方向界面通量计算 (逐列处理，基于 Y 方向一维标量熵判定)
    # =========================================================================
    nx_dir, ny_dir = 0.0, 1.0

    for i in range(Nx):
        ii = i + nghost

        # 预先解算该列对应的 Y 方向一维不连续性判定序列
        prob_y = np.zeros(Ny + 2, dtype=np.float32)
        for j in range(Ny + 2):
            idx_ext = j + (nghost - 1)

            u0_l = (entropy[idx_ext - 2, ii] + 22 * entropy[idx_ext - 1, ii] + entropy[idx_ext, ii]) / 24.0
            u1_l = (entropy[idx_ext, ii] - entropy[idx_ext - 2, ii]) / 2.0
            u2_l = (entropy[idx_ext - 2, ii] - 2 * entropy[idx_ext - 1, ii] + entropy[idx_ext, ii]) / 2.0

            u0_c = (entropy[idx_ext - 1, ii] + 22 * entropy[idx_ext, ii] + entropy[idx_ext + 1, ii]) / 24.0
            u1_c = (entropy[idx_ext + 1, ii] - entropy[idx_ext - 1, ii]) / 2.0
            u2_c = (entropy[idx_ext - 1, ii] - 2 * entropy[idx_ext, ii] + entropy[idx_ext + 1, ii]) / 2.0

            u0_r = (entropy[idx_ext, ii] + 22 * entropy[idx_ext + 1, ii] + entropy[idx_ext + 2, ii]) / 24.0
            u1_r = (entropy[idx_ext + 2, ii] - entropy[idx_ext, ii]) / 2.0
            u2_r = (entropy[idx_ext, ii] - 2 * entropy[idx_ext + 1, ii] + entropy[idx_ext + 2, ii]) / 2.0

            edge_R_of_L = u0_l + 0.5 * u1_l + (1.0 / 6.0) * u2_l
            edge_L_of_C = u0_c - 0.5 * u1_c + (1.0 / 6.0) * u2_c
            edge_R_of_C = u0_c + 0.5 * u1_c + (1.0 / 6.0) * u2_c
            edge_L_of_R = u0_r - 0.5 * u1_r + (1.0 / 6.0) * u2_r

            max_jump = np.max([np.abs(edge_L_of_C - edge_R_of_L), np.abs(edge_L_of_R - edge_R_of_C)])
            denominator = (dy ** 2.5) * (np.abs(entropy[idx_ext, ii]) + 1e-10)

            prob_y[j] = 1.0 if (max_jump / denominator) <= threshold else 0.0

        # 列内遍历所有 Y 方向截面 j+1/2
        for j_face in range(Ny + 1):
            j_center = j_face + nghost
            jL, jR = j_center - 1, j_center

            rhoL, rhoR = rho[jL, ii], rho[jR, ii]
            uL, uR = u[jL, ii], u[jR, ii]
            vL, vR = v[jL, ii], v[jR, ii]
            HL, HR = H[jL, ii], H[jR, ii]

            rtL, rtR = np.sqrt(rhoL), np.sqrt(rhoR)
            denom = rtL + rtR
            u_t = (rtL * uL + rtR * uR) / denom
            v_t = (rtL * vL + rtR * vR) / denom
            H_t = (rtL * HL + rtR * HR) / denom
            a_t = np.sqrt(np.maximum((gamma - 1.0) * (H_t - 0.5 * (u_t ** 2 + v_t ** 2)), 1e-14))

            # 构造特征变换矩阵 (基于您前文给出的 y方向完全复制Fortran解析表达式)
            gamma1 = gamma - 1.0
            V_sq = u_t ** 2 + v_t ** 2
            R_mat = np.array([
                [1.0, 0.0, 1.0, 1.0],
                [u_t, 1.0, u_t, u_t],
                [v_t - a_t, 0.0, v_t, v_t + a_t],
                [H_t - v_t * a_t, v_t, 0.5 * V_sq, H_t + v_t * a_t]
            ])
            L_mat = np.array([
                [H_t + (a_t / gamma1) * (v_t - a_t), -u_t, -(v_t + a_t / gamma1), 1.0],
                [-2 * u_t * a_t ** 2 / gamma1, 2 * a_t ** 2 / gamma1, 0.0, 0.0],
                [-2 * H_t + 4 * a_t ** 2 / gamma1, 2 * u_t, 2 * v_t, -2.0],
                [H_t - (a_t / gamma1) * (v_t + a_t), -u_t, -v_t + a_t / gamma1, 1.0]
            ])
            L_mat = (gamma1 / (2.0 * a_t ** 2)) * L_mat

            # 投影到特征空间
            stencil = slice(j_center - 3, j_center + 3)
            W_stencil = L_mat @ U_ext[:, stencil, ii]
            G_stencil = L_mat @ G[:, stencil, ii]  # 注意此处乘的是Y方向通量G

            alpha_val = np.max(np.abs([v_t - a_t, v_t, v_t + a_t]))
            G_plus = 0.5 * (G_stencil + alpha_val * W_stencil)
            G_minus = 0.5 * (G_stencil - alpha_val * W_stencil)

            Gp_iL = np.zeros(4)
            Gm_iR = np.zeros(4)

            for k in range(4):
                # --- 正通量左(下)重构 ---
                if prob_y[j_face]:
                    g = G_plus[k, :]
                    Gp_iL[k] = (2 * g[0] - 13 * g[1] + 47 * g[2] + 27 * g[3] - 3 * g[4]) / 60.0
                else:
                    g = G_plus[k, :]
                    p1 = (2 * g[0] - 7 * g[1] + 11 * g[2]) / 6.0
                    p2 = (-g[1] + 5 * g[2] + 2 * g[3]) / 6.0
                    p3 = (2 * g[2] + 5 * g[3] - g[4]) / 6.0
                    b1 = (13 / 12) * (g[0] - 2 * g[1] + g[2]) ** 2 + 0.25 * (g[0] - 4 * g[1] + 3 * g[2]) ** 2
                    b2 = (13 / 12) * (g[1] - 2 * g[2] + g[3]) ** 2 + 0.25 * (g[1] - g[3]) ** 2
                    b3 = (13 / 12) * (g[2] - 2 * g[3] + g[4]) ** 2 + 0.25 * (3 * g[2] - 4 * g[3] + g[4]) ** 2
                    al1 = 0.1 / (epsilon + b1) ** 2;
                    al2 = 0.6 / (epsilon + b2) ** 2;
                    al3 = 0.3 / (epsilon + b3) ** 2
                    w_sum = al1 + al2 + al3
                    Gp_iL[k] = (al1 * p1 + al2 * p2 + al3 * p3) / w_sum

                # --- 负通量右(上)重构 ---
                if prob_y[j_face + 1]:
                    g = G_minus[k, :]
                    Gm_iR[k] = (-3 * g[1] + 27 * g[2] + 47 * g[3] - 13 * g[4] + 2 * g[5]) / 60.0
                else:
                    g = G_minus[k, :]
                    p1 = (-g[1] + 5 * g[2] + 2 * g[3]) / 6.0
                    p2 = (2 * g[2] + 5 * g[3] - g[4]) / 6.0
                    p3 = (11 * g[3] - 7 * g[4] + 2 * g[5]) / 6.0
                    b1 = (13 / 12) * (g[1] - 2 * g[2] + g[3]) ** 2 + 0.25 * (g[1] - 4 * g[2] + 3 * g[3]) ** 2
                    b2 = (13 / 12) * (g[2] - 2 * g[3] + g[4]) ** 2 + 0.25 * (g[2] - g[4]) ** 2
                    b3 = (13 / 12) * (g[3] - 2 * g[4] + g[5]) ** 2 + 0.25 * (3 * g[3] - 4 * g[4] + g[5]) ** 2
                    al1 = 0.3 / (epsilon + b1) ** 2;
                    al2 = 0.6 / (epsilon + b2) ** 2;
                    al3 = 0.1 / (epsilon + b3) ** 2
                    w_sum = al1 + al2 + al3
                    Gm_iR[k] = (al1 * p1 + al2 * p2 + al3 * p3) / w_sum

            G_hat[:, j_face, i] = R_mat @ (Gp_iL + Gm_iR)

    # =========================================================================
    # 4. 空间总残差守恒组合 (RHS = -dF/dx - dG/dy)
    # =========================================================================
    rhs = np.zeros((4, Ny, Nx))
    rhs -= (F_hat[:, :, 1:] - F_hat[:, :, :-1]) / dx
    rhs -= (G_hat[:, 1:, :] - G_hat[:, :-1, :]) / dy
    return rhs


def compute_rhs_2d_with_MLP(U_ext, dx, dy, model, device, gamma=1.4, threshold=0.5, nghost=3, epsilon=1e-6):
    """
    二维 Euler 空间右端项 (RHS) 计算函数。
    【内场预测架构】：神经网络预测逻辑完全集成在函数内部，逐行/逐列提取一维物理比熵切片
    实时产生内场的 prob_x 和 prob_y 判定序列。

    参数:
        U_ext     : ndarray, shape (4, Ny_ext, Nx_ext) -> 包含幽灵层的守恒变量
        dx, dy    : float -> 网格间距
        model     : 传入的神经网络模型实例 (Weno5FDMMLP)
        device    : PyTorch 计算设备 (cpu 或 mps)
        threshold : 神经网络输出的判定阈值（默认 0.5）
    """
    n_vars, Ny_ext, Nx_ext = U_ext.shape
    assert n_vars == 4, "二维Euler应有4个守恒变量"
    Ny = Ny_ext - 2 * nghost
    Nx = Nx_ext - 2 * nghost

    # =========================================================================
    # 1. 全场中心点物理量及物理通量解算
    # =========================================================================
    rho = np.maximum(U_ext[0], 1e-14)
    u = U_ext[1] / rho
    v = U_ext[2] / rho
    E = U_ext[3]
    p = np.maximum((gamma - 1.0) * (E - 0.5 * rho * (u ** 2 + v ** 2)), 1e-14)
    H = (E + p) / rho

    F = np.zeros_like(U_ext)  # x方向通量
    G = np.zeros_like(U_ext)  # y方向通量
    F[0], F[1], F[2], F[3] = rho * u, rho * u ** 2 + p, rho * u * v, u * (E + p)
    G[0], G[1], G[2], G[3] = rho * v, rho * u * v, rho * v ** 2 + p, v * (E + p)

    # 计算全流场统一、尺度不变的物理热力学标量熵 (s = p / rho^gamma)用于网络特征提取
    entropy = p / np.maximum(rho ** gamma, 1e-12)

    F_hat = np.zeros((4, Ny, Nx + 1))  # x方向界面数值通量
    G_hat = np.zeros((4, Ny + 1, Nx))  # y方向界面数值通量

    # =========================================================================
    # 2. X 方向界面通量计算 (逐行处理，内部动态调用 predict_2d 产生 prob_x)
    # =========================================================================
    for j in range(Ny):
        jj = j + nghost

        # 【集成在内部】：直接提取该行包含所有 ghost 单元的完整一维熵切片
        entropy_slice_x = entropy[jj, :]
        # 调用你的一维神经网络算子（严格传递 4 个参数）
        prob_array_x = predict_2d(entropy_slice_x, dx, model, device)
        # 二值化生成当前行的 troubled-point 判定序列（长度为 Nx + 2）
        prob_x = np.where(prob_array_x > threshold, 1.0, 0.0)

        # 行内遍历所有 X 方向截面 i+1/2
        for i_face in range(Nx + 1):
            i_center = i_face + nghost
            iL, iR = i_center - 1, i_center

            # Roe 平均态计算
            rhoL, rhoR = rho[jj, iL], rho[jj, iR]
            uL, uR = u[jj, iL], u[jj, iR]
            vL, vR = v[jj, iL], v[jj, iR]
            HL, HR = H[jj, iL], H[jj, iR]

            rtL, rtR = np.sqrt(rhoL), np.sqrt(rhoR)
            denom = rtL + rtR
            u_t = (rtL * uL + rtR * uR) / denom
            v_t = (rtL * vL + rtR * vR) / denom
            H_t = (rtL * HL + rtR * HR) / denom
            a_t = np.sqrt(np.maximum((gamma - 1.0) * (H_t - 0.5 * (u_t ** 2 + v_t ** 2)), 1e-14))

            # 构造特征变换矩阵 (X 方向)
            gamma1 = gamma - 1.0
            V_sq = u_t ** 2 + v_t ** 2
            R_mat = np.array([
                [1.0, 1.0, 0.0, 1.0],
                [u_t - a_t, u_t, 0.0, u_t + a_t],
                [v_t, v_t, 1.0, v_t],
                [H_t - u_t * a_t, 0.5 * V_sq, v_t, H_t + u_t * a_t]
            ])
            L_mat = np.array([
                [H_t + (a_t / gamma1) * (u_t - a_t), -(u_t + a_t / gamma1), -v_t, 1.0],
                [-2 * H_t + 4 * a_t ** 2 / gamma1, 2 * u_t, 2 * v_t, -2.0],
                [-2 * v_t * a_t ** 2 / gamma1, 0.0, 2 * a_t ** 2 / gamma1, 0.0],
                [H_t - (a_t / gamma1) * (u_t + a_t), -u_t + a_t / gamma1, -v_t, 1.0]
            ])
            L_mat = (gamma1 / (2.0 * a_t ** 2)) * L_mat

            # 投影到特征空间
            stencil = slice(i_center - 3, i_center + 3)
            W_stencil = L_mat @ U_ext[:, jj, stencil]
            G_stencil = L_mat @ F[:, jj, stencil]

            alpha_val = np.max(np.abs([u_t - a_t, u_t, u_t + a_t]))
            G_plus = 0.5 * (G_stencil + alpha_val * W_stencil)
            G_minus = 0.5 * (G_stencil - alpha_val * W_stencil)

            Gp_iL = np.zeros(4)
            Gm_iR = np.zeros(4)

            # 四个物理守恒通道共享由神经网络在内部生成的标量 prob_x 探测算子
            for k in range(4):
                # --- 正通量左重构 ---
                if prob_x[i_face] == 1.0:  # 走 Linear5 高阶线性重构
                    g = G_plus[k, :]
                    Gp_iL[k] = (2 * g[0] - 13 * g[1] + 47 * g[2] + 27 * g[3] - 3 * g[4]) / 60.0
                else:  # 回退到经典无振荡 WENO5 重构
                    g = G_plus[k, :]
                    p1 = (2 * g[0] - 7 * g[1] + 11 * g[2]) / 6.0
                    p2 = (-g[1] + 5 * g[2] + 2 * g[3]) / 6.0
                    p3 = (2 * g[2] + 5 * g[3] - g[4]) / 6.0
                    b1 = (13 / 12) * (g[0] - 2 * g[1] + g[2]) ** 2 + 0.25 * (g[0] - 4 * g[1] + 3 * g[2]) ** 2
                    b2 = (13 / 12) * (g[1] - 2 * g[2] + g[3]) ** 2 + 0.25 * (g[1] - g[3]) ** 2
                    b3 = (13 / 12) * (g[2] - 2 * g[3] + g[4]) ** 2 + 0.25 * (3 * g[2] - 4 * g[3] + g[4]) ** 2
                    al1 = 0.1 / (epsilon + b1) ** 2
                    al2 = 0.6 / (epsilon + b2) ** 2
                    al3 = 0.3 / (epsilon + b3) ** 2
                    w_sum = al1 + al2 + al3
                    Gp_iL[k] = (al1 * p1 + al2 * p2 + al3 * p3) / w_sum

                # --- 负通量右重构 ---
                if prob_x[i_face + 1] == 1.0:  # 走 Linear5 右侧重构
                    g = G_minus[k, :]
                    Gm_iR[k] = (-3 * g[1] + 27 * g[2] + 47 * g[3] - 13 * g[4] + 2 * g[5]) / 60.0
                else:  # 回退到标准五阶 WENO5
                    g = G_minus[k, :]
                    p1 = (-g[1] + 5 * g[2] + 2 * g[3]) / 6.0
                    p2 = (2 * g[2] + 5 * g[3] - g[4]) / 6.0
                    p3 = (11 * g[3] - 7 * g[4] + 2 * g[5]) / 6.0
                    b1 = (13 / 12) * (g[1] - 2 * g[2] + g[3]) ** 2 + 0.25 * (g[1] - 4 * g[2] + 3 * g[3]) ** 2
                    b2 = (13 / 12) * (g[2] - 2 * g[3] + g[4]) ** 2 + 0.25 * (g[2] - g[4]) ** 2
                    b3 = (13 / 12) * (g[3] - 2 * g[4] + g[5]) ** 2 + 0.25 * (3 * g[3] - 4 * g[4] + g[5]) ** 2
                    al1 = 0.3 / (epsilon + b1) ** 2
                    al2 = 0.6 / (epsilon + b2) ** 2
                    al3 = 0.1 / (epsilon + b3) ** 2
                    w_sum = al1 + al2 + al3
                    Gm_iR[k] = (al1 * p1 + al2 * p2 + al3 * p3) / w_sum

            F_hat[:, j, i_face] = R_mat @ (Gp_iL + Gm_iR)

    # =========================================================================
    # 3. Y 方向界面通量计算 (逐列处理，内部动态调用 predict_2d 产生 prob_y)
    # =========================================================================
    for i in range(Nx):
        ii = i + nghost

        # 【集成在内部】：直接提取该列包含所有 ghost 单元的完整一维熵切片
        entropy_slice_y = entropy[:, ii]
        # 调用你的一维神经网络算子，空间尺度参数传入 dy
        prob_array_y = predict_2d(entropy_slice_y, dy, model, device)
        # 二值化生成当前列的 troubled-point 判定序列（长度为 Ny + 2）
        prob_y = np.where(prob_array_y > threshold, 1.0, 0.0)

        # 列内遍历所有 Y 方向截面 j+1/2
        for j_face in range(Ny + 1):
            j_center = j_face + nghost
            jL, jR = j_center - 1, j_center

            rhoL, rhoR = rho[jL, ii], rho[jR, ii]
            uL, uR = u[jL, ii], u[jR, ii]
            vL, vR = v[jL, ii], v[jR, ii]
            HL, HR = H[jL, ii], H[jR, ii]

            rtL, rtR = np.sqrt(rhoL), np.sqrt(rhoR)
            denom = rtL + rtR
            u_t = (rtL * uL + rtR * uR) / denom
            v_t = (rtL * vL + rtR * vR) / denom
            H_t = (rtL * HL + rtR * HR) / denom
            a_t = np.sqrt(np.maximum((gamma - 1.0) * (H_t - 0.5 * (u_t ** 2 + v_t ** 2)), 1e-14))

            # 构造特征变换矩阵 (Y 方向)
            gamma1 = gamma - 1.0
            V_sq = u_t ** 2 + v_t ** 2
            R_mat = np.array([
                [1.0, 0.0, 1.0, 1.0],
                [u_t, 1.0, u_t, u_t],
                [v_t - a_t, 0.0, v_t, v_t + a_t],
                [H_t - v_t * a_t, v_t, 0.5 * V_sq, H_t + v_t * a_t]
            ])
            L_mat = np.array([
                [H_t + (a_t / gamma1) * (v_t - a_t), -u_t, -(v_t + a_t / gamma1), 1.0],
                [-2 * u_t * a_t ** 2 / gamma1, 2 * a_t ** 2 / gamma1, 0.0, 0.0],
                [-2 * H_t + 4 * a_t ** 2 / gamma1, 2 * u_t, 2 * v_t, -2.0],
                [H_t - (a_t / gamma1) * (v_t + a_t), -u_t, -v_t + a_t / gamma1, 1.0]
            ])
            L_mat = (gamma1 / (2.0 * a_t ** 2)) * L_mat

            # 投影到特征空间
            stencil = slice(j_center - 3, j_center + 3)
            W_stencil = L_mat @ U_ext[:, stencil, ii]
            G_stencil = L_mat @ G[:, stencil, ii]  # 乘的是 Y 方向物理通量 G

            alpha_val = np.max(np.abs([v_t - a_t, v_t, v_t + a_t]))
            G_plus = 0.5 * (G_stencil + alpha_val * W_stencil)
            G_minus = 0.5 * (G_stencil - alpha_val * W_stencil)

            Gp_iL = np.zeros(4)
            Gm_iR = np.zeros(4)

            for k in range(4):
                # --- 正通量左(下)重构 ---
                if prob_y[j_face] == 1.0:  # 判定为光滑
                    g = G_plus[k, :]
                    Gp_iL[k] = (2 * g[0] - 13 * g[1] + 47 * g[2] + 27 * g[3] - 3 * g[4]) / 60.0
                else:  # 判定为 troubled-point
                    g = G_plus[k, :]
                    p1 = (2 * g[0] - 7 * g[1] + 11 * g[2]) / 6.0
                    p2 = (-g[1] + 5 * g[2] + 2 * g[3]) / 6.0
                    p3 = (2 * g[2] + 5 * g[3] - g[4]) / 6.0
                    b1 = (13 / 12) * (g[0] - 2 * g[1] + g[2]) ** 2 + 0.25 * (g[0] - 4 * g[1] + 3 * g[2]) ** 2
                    b2 = (13 / 12) * (g[1] - 2 * g[2] + g[3]) ** 2 + 0.25 * (g[1] - g[3]) ** 2
                    b3 = (13 / 12) * (g[2] - 2 * g[3] + g[4]) ** 2 + 0.25 * (3 * g[2] - 4 * g[3] + g[4]) ** 2
                    al1 = 0.1 / (epsilon + b1) ** 2
                    al2 = 0.6 / (epsilon + b2) ** 2
                    al3 = 0.3 / (epsilon + b3) ** 2
                    w_sum = al1 + al2 + al3
                    Gp_iL[k] = (al1 * p1 + al2 * p2 + al3 * p3) / w_sum

                # --- 负通量右(上)重构 ---
                if prob_y[j_face + 1] == 1.0:  # 判定为光滑
                    g = G_minus[k, :]
                    Gm_iR[k] = (-3 * g[1] + 27 * g[2] + 47 * g[3] - 13 * g[4] + 2 * g[5]) / 60.0
                else:  # 回退到标准五阶 WENO5
                    g = G_minus[k, :]
                    p1 = (-g[1] + 5 * g[2] + 2 * g[3]) / 6.0
                    p2 = (2 * g[2] + 5 * g[3] - g[4]) / 6.0
                    p3 = (11 * g[3] - 7 * g[4] + 2 * g[5]) / 6.0
                    b1 = (13 / 12) * (g[1] - 2 * g[2] + g[3]) ** 2 + 0.25 * (g[1] - 4 * g[2] + 3 * g[3]) ** 2
                    b2 = (13 / 12) * (g[2] - 2 * g[3] + g[4]) ** 2 + 0.25 * (g[2] - g[4]) ** 2
                    b3 = (13 / 12) * (g[3] - 2 * g[4] + g[5]) ** 2 + 0.25 * (3 * g[3] - 4 * g[4] + g[5]) ** 2
                    al1 = 0.3 / (epsilon + b1) ** 2
                    al2 = 0.6 / (epsilon + b2) ** 2
                    al3 = 0.1 / (epsilon + b3) ** 2
                    w_sum = al1 + al2 + al3
                    Gm_iR[k] = (al1 * p1 + al2 * p2 + al3 * p3) / w_sum

            G_hat[:, j_face, i] = R_mat @ (Gp_iL + Gm_iR)

    # =========================================================================
    # 4. 空间总残差守恒组合 (RHS = -dF/dx - dG/dy)
    # =========================================================================
    rhs = np.zeros((4, Ny, Nx))
    rhs -= (F_hat[:, :, 1:] - F_hat[:, :, :-1]) / dx
    rhs -= (G_hat[:, 1:, :] - G_hat[:, :-1, :]) / dy
    return rhs
