import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

'''
Joint Post-process for 2D Double Mach Reflection: 
3x3 子图联合二维等高线绘制 (截取区域 X in [0.0, 3.0], 43条等高线版)
横向对比: Column 1 (WENO5), Column 2 (KXRCF), Column 3 (MLP)
纵向对比: Row 1 (240x60), Row 2 (480x120), Row 3 (960x240)
'''


def load_any_data(filepath, Nx, Ny):
    """
    自适应数据读取器：支持 .csv 和 .npz 格式，并将展平的数据重构为二维物理矩阵
    """
    if not os.path.exists(filepath):
        print(f"⚠️ 警告: 未找到文件 {filepath}")
        return None, None, None

    # ---- 情况 A：处理 960x240 的 PureWENO5 .npz 文件 ----
    if filepath.endswith('.npz'):
        data = np.load(filepath)
        try:
            X = data['X'].reshape(Ny, Nx)
            Y = data['Y'].reshape(Ny, Nx)
            rho = data['rho'].reshape(Ny, Nx)
        except KeyError:
            # 备用键名方案，防止 npz 内部使用的是全称
            X = data['X'].reshape(Ny, Nx)
            Y = data['Y'].reshape(Ny, Nx)
            rho = data['Density(rho)'].reshape(Ny, Nx)
        return X, Y, rho

    # ---- 情况 B：处理常规的 .csv 文件 ----
    else:
        skip_rows = 0
        with open(filepath, 'r', encoding='utf-8') as f:
            for line in f:
                if line.startswith('#'):
                    skip_rows += 1
                else:
                    break

        df = pd.read_csv(filepath, skiprows=skip_rows)
        # 注意：重构矩阵的形状必须是 (Ny, Nx)
        X = df['X'].values.reshape(Ny, Nx)
        Y = df['Y'].values.reshape(Ny, Nx)
        rho = df['Density(rho)'].values.reshape(Ny, Nx)
        return X, Y, rho


def main():
    # 禁用 LaTeX 渲染器确保速度与兼容性，全部使用标准的黑体/Sans-serif字体
    plt.rcParams.update({
        'text.usetex': False
    })

    # 纵向三档网格分辨率 (Nx, Ny)
    row_resolutions = [
        (240, 60),
        (480, 120),
        (960, 240)
    ]

    # 横向三档格式方案：使用 lambda 动态匹配特殊文件名
    col_schemes = [
        {
            'key': 'PureWENO5',
            'label': 'WENO5',
            'getter': lambda Nx,
                             Ny: "Weno5DoubleMachRefelection_960x240_results.npz" if Nx == 960 else f"PureWENO5_DoubleMach_{Nx}x{Ny}_results.csv"
        },
        {
            'key': 'Weno5KXRCF',
            'label': 'KXRCF',
            'getter': lambda Nx, Ny: f"Weno5KXRCF_DoubleMach_{Nx}x{Ny}_results.csv"
        },
        {
            'key': 'Weno5MLP',
            'label': 'MLP',
            'getter': lambda Nx, Ny: f"Weno5MLP_DoubleMach_{Nx}x{Ny}_results.csv"
        }
    ]

    # 自动化生成学术子图序号 ['(a)', '(b)', ..., '(i)']
    sub_indices = [f"({chr(97 + i)})" for i in range(9)]

    # =========================================================================
    # 调整1：画布高度拉高到 20.0，配合较大的行间距，确保图片不被压缩变形
    # =========================================================================
    fig, axes = plt.subplots(3, 3, figsize=(36, 20.0))

    # 核心指定：从 1.887 到 22.9 均匀画 43 条等高线
    global_levels = np.linspace(1.887, 22.9, 43)
    cmap_choice = 'viridis'

    # 遍历 3x3 矩阵开始绘图
    for row_idx, (Nx, Ny) in enumerate(row_resolutions):
        for col_idx, scheme in enumerate(col_schemes):
            ax = axes[row_idx, col_idx]

            # 动态获取对应的文件名并读取
            filename = scheme['getter'](Nx, Ny)
            X, Y, rho = load_any_data(filename, Nx, Ny)

            if rho is not None:
                # 绘制纯等高线条，无颜色填充块，渐变颜色直接应用在弧线上
                ax.contour(X, Y, rho,
                           levels=global_levels,
                           cmap=cmap_choice,
                           linewidths=1.0)
            else:
                # 若文件不存在，在对应子图位置渲染红色警告提示
                ax.text(0.5, 0.5, f'Data Missing\n{scheme["label"]}\n{Nx}x{Ny}',
                        ha='center', va='center', fontsize=24, color='red')
                ax.set_xlim(0.0, 3.0)
                ax.set_ylim(0.0, 1.0)
                continue

            # 严格保持物理长宽比 1:1，防止激波角度和波形发生目视扭曲
            ax.set_aspect('equal')
            ax.grid(True, linestyle=':', alpha=0.3)

            # =========================================================================
            # 【极致刻度与截断几何界限设置】
            # =========================================================================
            ax.set_xlim(0.0, 3.0)
            ax.set_ylim(0.0, 1.0)
            ax.set_xticks([0.0, 1.0, 2.0, 3.0])
            ax.set_yticks([0.0, 0.5, 1.0])

            # =========================================================================
            # 【精确学术控标：X 轴全开，Y 轴仅第一列显示数字】
            # =========================================================================
            # 1. X 轴配置：所有子图的横标数字均清晰可见
            ax.tick_params(axis='x', direction='in', top=True, right=True,
                           length=6, width=1.0, labelsize=38, pad=15)
            ax.set_xlabel('X', fontsize=44, labelpad=12)

            # 2. Y 轴配置：只有最左侧一列（col_idx == 0）才有数字，其余隐藏
            if col_idx == 0:
                ax.set_ylabel('Y', fontsize=44, labelpad=12)
                ax.tick_params(axis='y', direction='in', top=True, right=True,
                               length=6, width=1.0, labelsize=38, pad=15)
            else:
                ax.tick_params(axis='y', direction='in', top=True, right=True,
                               length=6, width=1.0, labelleft=False)

            # =========================================================================
            # 🟢 调整2：子图正下方小标题近远精密定位
            # =========================================================================
            flat_idx = row_idx * 3 + col_idx
            full_title = fr"{sub_indices[flat_idx]} {scheme['label']} ($\mathrm{{N}}_x \times \mathrm{{N}}_y = {Nx} \times {Ny}$)"

            # 降低标题高度，避开大字号的 X 轴 label
            title_y_position = -0.42

            ax.text(0.5, title_y_position, full_title, transform=ax.transAxes,
                    fontsize=40, va='top', ha='center')

    # =========================================================================
    # 调整3：大图留白控制（大幅拉开 h_pad 并修正底部预留）
    # =========================================================================
    # h_pad = 7.5：强行拉大上下图之间的空隙
    # rect 的第二个参数从 0.05 调大到 0.08：为最后一行的小标题留出绝对充裕的底层空间
    plt.tight_layout(rect=[0.03, 0.08, 0.97, 0.97], h_pad=7.5, w_pad=2.5)

    output_pdf = "DMR_compare.pdf"
    plt.savefig(output_pdf, dpi=300)
    print(f"\n📊 [绘图成功] 间距完美且标题不重叠的双马赫对比大图已导出至: {output_pdf}")
    plt.show()


if __name__ == "__main__":
    main()