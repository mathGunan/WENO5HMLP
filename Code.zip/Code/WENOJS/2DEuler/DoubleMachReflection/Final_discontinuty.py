import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import torch
from helperfunction import * # 确保此文件中包含 Weno5FDMMLP, predict_2d 等定义

'''
Joint Post-process for 2D Double Mach Reflection Discontinuity Detectors: 3x4 子图联合二维间断点综合汇总大图
横向对比 (Columns):
  - Col 1: MLP (X Direction)   |  Col 2: KXRCF (X Direction)
  - Col 3: MLP (Y Direction)   |  Col 4: KXRCF (Y Direction)
纵向对比 (Rows):
  - Row 1 (240x60), Row 2 (480x120), Row 3 (960x240)
物理与边界约束：
  1. 严格绑定用户提供的专用 DMR 边界条件函数进行幽灵层外推。
  2. 终止时间统一锁定为标准学术值 t = 0.2，gamma = 1.4。
  3. 截断显示区域至 X in [0.0, 3.0]，确保激波细节高清呈现且画布不失真。
'''

gamma = 1.4
t_final = 0.2  # 双马赫反射标准计算终止终止物理时间
model = None
device = None


def get_model():
    """全局获取神经网络模型"""
    global model, device
    if model is None:
        if torch.backends.mps.is_available():
            device = torch.device("mps")
        elif torch.cuda.is_available():
            device = torch.device("cuda")
        else:
            device = torch.device("cpu")

        ckpt = torch.load('best_model.pth', map_location=device)
        model = Weno5FDMMLP().to(device)
        model.load_state_dict(ckpt['model_state_dict'])
        model.eval()
        print("▶ [物理绑定] 神经网络模型加载完成，输入特征严格绑定物理比熵场切片。")
    return model, device


def apply_DMR_bc(U_phys, x_coords_in, t, gamma=1.4, nghost=3):
    """
    专门为双马赫反射 (DMR) 问题定制的边界条件填充函数（完美对齐内场守恒量映射）
    """
    n_vars, Ny, Nx = U_phys.shape
    assert n_vars == 4, "2D Euler 应包含 4 个守恒变量"

    Ny_ext = Ny + 2 * nghost
    Nx_ext = Nx + 2 * nghost

    dx = x_coords_in[1] - x_coords_in[0] if Nx > 1 else 1.0 / Nx
    x_left_ghost = [x_coords_in[0] - (nghost - i) * dx for i in range(nghost)]
    x_right_ghost = [x_coords_in[-1] + (i + 1) * dx for i in range(nghost)]
    x_coords_ext = np.concatenate([x_left_ghost, x_coords_in, x_right_ghost])

    U_ext = np.zeros((4, Ny_ext, Nx_ext))
    U_ext[:, nghost:nghost + Ny, nghost:nghost + Nx] = U_phys

    # 状态 L
    rho_L = 8.0
    u_L = 8.25 * np.sqrt(3.0) / 2.0
    v_L = -8.25 * 0.5
    p_L = 116.5
    E_L = p_L / (gamma - 1.0) + 0.5 * rho_L * (u_L ** 2 + v_L ** 2)
    U_L = np.array([rho_L, rho_L * u_L, rho_L * v_L, E_L])

    # 状态 R
    rho_R = 1.4
    u_R = 0.0
    v_R = 0.0
    p_R = 1.0
    E_R = p_R / (gamma - 1.0) + 0.5 * rho_R * (u_R ** 2 + v_R ** 2)
    U_R = np.array([rho_R, rho_R * u_R, rho_R * v_R, E_R])

    # 左边界
    for i in range(nghost):
        U_ext[:, :, i] = U_L[:, np.newaxis]

    # 右边界
    for i in range(nghost):
        U_ext[:, :, Nx_ext - nghost + i] = U_ext[:, :, Nx_ext - nghost - 1]

    # 下边界
    for j in range(nghost):
        jj_ghost = nghost - 1 - j
        jj_internal = nghost + j
        U_ext[0, jj_ghost, :] = U_ext[0, jj_internal, :]
        U_ext[1, jj_ghost, :] = U_ext[1, jj_internal, :]
        U_ext[2, jj_ghost, :] = -U_ext[2, jj_internal, :]
        U_ext[3, jj_ghost, :] = U_ext[3, jj_internal, :]

    is_left_of_wall = x_coords_ext < (1.0 / 6.0)
    for j in range(nghost):
        jj_ghost = nghost - 1 - j
        U_ext[:, jj_ghost, is_left_of_wall] = U_L[:, np.newaxis]

    # 上边界
    x_front = (1.0 / 6.0) + (1.0 / np.sqrt(3.0)) + (20.0 / np.sqrt(3.0)) * t
    is_shocked_top = x_coords_ext < x_front

    for j in range(nghost):
        jj_ghost = Ny_ext - nghost + j
        U_ext[:, jj_ghost, is_shocked_top] = U_L[:, np.newaxis]
        U_ext[:, jj_ghost, ~is_shocked_top] = U_R[:, np.newaxis]

    # 全局物理防御
    U_ext[0] = np.maximum(U_ext[0], 1e-10)
    p_ext = (gamma - 1.0) * (U_ext[3] - 0.5 * (U_ext[1] ** 2 + U_ext[2] ** 2) / U_ext[0])
    if np.any(p_ext < 1e-10):
        p_safe = np.maximum(p_ext, 1e-10)
        U_ext[3] = p_safe / (gamma - 1.0) + 0.5 * (U_ext[1] ** 2 + U_ext[2] ** 2) / U_ext[0]

    # 导出核心扫描所需的全场比熵场矩阵
    rho_ext = U_ext[0]
    u_ext = U_ext[1] / rho_ext
    v_ext = U_ext[2] / rho_ext
    E_ext = U_ext[3]
    p_final = (gamma - 1.0) * (E_ext - 0.5 * rho_ext * (u_ext ** 2 + v_ext ** 2))
    entropy_ext = p_final / np.maximum(rho_ext ** gamma, 1e-12)

    return entropy_ext


def load_any_dmr_data(filepath, Nx, Ny):
    """自适应数据读取器：无缝支持 .csv 和 .npz 格式，并解包全部 Euler 守恒量"""
    if not os.path.exists(filepath):
        return None, None, None, None, None, None

    if filepath.endswith('.npz'):
        data = np.load(filepath)
        try:
            X = data['X'].reshape(Ny, Nx, order='C')
            Y = data['Y'].reshape(Ny, Nx, order='C')
            rho = data['rho'].reshape(Ny, Nx, order='C')
            rhou = data['rhou'].reshape(Ny, Nx, order='C')
            rhov = data['rhov'].reshape(Ny, Nx, order='C')
            E = data['E'].reshape(Ny, Nx, order='C')
        except KeyError:
            X = data['X'].reshape(Ny, Nx, order='C')
            Y = data['Y'].reshape(Ny, Nx, order='C')
            rho = data['Density(rho)'].reshape(Ny, Nx, order='C')
            rhou = data['Momentum_X(rho_u)'].reshape(Ny, Nx, order='C')
            rhov = data['Momentum_Y(rho_v)'].reshape(Ny, Nx, order='C')
            E = data['Energy(E)'].reshape(Ny, Nx, order='C')
        return X, Y, rho, rhou, rhov, E
    else:
        df = pd.read_csv(filepath, comment='#')
        X = df["X"].values.reshape(Ny, Nx, order='C')
        Y = df["Y"].values.reshape(Ny, Nx, order='C')
        rho = df["Density(rho)"].values.reshape(Ny, Nx, order='C')
        rhou = df["Momentum_X(rho_u)"].values.reshape(Ny, Nx, order='C')
        rhov = df["Momentum_Y(rho_v)"].values.reshape(Ny, Nx, order='C')
        E = df["Energy(E)"].values.reshape(Ny, Nx, order='C')
        return X, Y, rho, rhou, rhov, E


def load_and_predict_dmr(nx, ny, mlp_model, mlp_device, kxrcf_threshold=1.0, mlp_threshold=0.5):
    """核心扫描函数：读取各方案数据，注入 DMR 标准边界并执行双向间断点识别"""
    nghost = 3
    dx = 4.0 / nx
    dy = 1.0 / ny

    # 动态匹配文件名（包含对 PureWENO5 960档特例的处理）
    mlp_file = f"Weno5MLP_DoubleMach_{nx}x{ny}_results.csv"
    kxrcf_file = f"Weno5KXRCF_DoubleMach_{nx}x{ny}_results.csv"
    # 1. 读取 MLP 物理分支
    X_mesh, Y_mesh, rho_m, rhou_m, rhov_m, E_m = load_any_dmr_data(mlp_file, nx, ny)
    if X_mesh is None:
        print(f"❌ 警告: 未找到 {nx}x{ny} 的对应数据文件，跳过。")
        return None, None, None, None, None, None

    x_coords_in = X_mesh[0, :]  # 提取一维纯内场 X 坐标序列
    U_phys_m = np.stack([rho_m, rhou_m, rhov_m, E_m], axis=0)
    entropy_mlp = apply_DMR_bc(U_phys_m, x_coords_in, t=t_final, gamma=gamma, nghost=nghost)

    # 2. 读取 KXRCF 物理分支
    _, _, rho_k, rhou_k, rhov_k, E_k = load_any_dmr_data(kxrcf_file, nx, ny)
    U_phys_k = np.stack([rho_k, rhou_k, rhov_k, E_k], axis=0)
    entropy_kxrcf = apply_DMR_bc(U_phys_k, x_coords_in, t=t_final, gamma=gamma, nghost=nghost)

    mask_mlp_x = np.zeros((ny, nx), dtype=bool)
    mask_mlp_y = np.zeros((ny, nx), dtype=bool)
    mask_kxrcf_x = np.zeros((ny, nx), dtype=bool)
    mask_kxrcf_y = np.zeros((ny, nx), dtype=bool)

    # 🛠️ 扫描轴 1: X 方向扫描
    for j in range(ny):
        jj = j + nghost
        entropy_slice_x_full_m = entropy_mlp[jj, :]
        prob_array_x_m = predict_2d(entropy_slice_x_full_m, dx, mlp_model, mlp_device)
        prob_x_m = np.where(prob_array_x_m > mlp_threshold, 1.0, 0.0)
        for i in range(nx):
            if prob_x_m[i] == 0.0:
                mask_mlp_x[j, i] = True

        for i in range(nx):
            idx_ext = i + nghost
            u0_l = (entropy_kxrcf[jj, idx_ext - 2] + 22 * entropy_kxrcf[jj, idx_ext - 1] + entropy_kxrcf[jj, idx_ext]) / 24.0
            u1_l = (entropy_kxrcf[jj, idx_ext] - entropy_kxrcf[jj, idx_ext - 2]) / 2.0
            u2_l = (entropy_kxrcf[jj, idx_ext - 2] - 2 * entropy_kxrcf[jj, idx_ext - 1] + entropy_kxrcf[jj, idx_ext]) / 2.0

            u0_c = (entropy_kxrcf[jj, idx_ext - 1] + 22 * entropy_kxrcf[jj, idx_ext] + entropy_kxrcf[jj, idx_ext + 1]) / 24.0
            u1_c = (entropy_kxrcf[jj, idx_ext + 1] - entropy_kxrcf[jj, idx_ext - 1]) / 2.0
            u2_c = (entropy_kxrcf[jj, idx_ext - 1] - 2 * entropy_kxrcf[jj, idx_ext] + entropy_kxrcf[jj, idx_ext + 1]) / 24.0

            u0_r = (entropy_kxrcf[jj, idx_ext] + 22 * entropy_kxrcf[jj, idx_ext + 1] + entropy_kxrcf[jj, idx_ext + 2]) / 24.0
            u1_r = (entropy_kxrcf[jj, idx_ext + 2] - entropy_kxrcf[jj, idx_ext]) / 2.0
            u2_r = (entropy_kxrcf[jj, idx_ext] - 2 * entropy_kxrcf[jj, idx_ext + 1] + entropy_kxrcf[jj, idx_ext + 2]) / 2.0

            edge_R_of_L = u0_l + 0.5 * u1_l + (1.0 / 6.0) * u2_l
            edge_L_of_C = u0_c - 0.5 * u1_c + (1.0 / 6.0) * u2_c
            edge_R_of_C = u0_c + 0.5 * u1_c + (1.0 / 6.0) * u2_c
            edge_L_of_R = u0_r - 0.5 * u1_r + (1.0 / 6.0) * u2_r

            max_jump = np.max([np.abs(edge_L_of_C - edge_R_of_L), np.abs(edge_L_of_R - edge_R_of_C)])
            denominator = (dx ** 2.5) * (np.abs(entropy_kxrcf[jj, idx_ext]) + 1e-10)

            if (max_jump / denominator) > kxrcf_threshold:
                mask_kxrcf_x[j, i] = True

    # 🛠️ 扫描轴 2: Y 方向扫描
    for i in range(nx):
        ii = i + nghost
        entropy_slice_y_full_m = entropy_mlp[:, ii]
        prob_array_y_m = predict_2d(entropy_slice_y_full_m, dy, mlp_model, mlp_device)
        prob_y_m = np.where(prob_array_y_m > mlp_threshold, 1.0, 0.0)
        for j in range(ny):
            if prob_y_m[j] == 0.0:
                mask_mlp_y[j, i] = True

        for j in range(ny):
            idx_ext = j + nghost
            u0_l = (entropy_kxrcf[idx_ext - 2, ii] + 22 * entropy_kxrcf[idx_ext - 1, ii] + entropy_kxrcf[idx_ext, ii]) / 24.0
            u1_l = (entropy_kxrcf[idx_ext, ii] - entropy_kxrcf[idx_ext - 2, ii]) / 2.0
            u2_l = (entropy_kxrcf[idx_ext - 2, ii] - 2 * entropy_kxrcf[idx_ext - 1, ii] + entropy_kxrcf[idx_ext, ii]) / 2.0

            u0_c = (entropy_kxrcf[idx_ext - 1, ii] + 22 * entropy_kxrcf[idx_ext, ii] + entropy_kxrcf[idx_ext + 1, ii]) / 24.0
            u1_c = (entropy_kxrcf[idx_ext + 1, ii] - entropy_kxrcf[idx_ext - 1, ii]) / 2.0
            u2_c = (entropy_kxrcf[idx_ext - 1, ii] - 2 * entropy_kxrcf[idx_ext, ii] + entropy_kxrcf[idx_ext + 1, ii]) / 2.0

            u0_r = (entropy_kxrcf[idx_ext, ii] + 22 * entropy_kxrcf[idx_ext + 1, ii] + entropy_kxrcf[idx_ext + 2, ii]) / 24.0
            u1_r = (entropy_kxrcf[idx_ext + 2, ii] - entropy_kxrcf[idx_ext, ii]) / 2.0
            u2_r = (entropy_kxrcf[idx_ext, ii] - 2 * entropy_kxrcf[idx_ext + 1, ii] + entropy_kxrcf[idx_ext + 2, ii]) / 24.0

            edge_R_of_L = u0_l + 0.5 * u1_l + (1.0 / 6.0) * u2_l
            edge_L_of_C = u0_c - 0.5 * u1_c + (1.0 / 6.0) * u2_c
            edge_R_of_C = u0_c + 0.5 * u1_c + (1.0 / 6.0) * u2_c
            edge_L_of_R = u0_r - 0.5 * u1_r + (1.0 / 6.0) * u2_r

            max_jump = np.max([np.abs(edge_L_of_C - edge_R_of_L), np.abs(edge_L_of_R - edge_R_of_C)])
            denominator = (dy ** 2.5) * (np.abs(entropy_kxrcf[idx_ext, ii]) + 1e-10)

            if (max_jump / denominator) > kxrcf_threshold:
                mask_kxrcf_y[j, i] = True

    print(f"   📊 网格 {nx}x{ny:<3} DMR比熵扫描完毕 | MLP [X:{np.sum(mask_mlp_x):<4} Y:{np.sum(mask_mlp_y):<4}] | KXRCF [X:{np.sum(mask_kxrcf_x):<4} Y:{np.sum(mask_kxrcf_y):<4}]")
    return X_mesh, Y_mesh, mask_mlp_x, mask_mlp_y, mask_kxrcf_x, mask_kxrcf_y


def main():
    resolution_pairs = [(240, 60), (480, 120), (960, 240)]

    col_configs = [
        ('MLP', 2, 'X Direction'),    # Col 1
        ('KXRCF', 4, 'X Direction'),  # Col 2
        ('MLP', 3, 'Y Direction'),    # Col 3
        ('KXRCF', 5, 'Y Direction')   # Col 4
    ]

    mlp_model, mlp_device = get_model()
    sub_indices = [f"({chr(97 + i)})" for i in range(12)]

    print(fr"====== 🚀 正在启动 2D Double Mach Reflection 间断探测多轴汇总图生成 ======")

    data_cache = {}
    for nx, ny in resolution_pairs:
        res = load_and_predict_dmr(nx, ny, mlp_model, mlp_device, kxrcf_threshold=1.0, mlp_threshold=0.5)
        if res[0] is not None:
            data_cache[(nx, ny)] = res

    print("========================================================================\n")

    stats_summary = []

    # 🛠️ 画布微调：因为 DMR 图像由高瘦(RT)变成了横宽型（3:1 比率），我们将 3x4 子图大图尺寸改为宽 38，高 16.5
    fig, axes = plt.subplots(3, 4, figsize=(38, 16.5))

    for row_idx, (nx, ny) in enumerate(resolution_pairs):
        if (nx, ny) not in data_cache:
            continue
        row_data = data_cache[(nx, ny)]

        X_flat = row_data[0].flatten()
        Y_flat = row_data[1].flatten()

        for col_idx, (method, data_idx, dir_name) in enumerate(col_configs):
            ax = axes[row_idx, col_idx]
            current_mask_flat = row_data[data_idx].flatten()

            total_points = nx * ny
            troubled_points = np.sum(current_mask_flat)
            percentage = (troubled_points / total_points) * 100

            stats_summary.append({
                "Resolution": f"{nx}x{ny}",
                "Method": method,
                "Direction": dir_name,
                "Troubled_Count": troubled_points,
                "Total_Count": total_points,
                "Ratio_Pct": percentage
            })

            # 动态调整标记大小，高分辨率网格用更密集的粒子点展现高保真激波边缘
            marker_size = 8.0 if nx <= 240 else (3.0 if nx <= 480 else 0.5)

            ax.scatter(X_flat[current_mask_flat], Y_flat[current_mask_flat],
                       s=marker_size, c='red', marker='s', edgecolors='none')

            ax.set_aspect('equal')
            # 严格截断显示区域为 X 轴 [0.0, 3.0]，Y 轴 [0.0, 1.0]
            ax.set_xlim(0.0, 3.0)
            ax.set_ylim(0.0, 1.0)
            ax.set_xticks([0.0, 1.0, 2.0, 3.0])
            ax.set_yticks([0.0, 0.5, 1.0])

            ax.tick_params(axis='both', which='major', direction='in', top=True, right=True, length=5, labelsize=36, pad=6)
            ax.set_xlabel('X', fontsize=40, labelpad=4)

            if col_idx == 0:
                ax.set_ylabel('Y', fontsize=40, labelpad=4)
            else:
                ax.tick_params(axis='y', labelleft=False)

            # 🛠️ 【精密双行小标题渲染】：包含要求的直体带下标级 LaTeX 公式排版
            flat_idx = row_idx * 4 + col_idx
            line1 = fr"{sub_indices[flat_idx]} {method}"
            line2 = fr"{dir_name} ($\mathrm{{N}}_x \times \mathrm{{N}}_y = {nx} \times {ny}$)"
            full_title_two_lines = f"{line1}\n{line2}"

            # y=-0.42 确保绝不与大号的 X 轴标签重合，自上而下对齐
            ax.text(0.5, -0.42, transform=ax.transAxes, s=full_title_two_lines,
                    fontsize=30, va='top', ha='center', linespacing=1.2)

    # 🟢 终端输出量化对比分析报表
    print("\n" + "=" * 80)
    print(f"{'2D Double Mach Reflection 间断点探测百分比量化统计表':^72}")
    print("=" * 80)
    print(f"{'网格规模':<12} | {'探测算子':<8} | {'扫描方向':<14} | {'间断点数':<10} | {'总网格数':<10} | {'占比 (Ratio)'}")
    print("-" * 80)
    for item in stats_summary:
        print(f"{item['Resolution']:<12} | {item['Method']:<8} | {item['Direction']:<14} | {item['Troubled_Count']:<10} | {item['Total_Count']:<10} | {item['Ratio_Pct']:.4f}%")
    print("=" * 80 + "\n")

    # 极宽幅流场专门预留的紧凑留白比例
    plt.tight_layout(rect=[0.02, 0.05, 0.98, 0.98])
    plt.subplots_adjust(wspace=0.12, hspace=0.65)  # 适当放大行距，留足空间展示双行复杂学术小标题

    output_pdf = "DMR_Discontinuity.pdf"
    plt.savefig(output_pdf, dpi=300, bbox_inches='tight')
    print(f"📊 3x4 DMR 综合大图（完美集成用户边界、X 截断显示与 LaTeX 标题）已成功保存至: {output_pdf}")
    plt.show()


if __name__ == "__main__":
    main()