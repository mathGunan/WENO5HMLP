import numpy as np

def double_mach_IC(Xc, Yc):
    """
    双马赫反射问题初始条件
    输入:
        Xc, Yc: 网格中心坐标数组，形状 (Ny, Nx)
    输出:
        U: 守恒量矩阵, shape (4, Ny, Nx)
    """
    GAMMA = 1.4
    Ny, Nx = Xc.shape

    # 初始化数组
    rho = np.zeros((Ny, Nx))
    u = np.zeros((Ny, Nx))
    v = np.zeros((Ny, Nx))
    p = np.zeros((Ny, Nx))

    # 双马赫反射初始条件：斜激波
    # 激波位置: x = 1/6 + y/sqrt(3)
    shock_position = 1.0 / 6.0 + Yc / np.sqrt(3.0)

    # 激波前状态 (右侧)
    rho_pre, u_pre, v_pre, p_pre = 1.4, 0.0, 0.0, 1.0

    # 激波后状态 (左侧) - 根据Rankine-Hugoniot条件计算
    rho_post = 8.0
    u_post = 8.25 * np.cos(np.pi / 6.0)  # 8.25 * cos(30°)
    v_post = -8.25 * np.sin(np.pi / 6.0)  # 8.25 * sin(30°)，向下
    p_post = 116.5

    # 根据激波位置设置初始条件
    for j in range(Ny):
        for i in range(Nx):
            if Xc[j, i] < shock_position[j, i]:
                # 激波后区域
                rho[j, i] = rho_post
                u[j, i] = u_post
                v[j, i] = v_post
                p[j, i] = p_post
            else:
                # 激波前区域
                rho[j, i] = rho_pre
                u[j, i] = u_pre
                v[j, i] = v_pre
                p[j, i] = p_pre

    # 转换为守恒量
    E = p / (GAMMA - 1.0) + 0.5 * rho * (u ** 2 + v ** 2)
    U = np.array([rho, rho * u, rho * v, E])

    return U
