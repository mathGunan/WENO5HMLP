import numpy as np
import matplotlib.pyplot as plt

# 1. 直接用 numpy 读取 CSV 文件（自动跳过前两行：1行注释，1行表头）
# delimiter=',' 表示用逗号分隔
data = np.loadtxt("Weno5MLP_DoubleMach_120x30_results.csv", delimiter=",", skiprows=2)

# 2. 根据我们在主程序里写入的顺序，直接按列的下标切片：
# 顺序是：0:X, 1:Y, 2:Density(rho), 3:Momentum_X, 4:Momentum_Y, 5:Energy
Y_flat = data[:, 1]
rho_flat = data[:, 2]

# 3. 自动计算 y 方向网格数并重构为二维矩阵
Ny = len(np.unique(Y_flat))
rho_mat = rho_flat.reshape((Ny, -1))

# 4. 最简彩色流场出图
plt.figure(figsize=(10, 3))
plt.imshow(rho_mat, origin='lower', cmap='jet', aspect='auto')
plt.colorbar(label="Density")
plt.title("Double Mach Reflection - Density")
plt.show()