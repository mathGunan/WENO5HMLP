import numpy as np
import matplotlib.pyplot as plt

# ------------------------
# 读取结果
# ------------------------

npz_filename="Weno5MLP2DEulerRiemann_100x100_results.npz"
data = np.load(npz_filename)
rho = data['rho']  # 内部网格密度 (Ny, Nx)
print(f"密度数组形状: {rho.shape}")
print(f"密度最小值: {np.min(rho):.6f}")
print(f"密度最大值: {np.max(rho):.6f}")

# ------------------------
# 网格坐标
# ------------------------
N=100
Lx = Ly = 1.0
dx = Lx / N
dy = Ly / N
x = np.linspace(dx/2, Lx-dx/2, N)
y = np.linspace(dy/2, Ly-dy/2, N)
X, Y = np.meshgrid(x, y, indexing='xy')

# ------------------------
# 绘图
# ------------------------
plt.figure(figsize=(8,8))

# 选择适合的颜色等级
levels = np.linspace(0.25, 3.05, 29)
# 先绘制颜色填充
cf = plt.contourf(X, Y, rho, levels=levels, cmap= 'viridis')
# 再绘制等值线（在颜色填充之上）
contour_lines = plt.contour(X, Y, rho, levels=levels, colors='black', linewidths=1.0, alpha=0.9)

# 设置坐标刻度
xticks = [0.35,0.5,0.65]
yticks = [0.35,0.5,0.65]
plt.xticks(xticks)
plt.yticks(yticks)


plt.xlim(0.35, 0.65)
plt.ylim(0.35, 0.65)

# 显示上边界和右边界的坐标
# 显示所有边界并设置刻度位置
ax = plt.gca()
ax.spines['top'].set_visible(True)
ax.spines['right'].set_visible(True)
ax.spines['bottom'].set_visible(True)
ax.spines['left'].set_visible(True)
# 在上边界和右边界显示刻度标签
ax.xaxis.set_ticks_position('both')  # 在顶部和底部都显示刻度
ax.yaxis.set_ticks_position('both')  # 在左侧和右侧都显示刻度
ax.tick_params(which='both', direction='in', top=True, right=True,
               labeltop=True, labelright=True)
ax.xaxis.set_major_formatter(plt.FormatStrFormatter('%g'))
ax.yaxis.set_major_formatter(plt.FormatStrFormatter('%g'))


plt.tight_layout()
plt.savefig(f'MLP{N}.pdf',dpi=600)
plt.show()
