import csv
import time
import numpy as np
from RK3 import SolverKXRCFRk3  # 严格导入您的 KXRCF 判定版 RK3 推进器
from IC import *
from helperfunction import *

gamma = 1.4


def compute_single_run(N, T_final=0.3):
    """
    单次网格规模的 Riemann-2 问题计算算子（基于一维标量比熵 KXRCF 探测器）
    """
    nx = ny = N
    Lx = Ly = 1.0
    dx = Lx / nx
    dy = Ly / ny

    # 网格中心坐标
    x = np.linspace(dx / 2, Lx - dx / 2, nx)
    y = np.linspace(dy / 2, Ly - dy / 2, ny)
    Xc, Yc = np.meshgrid(x, y, indexing='xy')

    # 初始条件（加载 Riemann-2 物理流场状态）
    U = riemann_IC(Xc, Yc)  # shape (4, ny, nx)

    # 时间推进
    t = 0.0
    iteration = 0

    start_time = time.time()

    while t < T_final:
        # 严格保持您的步长计算逻辑
        dt = compute_time_step(U, dx, dy)

        if t + dt > T_final:
            dt = T_final - t

        # 【严格关键字对齐】：严格对应您 SolverKXRCFRk3 的参数列表
        U = SolverKXRCFRk3(
            U_phys=U,
            dx=dx,
            dy=dy,
            dt=dt,
            gamma=gamma,
            threshold=1.0,  # 对齐一维经典学术阈值 1.0
            nghost=3,
            epsilon=1e-6
        )
        t += dt
        iteration += 1

        # 仅在每 50 步迭代时执行一次高效的进度输出，防止大网格 IO 阻塞
        if iteration % 50 == 0:
            progress = (t / T_final) * 100
            print(f"N={N}: 进度 {progress:.1f}%, 迭代 {iteration}, 物理时间 t={t:.4f}")

    cpu_time = time.time() - start_time
    print(f"网格规模 {N}x{N} (WENO5-KXRCF Riemann-2) 计算完毕，总耗时: {cpu_time:.4f} 秒")

    return Xc, Yc, U, cpu_time


def main():
    print("====================================================")
    print("  开启 2D Euler (WENO5KXRCF + Roe) Riemann-2 问题常态化计算  ")
    print("====================================================")

    N = 125  # 逐步推向大规模网格，目标 1000*1000
    T_final = 0.3

    # 执行仿真计算
    Xc, Yc, U_final, cpu_time = compute_single_run(N, T_final=T_final)

    # 提取最后时刻的 4 个完整守恒量分量
    rho_num = U_final[0, :, :]
    rhou_num = U_final[1, :, :]
    rhov_num = U_final[2, :, :]
    E_num = U_final[3, :, :]

    # 将二维空间网格及流场展平为一维列，以便标准 CSV 表格化存储
    x_flat = Xc.flatten()
    y_flat = Yc.flatten()
    rho_flat = rho_num.flatten()
    rhou_flat = rhou_num.flatten()
    rhov_flat = rhov_num.flatten()
    E_flat = E_num.flatten()

    # 规范化 CSV 命名，清晰标记为 Riemann2 问题与 KXRCF 方法
    csv_filename = f"Weno5KXRCF2DEuler_Riemann2_{N}x{N}_results.csv"

    with open(csv_filename, mode='w', newline='', encoding='utf-8') as f:
        writer = csv.writer(f)

        # 1. 在 CSV 头部写入全局元数据（保留总 CPU 时间）
        writer.writerow(["# Global Metadata", f"Total_CPU_Time_Seconds: {cpu_time:.6f}"])

        # 2. 写入标准的【守恒量】列标题
        writer.writerow(["X", "Y", "Density(rho)", "Momentum_X(rho_u)", "Momentum_Y(rho_v)", "Energy(E)"])

        # 3. 逐行写入流场各网格点上的位置与守恒量分量
        for i in range(len(x_flat)):
            writer.writerow([
                f"{x_flat[i]:.6e}",
                f"{y_flat[i]:.6e}",
                f"{rho_flat[i]:.6e}",
                f"{rhou_flat[i]:.6e}",
                f"{rhov_flat[i]:.6e}",
                f"{E_flat[i]:.6e}"
            ])

    print("----------------------------------------------------")
    print(f"WENO5-KXRCF Riemann-2 流场数据保存完毕。最终 CSV 路径: {csv_filename}")
    print("====================================================")


if __name__ == "__main__":
    main()