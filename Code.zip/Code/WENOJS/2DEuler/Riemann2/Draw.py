import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

'''
Joint Post-process for 2D Euler Riemann-2 Equation: 3x3 子图联合局部二维等高线填充图
区域限制: X 轴 [0.35, 0.65] | Y 轴 [0.35, 0.65]
横向对比: Column 1 (WENO5), Column 2 (KXRCF), Column 3 (MLP)
纵向对比: Row 1 (N=125), Row 2 (N=250), Row 3 (N=500)
特色：颜色填充 (contourf) 底色 + 极细黑线 (contour) 勾勒流场结构
'''


def load_csv_data(filepath, N, x_min_roi=0.35, x_max_roi=0.65, y_min_roi=0.35, y_max_roi=0.65):
    """
    高效读取 CSV 数据，并将展平的数据重构为二维矩阵。
    同步返回指定局部区域 (ROI) 内的局部极值。
    """
    if not os.path.exists(filepath):
        print(f"❌ 警告: 未找到文件 {filepath}")
        return None, None, None, None, None

    skip_rows = 0
    with open(filepath, 'r', encoding='utf-8') as f:
        for line in f:
            if line.startswith('#'):
                skip_rows += 1
            else:
                break

    df = pd.read_csv(filepath, skiprows=skip_rows)

    # 重构为 (N, N) 空间矩阵
    X = df['X'].values.reshape(N, N)
    Y = df['Y'].values.reshape(N, N)
    rho = df['Density(rho)'].values.reshape(N, N)

    # 过滤出局部区域的掩码，用于精准计算区域内的极值
    roi_mask = (X >= x_min_roi) & (X <= x_max_roi) & (Y >= y_min_roi) & (Y <= y_max_roi)

    if np.any(roi_mask):
        rho_min_roi = rho[roi_mask].min()
        rho_max_roi = rho[roi_mask].max()
    else:
        rho_min_roi, rho_max_roi = rho.min(), rho.max()

    return X, Y, rho, rho_min_roi, rho_max_roi


def main():
    # 设定学术期刊高分辨率出版标准
    plt.rcParams.update({
        'text.usetex': False
    })

    row_resolutions = [125, 250, 500]

    # 列（Columns）：包含绘制所需的标签、文件名模板
    col_schemes = [
        {'key': 'PureWENO5', 'label': 'WENO5', 'template': "PureWENO5_2DEuler_Riemann2_{N}x{N}_results.csv"},
        {'key': 'Weno5KXRCF', 'label': 'KXRCF', 'template': "Weno5KXRCF2DEuler_Riemann2_{N}x{N}_results.csv"},
        {'key': 'Weno5MLP', 'label': 'MLP', 'template': "Weno5MLP2DEuler_Riemann2_{N}x{N}_results.csv"}
    ]

    # 自动化生成学术子图序号 ['(a)', '(b)', ..., '(i)']
    sub_indices = [f"({chr(97 + i)})" for i in range(9)]

    # 设定您要求的坐标轴限制范围
    xmin, xmax = 0.35, 0.65
    ymin, ymax = 0.35, 0.65

    print(f"====== 🚀 正在扫描 [{xmin}, {xmax}] 局部区域内的 2D Euler 密度极值 ======")

    # 1. 第一遍预加载：仅扫描并输出该局部区域内的极值，方便手动控标
    data_cache = {}
    for N in row_resolutions:
        for col_idx, scheme in enumerate(col_schemes):
            filename = scheme['template'].format(N=N)
            X, Y, rho, r_min, r_max = load_csv_data(filename, N, xmin, xmax, ymin, ymax)
            data_cache[(N, col_idx)] = (X, Y, rho)
            if rho is not None:
                print(
                    f"   📊 网格 [{N}x{N:<3}] | 格式 [{scheme['label']:<5}] -> 局部 rho_min = {r_min:9.6f} | 局部 rho_max = {r_max:9.6f}")

    print("=========================================================================\n")

    # =========================================================================
    # 🟢 【核心手动控标区】：请参考上面打印的局部极值，调整填充和线条的等高线层级
    # =========================================================================
    global_levels = np.linspace(0.14, 3.07, 40)  # 填充图可以适当增加级数，让过渡更平滑
    cmap_choice = 'viridis'

    # 调整总画布比例为 30x31，预留出底部大尺寸小标题空间
    fig, axes = plt.subplots(3, 3, figsize=(30, 31))

    # 遍历 3x3 矩阵开始绘制
    for row_idx, N in enumerate(row_resolutions):
        for col_idx, scheme in enumerate(col_schemes):
            ax = axes[row_idx, col_idx]
            X, Y, rho = data_cache[(N, col_idx)]

            if rho is not None:
                # 稍微扩展网格几何边界，防止 contourf 在局部边界切割时出现局部白边
                X_filled = np.clip(X, xmin, xmax)
                Y_filled = np.clip(Y, ymin, ymax)

                # Step 1: 连续颜色填充底色
                cf = ax.contourf(X_filled, Y_filled, rho,
                                 levels=global_levels,
                                 cmap=cmap_choice,
                                 extend='both')

                # Step 2: 极细黑色轮廓线叠加，增强流场波系不连续性的空间辨识度
                ax.contour(X, Y, rho,
                           levels=global_levels,
                           colors='black',
                           linewidths=0.4,
                           alpha=0.8)
            else:
                ax.text(0.5, 0.5, f'Data Missing\n{scheme["label"]}\nN = {N}',
                        ha='center', va='center', fontsize=24, color='red')
                ax.set_xlim(xmin, xmax)
                ax.set_ylim(ymin, ymax)
                continue

            # 保持物理长宽比 1:1
            ax.set_aspect('equal')
            ax.grid(True, linestyle=':', alpha=0.2, color='white')  # 填充图建议用白色或微弱网格线

            # =========================================================================
            # 【极致刻度与基本几何界限设置】 限制到 [0.35, 0.65] 局部区间
            # =========================================================================
            ax.set_xlim(xmin, xmax)
            ax.set_ylim(ymin, ymax)
            ax.set_xticks([0.4, 0.6])
            ax.set_yticks([0.4, 0.6])

            # =========================================================================
            # 【精确控标：X 轴全开，Y 轴仅第一列有标签数字】
            # =========================================================================
            # 1. X 轴配置：所有子图全面显示 X 轴刻度大数字和标签
            ax.tick_params(axis='x', direction='in', top=True, right=True,
                           length=5, width=1.0, labelsize=38, pad=20)
            ax.set_xlabel('X', fontsize=45, labelpad=18)

            # 2. Y 轴配置：只有第一列（col_idx == 0）才有数字和 ylabel，其余完全隐去
            if col_idx == 0:
                ax.set_ylabel('Y', fontsize=45, labelpad=15)
                ax.tick_params(axis='y', direction='in', top=True, right=True,
                               length=5, width=1.0, labelsize=38, pad=20)
            else:
                # 非第一列图，内部朝内的刻度线保留（学术规范），但隐藏数字
                ax.tick_params(axis='y', direction='in', top=True, right=True,
                               length=5, width=1.0, labelleft=False)

            # =========================================================================
            # 🟢 【子图正下方小标题精密定位（整合方法名与显式二维网格）】
            # =========================================================================
            flat_idx = row_idx * 3 + col_idx
            full_title = fr"{sub_indices[flat_idx]} {scheme['label']} ($\mathrm{{N}}_x=\mathrm{{N}}_y={N}$)"

            # 沿用控制间距下的标题高度
            title_y_position = -0.32
            ax.text(0.5, title_y_position, full_title, transform=ax.transAxes,
                    fontsize=45, va='top', ha='center')

    # =========================================================================
    # 【大图压缩留白区】：强制压缩 padding，将空间完美让渡给绘图域
    # =========================================================================
    plt.tight_layout(rect=[0.04, 0.04, 0.96, 0.97], h_pad=3.5, w_pad=3.0)

    output_pdf = "2DEuler_Riemann2_compare.pdf"
    plt.savefig(output_pdf, dpi=300)
    print(f"\n📊 [绘图成功] 局部缩放后的 3x3 颜色填充 Euler Riemann-2 图像已成功导出至: {output_pdf}")
    plt.show()


if __name__ == "__main__":
    main()