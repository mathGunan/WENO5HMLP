import pandas as pd
import numpy as np

# 读取 CSV 文件
df = pd.read_csv('Weno5KXRCFFDM2DEuler_results.csv')

# 提取误差列（用原始值计算，不四舍五入）
L1_err = df['L1_Error'].values
L2_err = df['L2_Error'].values
Linf_err = df['Linf_Error'].values

# 计算精度阶的函数
def compute_orders(errors):
    """计算精度阶，第一行返回 '--'，后续行用公式 Order = ln(E_N / E_2N) / ln(2)"""
    orders = ['--'] * len(errors)
    for i in range(len(errors) - 1):
        # 防止除以零或负数
        if errors[i] > 0 and errors[i+1] > 0:
            order = np.log(errors[i] / errors[i+1]) / np.log(2)
            orders[i+1] = round(order, 4)  # 保留四位小数
        else:
            orders[i+1] = '--'
    return orders

# 重新计算三种精度阶
df['L1_Order'] = compute_orders(L1_err)
df['L2_Order'] = compute_orders(L2_err)
df['Linf_Order'] = compute_orders(Linf_err)

# 保存覆盖原文件（或另存为新文件）
df.to_csv('Weno5KXRCFFDM2DEuler_results_updated.csv', index=False)

# 打印结果查看
print(df.to_string())