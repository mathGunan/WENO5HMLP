import torch
import numpy as np
from model import  *
gamma=1.4

# ==================== 全局模型定义 ====================
model = None
device = None
def get_model():
    global model, device
    if model is None:
        if torch.backends.mps.is_available():
            device = torch.device("mps")
            print("使用MPS设备")
        else:
            device = torch.device("cpu")
            print("使用CPU设备")
        ckpt = torch.load('best_model.pth',
                          map_location=device)
        model = Weno5FDMMLP().to(device)
        model.load_state_dict(ckpt['model_state_dict'])
        model.eval()
        print("模型加载完成")
    return model, device
# ==================== 全局模型定义结束 ====================


def predict_2d(entropy_stencil_1d, d_space, model, device):
    """
    接口级别预测 trouble 点概率（针对二维 Euler 方程中提取出来的一维特征切片）
    完美匹配您原有模型 4 个特征的输入（betaA, betaM, Tau5, d_space），完全不省略任何细节。

    参数:
        entropy_stencil_1d: ndarray, shape (M_ext,)
                            从二维流场中提取出来的 X 方向或 Y 方向的一维物理熵标量切片。
                            由于两侧各包含 3 层 ghost cells (nghost=3)，
                            若为 X 方向切片，M_ext = Nx + 6
                            若为 Y 方向切片，M_ext = Ny + 6
        d_space           : 空间网格间距 (X 方向传入 dx, Y 方向传入 dy)
        model             : 已训练的 MLP 模型（输入维度为 4）
        device            : torch.device
    返回:
        prob_output       : ndarray, shape (M_ext - 4,)
                            即返回长度为 Nx + 2 (或 Ny + 2) 的判定概率一维数组，
                            完美契合右端项数值通量内部遍历所需的索引边界。
    """
    M_ext = entropy_stencil_1d.shape[0]
    # 根据您之前一维代码完美的索引映射逻辑：
    # 一维时：N = M_ext - 6，构造大小为 (N + 2, 4) 即 (M_ext - 4, 4) 的矩阵
    # 这样生成的概率数组长度恰好为 M_ext - 4
    # 当传入 Nx + 6 时，返回 Nx + 2；当传入 Ny + 6 时，返回 Ny + 2。
    out_size = M_ext - 4

    # 构造特征输入矩阵，大小为 (out_size, 4)
    input_arrays = np.zeros((out_size, 4), dtype=np.float32)

    # 遍历空间位置（保持您原本完美的五点模板重构索引范围映射：从 2 开始 到 out_size + 2）
    for i in range(2, out_size + 2):
        # 基于物理熵的一维五点 stencil [i-2, i-1, i, i+1, i+2]
        stencil = entropy_stencil_1d[i - 2: i + 3]

        # 经典五阶 WENO 空间光滑指标计算 (100% 完整展开，不含任何省略)
        beta0 = (13.0 * (stencil[2] - 2.0 * stencil[3] + stencil[4]) ** 2 + 3.0 * (
                    3.0 * stencil[2] - 4.0 * stencil[3] + stencil[4]) ** 2) / 12.0
        beta1 = (13.0 * (stencil[1] - 2.0 * stencil[2] + stencil[3]) ** 2 + 3.0 * (stencil[1] - stencil[3]) ** 2) / 12.0
        beta2 = (13.0 * (stencil[0] - 2.0 * stencil[1] + stencil[2]) ** 2 + 3.0 * (
                    stencil[0] - 4.0 * stencil[1] + 3.0 * stencil[2]) ** 2) / 12.0

        betaA = min(beta0, beta1, beta2)
        betaM = (beta0 + beta1 + beta2) / 3.0
        Tau5 = abs(beta0 - beta2)

        # 写入该位置对应的特征向量行
        input_arrays[i - 2] = [betaA, betaM, Tau5, d_space]

    # 将特征矩阵转换为 PyTorch 张量并送入计算设备
    input_tensor = torch.from_numpy(input_arrays).to(device)

    with torch.no_grad():
        # 模型前向推理预测概率，通过 flatten() 压缩为一维形状 (out_size,)
        prob_output = model(input_tensor).cpu().numpy().flatten()

    return prob_output



def get_KXRCF_prob_matrices(U_ext, dx, dy, gamma, threshold, nghost):
    rho = np.maximum(U_ext[0], 1e-14)
    p = np.maximum((gamma - 1.0) * (U_ext[3] - 0.5 * (U_ext[1] ** 2 + U_ext[2] ** 2) / rho), 1e-14)
    entropy = p / np.maximum(rho ** gamma, 1e-12)

    Ny = U_ext.shape[1] - 2 * nghost
    Nx = U_ext.shape[2] - 2 * nghost

    prob_x = np.zeros((Ny, Nx + 2), dtype=np.float32)
    prob_y = np.zeros((Ny + 2, Nx), dtype=np.float32)

    for j in range(Ny):
        jj = j + nghost
        for i in range(Nx + 2):
            idx_ext = i + (nghost - 1)
            u0_c = (entropy[jj, idx_ext - 1] + 22 * entropy[jj, idx_ext] + entropy[jj, idx_ext + 1]) / 24.0
            u1_c = (entropy[jj, idx_ext + 1] - entropy[jj, idx_ext - 1]) / 2.0
            u2_c = (entropy[jj, idx_ext - 1] - 2 * entropy[jj, idx_ext] + entropy[jj, idx_ext + 1]) / 2.0

            u0_l = (entropy[jj, idx_ext - 2] + 22 * entropy[jj, idx_ext - 1] + entropy[jj, idx_ext]) / 24.0
            u1_l = (entropy[jj, idx_ext] - entropy[jj, idx_ext - 2]) / 2.0
            u2_l = (entropy[jj, idx_ext - 2] - 2 * entropy[jj, idx_ext - 1] + entropy[jj, idx_ext]) / 2.0

            u0_r = (entropy[jj, idx_ext] + 22 * entropy[jj, idx_ext + 1] + entropy[jj, idx_ext + 2]) / 24.0
            u1_r = (entropy[jj, idx_ext + 2] - entropy[jj, idx_ext]) / 2.0
            u2_r = (entropy[jj, idx_ext] - 2 * entropy[jj, idx_ext + 1] + entropy[jj, idx_ext + 2]) / 2.0

            edge_R_of_L = u0_l + 0.5 * u1_l + (1.0 / 6.0) * u2_l
            edge_L_of_C = u0_c - 0.5 * u1_c + (1.0 / 6.0) * u2_c
            edge_R_of_C = u0_c + 0.5 * u1_c + (1.0 / 6.0) * u2_c
            edge_L_of_R = u0_r - 0.5 * u1_r + (1.0 / 6.0) * u2_r

            max_jump = np.max([np.abs(edge_L_of_C - edge_R_of_L), np.abs(edge_L_of_R - edge_R_of_C)])
            denominator = (dx ** 2.5) * (np.abs(entropy[jj, idx_ext]) + 1e-10)
            prob_x[j, i] = 1.0 if (max_jump / denominator) <= threshold else 0.0

    for i in range(Nx):
        ii = i + nghost
        for j in range(Ny + 2):
            idx_ext = j + (nghost - 1)
            u0_c = (entropy[idx_ext - 1, ii] + 22 * entropy[idx_ext, ii] + entropy[idx_ext + 1, ii]) / 24.0
            u1_c = (entropy[idx_ext + 1, ii] - entropy[idx_ext - 1, ii]) / 2.0
            u2_c = (entropy[idx_ext - 1, ii] - 2 * entropy[idx_ext, ii] + entropy[idx_ext + 1, ii]) / 2.0

            u0_l = (entropy[idx_ext - 2, ii] + 22 * entropy[idx_ext - 1, ii] + entropy[idx_ext, ii]) / 24.0
            u1_l = (entropy[idx_ext, ii] - entropy[idx_ext - 2, ii]) / 2.0
            u2_l = (entropy[idx_ext - 2, ii] - 2 * entropy[idx_ext - 1, ii] + entropy[idx_ext, ii]) / 2.0

            u0_r = (entropy[idx_ext, ii] + 22 * entropy[idx_ext + 1, ii] + entropy[idx_ext + 2, ii]) / 24.0
            u1_r = (entropy[idx_ext + 2, ii] - entropy[idx_ext, ii]) / 2.0
            u2_r = (entropy[idx_ext, ii] - 2 * entropy[idx_ext + 1, ii] + entropy[idx_ext + 2, ii]) / 2.0

            edge_R_of_L = u0_l + 0.5 * u1_l + (1.0 / 6.0) * u2_l
            edge_L_of_C = u0_c - 0.5 * u1_c + (1.0 / 6.0) * u2_c
            edge_R_of_C = u0_c + 0.5 * u1_c + (1.0 / 6.0) * u2_c
            edge_L_of_R = u0_r - 0.5 * u1_r + (1.0 / 6.0) * u2_r

            max_jump = np.max([np.abs(edge_L_of_C - edge_R_of_L), np.abs(edge_L_of_R - edge_R_of_C)])
            denominator = (dy ** 2.5) * (np.abs(entropy[idx_ext, ii]) + 1e-10)
            prob_y[j, i] = 1.0 if (max_jump / denominator) <= threshold else 0.0

    return prob_x, prob_y


def get_MLP_prob_matrices(U_ext, dx, dy, gamma, threshold, nghost, model, device):
    """
    针对 2D Euler 提取一维切片并调用神经网络进行 troubled-point 判定
    """
    rho = np.maximum(U_ext[0], 1e-14)
    p = np.maximum((gamma - 1.0) * (U_ext[3] - 0.5 * (U_ext[1] ** 2 + U_ext[2] ** 2) / rho), 1e-14)
    entropy = p / np.maximum(rho ** gamma, 1e-12)

    Ny = U_ext.shape[1] - 2 * nghost
    Nx = U_ext.shape[2] - 2 * nghost

    prob_x = np.zeros((Ny, Nx + 2), dtype=np.float32)
    prob_y = np.zeros((Ny + 2, Nx), dtype=np.float32)

    # 1. X 方向：遍历每一行，空间尺度传入 dx
    for j in range(Ny):
        jj = j + nghost
        entropy_slice_x = entropy[jj, :]
        prob_array_x = predict_2d(entropy_slice_x, dx, model, device)
        prob_x[j, :] = np.where(prob_array_x > threshold, 1.0, 0.0)

    # 2. Y 方向：遍历每一列，空间尺度传入 dy
    for i in range(Nx):
        ii = i + nghost
        entropy_slice_y = entropy[:, ii]
        prob_array_y = predict_2d(entropy_slice_y, dy, model, device)
        prob_y[:, i] = np.where(prob_array_y > threshold, 1.0, 0.0)

    return prob_x, prob_y