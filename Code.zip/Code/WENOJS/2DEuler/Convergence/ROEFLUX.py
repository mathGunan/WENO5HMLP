import numpy as np


def compute_rhs_2d_pure_weno5(U_ext, dx, dy, gamma=1.4, nghost=3, epsilon=1e-6):
    """
    二维有限差分纯 WENO5 空间 RHS 计算函数。
    【无条件重构】：去除任何外部判定矩阵，在 X 和 Y 方向的全流场通道无条件执行纯正的 WENO5 重构。
    """
    n_vars, Ny_ext, Nx_ext = U_ext.shape
    assert n_vars == 4, "二维Euler守恒量应为4通道"
    Ny = Ny_ext - 2 * nghost
    Nx = Nx_ext - 2 * nghost

    # ========== 1. 计算中心点基本物理量与原始通量 F, G ==========
    rho = U_ext[0]
    u = U_ext[1] / np.maximum(rho, 1e-10)
    v = U_ext[2] / np.maximum(rho, 1e-10)
    E = U_ext[3]
    p = np.maximum((gamma - 1.0) * (E - 0.5 * rho * (u ** 2 + v ** 2)), 1e-10)
    a = np.sqrt(gamma * p / np.maximum(rho, 1e-10))

    F_ext = np.zeros_like(U_ext)
    G_ext = np.zeros_like(U_ext)
    F_ext[0], F_ext[1], F_ext[2], F_ext[3] = rho * u, rho * u ** 2 + p, rho * u * v, u * (E + p)
    G_ext[0], G_ext[1], G_ext[2], G_ext[3] = rho * v, rho * u * v, rho * v ** 2 + p, v * (E + p)

    # ========== 2. 初始化交界面数值通量 ==========
    F_hat = np.zeros((4, Ny, Nx + 1))  # X 方向界面
    G_hat = np.zeros((4, Ny + 1, Nx))  # Y 方向界面

    # ========== 3. X 方向通量重构循环 (逐行处理) ==========
    for j in range(Ny):
        jj = j + nghost

        # 沿当前行的全局 LF 通量分裂
        alpha_x = np.max(np.abs(u[jj, :]) + a[jj, :])
        F_plus = 0.5 * (F_ext[:, jj, :] + alpha_x * U_ext[:, jj, :])
        F_minus = 0.5 * (F_ext[:, jj, :] - alpha_x * U_ext[:, jj, :])

        for i_face in range(Nx + 1):
            i_center = i_face + nghost

            # 正通量左重构
            g_plus = F_plus[:, i_center - 3: i_center + 2]
            v0, v1, v2, v3, v4 = g_plus[:, 0], g_plus[:, 1], g_plus[:, 2], g_plus[:, 3], g_plus[:, 4]
            p1_plus = (2.0 * v0 - 7.0 * v1 + 11.0 * v2) / 6.0
            p2_plus = (-v1 + 5.0 * v2 + 2.0 * v3) / 6.0
            p3_plus = (2.0 * v2 + 5.0 * v3 - v4) / 6.0
            beta1_plus = (13.0 / 12.0) * (v0 - 2.0 * v1 + v2) ** 2 + 0.25 * (v0 - 4.0 * v1 + 3.0 * v2) ** 2
            beta2_plus = (13.0 / 12.0) * (v1 - 2.0 * v2 + v3) ** 2 + 0.25 * (v1 - v3) ** 2
            beta3_plus = (13.0 / 12.0) * (v2 - 2.0 * v3 + v4) ** 2 + 0.25 * (3.0 * v2 - 4.0 * v3 + v4) ** 2
            alpha1_plus = 0.1 / (epsilon + beta1_plus) ** 2
            alpha2_plus = 0.6 / (epsilon + beta2_plus) ** 2
            alpha3_plus = 0.3 / (epsilon + beta3_plus) ** 2
            wsum_plus = alpha1_plus + alpha2_plus + alpha3_plus
            F_plus_L = (alpha1_plus * p1_plus + alpha2_plus * p2_plus + alpha3_plus * p3_plus) / wsum_plus

            # 负通量右重构
            g_minus = F_minus[:, i_center - 2: i_center + 3]
            v0, v1, v2, v3, v4 = g_minus[:, 0], g_minus[:, 1], g_minus[:, 2], g_minus[:, 3], g_minus[:, 4]
            p1_minus = (-v0 + 5.0 * v1 + 2.0 * v2) / 6.0
            p2_minus = (2.0 * v1 + 5.0 * v2 - v3) / 6.0
            p3_minus = (11.0 * v2 - 7.0 * v3 + 2.0 * v4) / 6.0
            beta1_minus = (13.0 / 12.0) * (v0 - 2.0 * v1 + v2) ** 2 + 0.25 * (v0 - 4.0 * v1 + 3.0 * v2) ** 2
            beta2_minus = (13.0 / 12.0) * (v1 - 2.0 * v2 + v3) ** 2 + 0.25 * (v1 - v3) ** 2
            beta3_minus = (13.0 / 12.0) * (v2 - 2.0 * v3 + v4) ** 2 + 0.25 * (3.0 * v2 - 4.0 * v3 + v4) ** 2
            alpha1_minus = 0.3 / (epsilon + beta1_minus) ** 2
            alpha2_minus = 0.6 / (epsilon + beta2_minus) ** 2
            alpha3_minus = 0.1 / (epsilon + beta3_minus) ** 2
            wsum_minus = alpha1_minus + alpha2_minus + alpha3_minus
            F_minus_R = (alpha1_minus * p1_minus + alpha2_minus * p2_minus + alpha3_minus * p3_minus) / wsum_minus

            F_hat[:, j, i_face] = F_plus_L + F_minus_R

    # ========== 4. Y 方向通量重构循环 (逐列处理) ==========
    for i in range(Nx):
        ii = i + nghost

        # 沿当前列的全局 LF 通量分裂
        alpha_y = np.max(np.abs(v[:, ii]) + a[:, ii])
        G_plus = 0.5 * (G_ext[:, :, ii] + alpha_y * U_ext[:, :, ii])
        G_minus = 0.5 * (G_ext[:, :, ii] - alpha_y * U_ext[:, :, ii])

        for j_face in range(Ny + 1):
            j_center = j_face + nghost

            # 正通量下重构
            g_plus = G_plus[:, j_center - 3: j_center + 2]
            v0, v1, v2, v3, v4 = g_plus[:, 0], g_plus[:, 1], g_plus[:, 2], g_plus[:, 3], g_plus[:, 4]
            p1_plus = (2.0 * v0 - 7.0 * v1 + 11.0 * v2) / 6.0
            p2_plus = (-v1 + 5.0 * v2 + 2.0 * v3) / 6.0
            p3_plus = (2.0 * v2 + 5.0 * v3 - v4) / 6.0
            beta1_plus = (13.0 / 12.0) * (v0 - 2.0 * v1 + v2) ** 2 + 0.25 * (v0 - 4.0 * v1 + 3.0 * v2) ** 2
            beta2_plus = (13.0 / 12.0) * (v1 - 2.0 * v2 + v3) ** 2 + 0.25 * (v1 - v3) ** 2
            beta3_plus = (13.0 / 12.0) * (v2 - 2.0 * v3 + v4) ** 2 + 0.25 * (3.0 * v2 - 4.0 * v3 + v4) ** 2
            alpha1_plus = 0.1 / (epsilon + beta1_plus) ** 2
            alpha2_plus = 0.6 / (epsilon + beta2_plus) ** 2
            alpha3_plus = 0.3 / (epsilon + beta3_plus) ** 2
            wsum_plus = alpha1_plus + alpha2_plus + alpha3_plus
            G_plus_L = (alpha1_plus * p1_plus + alpha2_plus * p2_plus + alpha3_plus * p3_plus) / wsum_plus

            # 负通量上重构
            g_minus = G_minus[:, j_center - 2: j_center + 3]
            v0, v1, v2, v3, v4 = g_minus[:, 0], g_minus[:, 1], g_minus[:, 2], g_minus[:, 3], g_minus[:, 4]
            p1_minus = (-v0 + 5.0 * v1 + 2.0 * v2) / 6.0
            p2_minus = (2.0 * v1 + 5.0 * v2 - v3) / 6.0
            p3_minus = (11.0 * v2 - 7.0 * v3 + 2.0 * v4) / 6.0
            beta1_minus = (13.0 / 12.0) * (v0 - 2.0 * v1 + v2) ** 2 + 0.25 * (v0 - 4.0 * v1 + 3.0 * v2) ** 2
            beta2_minus = (13.0 / 12.0) * (v1 - 2.0 * v2 + v3) ** 2 + 0.25 * (v1 - v3) ** 2
            beta3_minus = (13.0 / 12.0) * (v2 - 2.0 * v3 + v4) ** 2 + 0.25 * (3.0 * v2 - 4.0 * v3 + v4) ** 2
            alpha1_minus = 0.3 / (epsilon + beta1_minus) ** 2
            alpha2_minus = 0.6 / (epsilon + beta2_minus) ** 2
            alpha3_minus = 0.1 / (epsilon + beta3_minus) ** 2
            wsum_minus = alpha1_minus + alpha2_minus + alpha3_minus
            G_minus_R = (alpha1_minus * p1_minus + alpha2_minus * p2_minus + alpha3_minus * p3_minus) / wsum_minus

            G_hat[:, j_face, i] = G_plus_L + G_minus_R

    # ========== 5. 计算空间总右端项残差 ==========
    rhs = np.zeros((4, Ny, Nx))
    rhs -= (F_hat[:, :, 1:] - F_hat[:, :, :-1]) / dx
    rhs -= (G_hat[:, 1:, :] - G_hat[:, :-1, :]) / dy
    return rhs


def compute_rhs_2d_with_KXRCF(U_ext, dx, dy, prob_x_global, prob_y_global, gamma=1.4, nghost=3, epsilon=1e-6):
    """
    接收外部传入全局判定矩阵的二维 Euler 空间右端项计算函数（保持原有名称）
    prob_x_global 尺寸: (Ny, Nx + 2)
    prob_y_global 尺寸: (Ny + 2, Nx)
    """
    n_vars, Ny_ext, Nx_ext = U_ext.shape
    Ny = Ny_ext - 2 * nghost
    Nx = Nx_ext - 2 * nghost

    rho = np.maximum(U_ext[0], 1e-14)
    u = U_ext[1] / rho
    v = U_ext[2] / rho
    E = U_ext[3]
    p = np.maximum((gamma - 1.0) * (E - 0.5 * rho * (u ** 2 + v ** 2)), 1e-14)
    H = (E + p) / rho

    F = np.zeros_like(U_ext)
    G = np.zeros_like(U_ext)
    F[0], F[1], F[2], F[3] = rho * u, rho * u ** 2 + p, rho * u * v, u * (E + p)
    G[0], G[1], G[2], G[3] = rho * v, rho * u * v, rho * v ** 2 + p, v * (E + p)

    F_hat = np.zeros((4, Ny, Nx + 1))
    G_hat = np.zeros((4, Ny + 1, Nx))

    # =========================================================================
    # 2. X 方向界面数值通量计算
    # =========================================================================
    for j in range(Ny):
        jj = j + nghost
        prob_x = prob_x_global[j, :]

        for i_face in range(Nx + 1):
            i_center = i_face + nghost
            iL, iR = i_center - 1, i_center

            rhoL, rhoR = rho[jj, iL], rho[jj, iR]
            uL, uR = u[jj, iL], u[jj, iR]
            vL, vR = v[jj, iL], v[jj, iR]
            HL, HR = H[jj, iL], H[jj, iR]

            rtL, rtR = np.sqrt(rhoL), np.sqrt(rhoR)
            denom = rtL + rtR
            u_t = (rtL * uL + rtR * uR) / denom
            v_t = (rtL * vL + rtR * vR) / denom
            H_t = (rtL * HL + rtR * HR) / denom
            a_t = np.sqrt(np.maximum((gamma - 1.0) * (H_t - 0.5 * (u_t ** 2 + v_t ** 2)), 1e-14))

            gamma1 = gamma - 1.0
            V_sq = u_t ** 2 + v_t ** 2

            R_mat = np.array([
                [1.0, 1.0, 0.0, 1.0],
                [u_t - a_t, u_t, 0.0, u_t + a_t],
                [v_t, v_t, 1.0, v_t],
                [H_t - u_t * a_t, 0.5 * V_sq, v_t, H_t + u_t * a_t]
            ])
            L_mat = np.array([
                [H_t + (a_t / gamma1) * (u_t - a_t), -(u_t + a_t / gamma1), -v_t, 1.0],
                [-2 * H_t + 4 * a_t ** 2 / gamma1, 2 * u_t, 2 * v_t, -2.0],
                [-2 * v_t * a_t ** 2 / gamma1, 0.0, 2 * a_t ** 2 / gamma1, 0.0],
                [H_t - (a_t / gamma1) * (u_t + a_t), -u_t + a_t / gamma1, -v_t, 1.0]
            ])
            L_mat = (gamma1 / (2.0 * a_t ** 2)) * L_mat

            stencil = slice(i_center - 3, i_center + 3)
            W_stencil = L_mat @ U_ext[:, jj, stencil]
            G_stencil = L_mat @ F[:, jj, stencil]

            alpha_val = np.max(np.abs([u_t - a_t, u_t, u_t + a_t]))
            G_plus = 0.5 * (G_stencil + alpha_val * W_stencil)
            G_minus = 0.5 * (G_stencil - alpha_val * W_stencil)

            Gp_iL = np.zeros(4)
            Gm_iR = np.zeros(4)

            for k in range(4):
                # --- 正通量左重构 ---
                g_p = G_plus[k, :]  # 长度为 6 的模板 (i-3, i-2, i-1, i, i+1, i+2)
                if prob_x[i_face]:
                    Gp_iL[k] = (2.0 * g_p[0] - 13.0 * g_p[1] + 47.0 * g_p[2] + 27.0 * g_p[3] - 3.0 * g_p[4]) / 60.0
                else:
                    p1 = (2.0 * g_p[0] - 7.0 * g_p[1] + 11.0 * g_p[2]) / 6.0
                    p2 = (-g_p[1] + 5.0 * g_p[2] + 2.0 * g_p[3]) / 6.0
                    p3 = (2.0 * g_p[2] + 5.0 * g_p[3] - g_p[4]) / 6.0
                    b1 = (13.0 / 12.0) * (g_p[0] - 2.0 * g_p[1] + g_p[2]) ** 2 + 0.25 * (
                                g_p[0] - 4.0 * g_p[1] + 3.0 * g_p[2]) ** 2
                    b2 = (13.0 / 12.0) * (g_p[1] - 2.0 * g_p[2] + g_p[3]) ** 2 + 0.25 * (g_p[1] - g_p[3]) ** 2
                    b3 = (13.0 / 12.0) * (g_p[2] - 2.0 * g_p[3] + g_p[4]) ** 2 + 0.25 * (
                                3.0 * g_p[2] - 4.0 * g_p[3] + g_p[4]) ** 2
                    al1 = 0.1 / (epsilon + b1) ** 2
                    al2 = 0.6 / (epsilon + b2) ** 2
                    al3 = 0.3 / (epsilon + b3) ** 2
                    w_sum = al1 + al2 + al3
                    Gp_iL[k] = (al1 * p1 + al2 * p2 + al3 * p3) / w_sum

                # --- 负通量右重构 ---
                g_m = G_minus[k, :]  # 镜像模板
                if prob_x[i_face + 1]:
                    Gm_iR[k] = (-3.0 * g_m[1] + 27.0 * g_m[2] + 47.0 * g_m[3] - 13.0 * g_m[4] + 2.0 * g_m[5]) / 60.0
                else:
                    p1 = (-g_m[1] + 5.0 * g_m[2] + 2.0 * g_m[3]) / 6.0
                    p2 = (2.0 * g_m[2] + 5.0 * g_m[3] - g_m[4]) / 6.0
                    p3 = (11.0 * g_m[3] - 7.0 * g_m[4] + 2.0 * g_m[5]) / 6.0
                    b1 = (13.0 / 12.0) * (g_m[1] - 2.0 * g_m[2] + g_m[3]) ** 2 + 0.25 * (
                                g_m[1] - 4.0 * g_m[2] + 3.0 * g_m[3]) ** 2
                    b2 = (13.0 / 12.0) * (g_m[2] - 2.0 * g_m[3] + g_m[4]) ** 2 + 0.25 * (g_m[2] - g_m[4]) ** 2
                    b3 = (13.0 / 12.0) * (g_m[3] - 2.0 * g_m[4] + g_m[5]) ** 2 + 0.25 * (
                                3.0 * g_m[3] - 4.0 * g_m[4] + g_m[5]) ** 2
                    al1 = 0.3 / (epsilon + b1) ** 2
                    al2 = 0.6 / (epsilon + b2) ** 2
                    al3 = 0.1 / (epsilon + b3) ** 2
                    w_sum = al1 + al2 + al3
                    Gm_iR[k] = (al1 * p1 + al2 * p2 + al3 * p3) / w_sum

            F_hat[:, j, i_face] = R_mat @ (Gp_iL + Gm_iR)

    # =========================================================================
    # 3. Y 方向界面数值通量计算
    # =========================================================================
    for i in range(Nx):
        ii = i + nghost
        prob_y = prob_y_global[:, i]

        for j_face in range(Ny + 1):
            j_center = j_face + nghost
            jL, jR = j_center - 1, j_center

            rhoL, rhoR = rho[jL, ii], rho[jR, ii]
            uL, uR = u[jL, ii], u[jR, ii]
            vL, vR = v[jL, ii], v[jR, ii]
            HL, HR = H[jL, ii], H[jR, ii]

            rtL, rtR = np.sqrt(rhoL), np.sqrt(rhoR)
            denom = rtL + rtR
            u_t = (rtL * uL + rtR * uR) / denom
            v_t = (rtL * vL + rtR * vR) / denom
            H_t = (rtL * HL + rtR * HR) / denom
            a_t = np.sqrt(np.maximum((gamma - 1.0) * (H_t - 0.5 * (u_t ** 2 + v_t ** 2)), 1e-14))

            gamma1 = gamma - 1.0
            V_sq = u_t ** 2 + v_t ** 2

            R_mat = np.array([
                [1.0, 0.0, 1.0, 1.0],
                [u_t, 1.0, u_t, u_t],
                [v_t - a_t, 0.0, v_t, v_t + a_t],
                [H_t - v_t * a_t, v_t, 0.5 * V_sq, H_t + v_t * a_t]
            ])
            L_mat = np.array([
                [H_t + (a_t / gamma1) * (v_t - a_t), -u_t, -(v_t + a_t / gamma1), 1.0],
                [-2 * u_t * a_t ** 2 / gamma1, 2 * a_t ** 2 / gamma1, 0.0, 0.0],
                [-2 * H_t + 4 * a_t ** 2 / gamma1, 2 * u_t, 2 * v_t, -2.0],
                [H_t - (a_t / gamma1) * (v_t + a_t), -u_t, -v_t + a_t / gamma1, 1.0]
            ])
            L_mat = (gamma1 / (2.0 * a_t ** 2)) * L_mat

            stencil = slice(j_center - 3, j_center + 3)
            W_stencil = L_mat @ U_ext[:, stencil, ii]
            G_stencil = L_mat @ G[:, stencil, ii]

            alpha_val = np.max(np.abs([v_t - a_t, v_t, v_t + a_t]))
            G_plus = 0.5 * (G_stencil + alpha_val * W_stencil)
            G_minus = 0.5 * (G_stencil - alpha_val * W_stencil)

            Gp_jL = np.zeros(4)
            Gm_jR = np.zeros(4)

            for k in range(4):
                # --- 正通量左(下)重构 ---
                g_p = G_plus[k, :]
                if prob_y[j_face]:
                    Gp_jL[k] = (2.0 * g_p[0] - 13.0 * g_p[1] + 47.0 * g_p[2] + 27.0 * g_p[3] - 3.0 * g_p[4]) / 60.0
                else:
                    p1 = (2.0 * g_p[0] - 7.0 * g_p[1] + 11.0 * g_p[2]) / 6.0
                    p2 = (-g_p[1] + 5.0 * g_p[2] + 2.0 * g_p[3]) / 6.0
                    p3 = (2.0 * g_p[2] + 5.0 * g_p[3] - g_p[4]) / 6.0
                    b1 = (13.0 / 12.0) * (g_p[0] - 2.0 * g_p[1] + g_p[2]) ** 2 + 0.25 * (
                                g_p[0] - 4.0 * g_p[1] + 3.0 * g_p[2]) ** 2
                    b2 = (13.0 / 12.0) * (g_p[1] - 2.0 * g_p[2] + g_p[3]) ** 2 + 0.25 * (g_p[1] - g_p[3]) ** 2
                    b3 = (13.0 / 12.0) * (g_p[2] - 2.0 * g_p[3] + g_p[4]) ** 2 + 0.25 * (
                                3.0 * g_p[2] - 4.0 * g_p[3] + g_p[4]) ** 2
                    al1 = 0.1 / (epsilon + b1) ** 2
                    al2 = 0.6 / (epsilon + b2) ** 2
                    al3 = 0.3 / (epsilon + b3) ** 2
                    w_sum = al1 + al2 + al3
                    Gp_jL[k] = (al1 * p1 + al2 * p2 + al3 * p3) / w_sum

                # --- 负通量右(上)重构 ---
                g_m = G_minus[k, :]
                if prob_y[j_face + 1]:
                    Gm_jR[k] = (-3.0 * g_m[1] + 27.0 * g_m[2] + 47.0 * g_m[3] - 13.0 * g_m[4] + 2.0 * g_m[5]) / 60.0
                else:
                    p1 = (-g_m[1] + 5.0 * g_m[2] + 2.0 * g_m[3]) / 6.0
                    p2 = (2.0 * g_m[2] + 5.0 * g_m[3] - g_m[4]) / 6.0
                    p3 = (11.0 * g_m[3] - 7.0 * g_m[4] + 2.0 * g_m[5]) / 6.0
                    b1 = (13.0 / 12.0) * (g_m[1] - 2.0 * g_m[2] + g_m[3]) ** 2 + 0.25 * (
                                g_m[1] - 4.0 * g_m[2] + 3.0 * g_m[3]) ** 2
                    b2 = (13.0 / 12.0) * (g_m[2] - 2.0 * g_m[3] + g_m[4]) ** 2 + 0.25 * (g_m[2] - g_m[4]) ** 2
                    b3 = (13.0 / 12.0) * (g_m[3] - 2.0 * g_m[4] + g_m[5]) ** 2 + 0.25 * (
                                3.0 * g_m[3] - 4.0 * g_m[4] + g_m[5]) ** 2
                    al1 = 0.3 / (epsilon + b1) ** 2
                    al2 = 0.6 / (epsilon + b2) ** 2
                    al3 = 0.1 / (epsilon + b3) ** 2
                    w_sum = al1 + al2 + al3
                    Gm_jR[k] = (al1 * p1 + al2 * p2 + al3 * p3) / w_sum

            G_hat[:, j_face, i] = R_mat @ (Gp_jL + Gm_jR)

    rhs = np.zeros((4, Ny, Nx))
    rhs -= (F_hat[:, :, 1:] - F_hat[:, :, :-1]) / dx
    rhs -= (G_hat[:, 1:, :] - G_hat[:, :-1, :]) / dy
    return rhs


def compute_rhs_2d_with_MLP(U_ext, dx, dy, prob_x_global, prob_y_global, gamma=1.4, nghost=3, epsilon=1e-6):
    """
    接收外部传入全局判定矩阵的二维 Euler MLP 空间右端项计算函数（保持原有名称）
    """
    return compute_rhs_2d_with_KXRCF(U_ext, dx, dy, prob_x_global, prob_y_global, gamma, nghost, epsilon)