import numpy as np

data = np.load("Weno5FDM2DEuler_results.npz")

errors_L1 = data['errors_L1']
errors_L2 = data['errors_L2']
errors_Linf = data['errors_Linf']
orders_L1 = data['orders_L1']
orders_L2 = data['orders_L2']
orders_Linf = data['orders_Linf']
cpu_times = data['cpu_times']


# 使用数据
print("L1误差:", errors_L1)
print("L1收敛阶:", orders_L1)
print("L2误差:", errors_L2)
print("L2收敛阶:", orders_L2)
print("Linf误差:", errors_Linf)
print("Linf收敛阶:", orders_Linf)
print("CPU时间:", cpu_times)

