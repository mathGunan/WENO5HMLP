import csv
import time
import numpy as np
import torch
from Errorandorder import L1_error, L2_error, Linf_error, convergence_order
from RK3 import SolverWeno5Rk3_MLP
from IC import IC, rho_exact
# 导入您的全局模型定义辅助函数以及您的网络架构类 Weno5FDMMLP
from model import *
from helperfunction import *

gamma = 1.4


# =========================================================================
# 1. 单次网格规模的仿真核心算子
# =========================================================================
def compute_single_run(N, model, device, T_final=0.3):
    nx = ny = N
    Lx = Ly = 2 * np.pi
    dx = Lx / nx
    dy = Ly / ny
    dt = dx ** (5.0 / 3.0)  # 精准匹配高阶精度时间步长需求，防止时间误差污染空间收敛阶

    x = np.linspace(dx / 2, 2 * np.pi - dx / 2, nx)
    y = np.linspace(dy / 2, 2 * np.pi - dy / 2, ny)
    Xc, Yc = np.meshgrid(x, y, indexing='xy')

    # 初始化光滑正弦流动场（从您的 IC.py 导入）
    U = IC(Xc, Yc)
    t = 0.0
    iteration = 0

    start_time = time.time()
    while t < T_final:
        if t + dt > T_final:
            dt = T_final - t

        # 【关键控制】：激活收敛阶状态约束 is_convergence_test=True
        # 使得在光滑区域做精度验证时，单步内保持 troubled-point 探测图层固定，确保流场无偏，完美测出5阶收敛
        U = SolverWeno5Rk3_MLP(
            U_phys=U,
            dx=dx,
            dy=dy,
            dt=dt,
            model=model,
            device=device,
            gamma=gamma,
            threshold=0.5,
            nghost=3,
            is_convergence_test=True
        )

        t += dt
        iteration += 1

    cpu_time = time.time() - start_time
    rho_num = U[0, :, :]
    rho_ex = rho_exact(Xc, Yc, T_final)

    # 精准计算L1, L2, Linf误差
    E1 = L1_error(rho_num, rho_ex)
    E2 = L2_error(rho_num, rho_ex)
    Einf = Linf_error(rho_num, rho_ex)

    print(f"网格规模 N={N:3d} 计算完毕，总迭代次数: {iteration:4d}，耗时: {cpu_time:.4f}s")
    return (N, dx, E1, E2, Einf, cpu_time)


# =========================================================================
# 2. 主程序控制流程
# =========================================================================
def main():
    print("====================================================")
    print("  开启 2D Euler (WENO5 + MLP) 空间收敛性自动化验证  ")
    print("====================================================")

    # 完美接入您现有的模型定义和权重加载辅助函数
    model, device = get_model()
    print(f"当前计算后端硬件映射为: {device}")

    # 测试渐进加密的网格序列
    test_N = [20, 40, 80,160]
    T_final = 0.3
    results = []

    # 冻结 PyTorch 梯度引擎，大幅度提升前向推理流场判定的速度并节省内存
    with torch.no_grad():
        for N in test_N:
            res = compute_single_run(N, model, device, T_final=T_final)
            results.append(res)

    # 提取多级误差与网格尺度
    dxs = [r[1] for r in results]
    errors_L1 = [r[2] for r in results]
    errors_L2 = [r[3] for r in results]
    errors_inf = [r[4] for r in results]
    cputimes = [r[5] for r in results]

    # 调用通用高阶收敛阶计算算子
    order_l1 = ["--"] + list(convergence_order(errors_L1, dxs))
    order_l2 = ["--"] + list(convergence_order(errors_L2, dxs))
    order_inf = ["--"] + list(convergence_order(errors_inf, dxs))

    # 将格式化数据规范写入 CSV 文件，便于 LaTeX / Origin 直接读取生成学术图表
    csv_filename = "Weno5MLPFDM2DEuler_results.csv"
    with open(csv_filename, mode='w', newline='', encoding='utf-8') as f:
        writer = csv.writer(f)
        writer.writerow([
            "N", "dx",
            "L1_Error", "L1_Order",
            "L2_Error", "L2_Order",
            "Linf_Error", "Linf_Order",
            "CPU_Time(s)"
        ])
        for i, r in enumerate(results):
            o1 = f"{order_l1[i]:.2f}" if isinstance(order_l1[i], float) else order_l1[i]
            o2 = f"{order_l2[i]:.2f}" if isinstance(order_l2[i], float) else order_l2[i]
            oinf = f"{order_inf[i]:.2f}" if isinstance(order_inf[i], float) else order_inf[i]

            writer.writerow([
                r[0],
                f"{r[1]:.6e}",
                f"{errors_L1[i]:.6e}", o1,
                f"{errors_L2[i]:.6e}", o2,
                f"{errors_inf[i]:.6e}", oinf,
                f"{cputimes[i]:.4f}"
            ])

    print("----------------------------------------------------")
    print(f"数据处理完毕。学术级收敛性数据已完整导出至: {csv_filename}")
    print("====================================================")


if __name__ == "__main__":
    main()