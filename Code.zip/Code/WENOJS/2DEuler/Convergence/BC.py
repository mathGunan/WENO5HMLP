import numpy as np

def apply_periodic_bc(U, nghost=3):
    """
    使用np.pad的简洁版本
    """
    # 对y方向和x方向分别应用周期性边界
    # 格式: ((y_before, y_after), (x_before, x_after))
    pad_width = ((0, 0), (nghost, nghost), (nghost, nghost))

    U_ext = np.pad(U, pad_width, mode='wrap')

    return U_ext