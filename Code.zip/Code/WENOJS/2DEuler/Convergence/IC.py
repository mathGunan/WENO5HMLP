import numpy as np

def IC(Xc, Yc, gamma=1.4):
    '''输出的是守恒向量组成的矩阵4*Ny*Nx'''
    rho = 1 + 0.2 * np.sin(Xc + Yc)
    u = 0.7 * np.ones_like(Xc)
    v = 0.3 * np.ones_like(Xc)
    p = 1.0 * np.ones_like(Xc)

    # 手动计算守恒变量
    U = np.zeros((4, Xc.shape[0], Xc.shape[1]))
    U[0] = rho  # 密度
    U[1] = rho * u  # x方向动量
    U[2] = rho * v  # y方向动量
    U[3] = p / (gamma - 1) + 0.5 * rho * (u ** 2 + v ** 2)  # 总能

    return U


def rho_exact(Xc, Yc, t):
    """平移波精确解"""
    x_shift = (Xc - 0.7*t) % (2*np.pi)
    y_shift = (Yc - 0.3*t) % (2*np.pi)
    return 1 + 0.2 * np.sin(x_shift + y_shift)