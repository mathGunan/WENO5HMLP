import csv
import time
import numpy as np

# 导入您的底层算子与环境配置
from BC import *
from Errorandorder import *
from IC import *
from RK3 import *
from ROEFLUX import *

gamma = 1.4


def compute_single_run(N, T_final=0.3):
    nx = ny = N
    Lx = Ly = 2 * np.pi
    dx = Lx / nx
    dy = Ly / ny
    dt = dx ** (5 / 3)  # 有限差分收敛阶验证时的时间步长设置

    # 网格中心坐标
    x = np.linspace(dx / 2, 2 * np.pi - dx / 2, nx)
    y = np.linspace(dy / 2, 2 * np.pi - dy / 2, ny)
    Xc, Yc = np.meshgrid(x, y, indexing="xy")

    # 初始条件 (shape: (4, ny, nx))
    U = IC(Xc, Yc)

    # 时间推进
    t = 0.0
    iteration = 0

    start_time = time.time()
    while t < T_final:
        if t + dt > T_final:
            dt = T_final - t

        # 无条件调用纯有限差分 WENO5 空间右端项的时间推进程序
        U = SolverWeno5Rk3(U, dx, dy, dt, gamma=gamma, nghost=3)

        t += dt
        iteration += 1

        if iteration % 50 == 0:
            progress = (t / T_final) * 100
            print(f"N={N}: 进度 {progress:.1f}%, 迭代 {iteration}")

    cpu_time = time.time() - start_time

    # 提取数值密度
    rho_num = U[0, :, :]

    # 获取 t 时刻的精确密度解
    rho_ex = rho_exact(Xc, Yc, T_final)

    # 误差计算（仅针对密度通道）
    E1 = L1_error(rho_num, rho_ex)
    E2 = L2_error(rho_num, rho_ex)
    Einf = Linf_error(rho_num, rho_ex)

    print(
        f"N={N}: 计算完成，耗时 {cpu_time:.4f} 秒，迭代 {iteration} 次"
    )
    return (N, dx, E1, E2, Einf, cpu_time)


def main():
    print("====================================================")
    print(" 开始 2D Euler (纯有限差分 WENO5) 收敛性与效率测试...")
    print("====================================================")

    test_N = [20, 40, 80,160]  # 收敛阶验证的网格序列
    T_final = 0.3
    results = []

    for N in test_N:
        res = compute_single_run(N, T_final=T_final)
        results.append(res)

    # 拆分并整理输出数据
    dxs = [r[1] for r in results]
    errors_L1 = [r[2] for r in results]
    errors_L2 = [r[3] for r in results]
    errors_inf = [r[4] for r in results]
    cputimes = [r[5] for r in results]

    # 计算收敛阶 (第一项由于没有前项，阶数留白或设为占位符 "--")
    order_l1 = ["--"] + list(convergence_order(errors_L1, dxs))
    order_l2 = ["--"] + list(convergence_order(errors_L2, dxs))
    order_inf = ["--"] + list(convergence_order(errors_inf, dxs))

    # 在控制台打印精美的学术预览表格
    print("\n=== 收敛性结果预览（密度） ===")
    for i, N in enumerate(test_N):
        print(
            f"N={N:<3} | dx={dxs[i]:.4e} | "
            f"L1={errors_L1[i]:.4e} ({order_l1[i]}) | "
            f"L2={errors_L2[i]:.4e} ({order_l2[i]}) | "
            f"Linf={errors_inf[i]:.4e} ({order_inf[i]})"
        )

    # 将数据写入符合学术出版标准的 CSV 文件
    csv_filename = "Weno5PureFDM2DEuler_results.csv"
    with open(csv_filename, mode="w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)

        # 写入标准的学术数据表头
        writer.writerow(
            [
                "N",
                "dx",
                "L1_Error",
                "L1_Order",
                "L2_Error",
                "L2_Order",
                "Linf_Error",
                "Linf_Order",
                "CPU_Time(s)",
            ]
        )

        # 逐行填入离散网格尺度下的计算参数和统计值
        for i, r in enumerate(results):
            # 格式化收敛阶显示
            o1 = f"{order_l1[i]:.2f}" if isinstance(order_l1[i], float) else order_l1[i]
            o2 = f"{order_l2[i]:.2f}" if isinstance(order_l2[i], float) else order_l2[i]
            oinf = (
                f"{order_inf[i]:.2f}"
                if isinstance(order_inf[i], float)
                else order_inf[i]
            )

            writer.writerow(
                [
                    r[0],  # N
                    f"{r[1]:.6e}",  # dx
                    f"{errors_L1[i]:.6e}",  # L1 误差
                    o1,  # L1 阶数
                    f"{errors_L2[i]:.6e}",  # L2 误差
                    o2,  # L2 阶数
                    f"{errors_inf[i]:.6e}",  # Linf 误差
                    oinf,  # Linf 阶数
                    f"{cputimes[i]:.4f}",  # 耗时
                ]
            )

    print(f"\n[成功] 纯 WENO5 精度测试结果已成功保存到: {csv_filename}")


if __name__ == "__main__":
    main()