from ROEFLUX import *
from BC import *
from helperfunction import *

def SolverWeno5Rk3(U_phys, dx, dy, dt, gamma=1.4, nghost=3, epsilon=1e-6):
    """
    三阶总变差减小 Runge-Kutta (TVD-RK3) 时间推进求解器 —— 纯有限差分 WENO5 格式。
    用于精度与耗时测试的基准（Baseline）。
    """
    # === Stage 1 ===
    U_ext = apply_periodic_bc(U_phys, nghost=nghost)
    rhs1 = compute_rhs_2d_pure_weno5(U_ext, dx, dy, gamma=gamma, nghost=nghost, epsilon=epsilon)
    U1 = U_phys + dt * rhs1

    # === Stage 2 ===
    U1_ext = apply_periodic_bc(U1, nghost=nghost)
    rhs2 = compute_rhs_2d_pure_weno5(U1_ext, dx, dy, gamma=gamma, nghost=nghost, epsilon=epsilon)
    U2 = 0.75 * U_phys + 0.25 * (U1 + dt * rhs2)

    # === Stage 3 ===
    U2_ext = apply_periodic_bc(U2, nghost=nghost)
    rhs3 = compute_rhs_2d_pure_weno5(U2_ext, dx, dy, gamma=gamma, nghost=nghost, epsilon=epsilon)
    U_next = (1.0 / 3.0) * U_phys + (2.0 / 3.0) * (U2 + dt * rhs3)

    return U_next


def SolverWeno5Rk3_KXRCF(U_phys, dx, dy, dt, gamma=1.4, threshold=1.0, nghost=3, is_convergence_test=False):
    """
    保持原名的 KXRCF 时间推进函数
    """
    U_ext = apply_periodic_bc(U_phys, nghost=nghost)

    if is_convergence_test:
        prob_x, prob_y = get_KXRCF_prob_matrices(U_ext, dx, dy, gamma, threshold, nghost)

    # --- Stage 1 ---
    if not is_convergence_test:
        prob_x, prob_y = get_KXRCF_prob_matrices(U_ext, dx, dy, gamma, threshold, nghost)
    rhs1 = compute_rhs_2d_with_KXRCF(U_ext, dx, dy, prob_x, prob_y, gamma, nghost)
    U1 = U_phys + dt * rhs1

    # --- Stage 2 ---
    U1_ext = apply_periodic_bc(U1, nghost=nghost)
    if not is_convergence_test:
        prob_x, prob_y = get_KXRCF_prob_matrices(U1_ext, dx, dy, gamma, threshold, nghost)
    rhs2 = compute_rhs_2d_with_KXRCF(U1_ext, dx, dy, prob_x, prob_y, gamma, nghost)
    U2 = 0.75 * U_phys + 0.25 * (U1 + dt * rhs2)

    # --- Stage 3 ---
    U2_ext = apply_periodic_bc(U2, nghost=nghost)
    if not is_convergence_test:
        prob_x, prob_y = get_KXRCF_prob_matrices(U2_ext, dx, dy, gamma, threshold, nghost)
    rhs3 = compute_rhs_2d_with_KXRCF(U2_ext, dx, dy, prob_x, prob_y, gamma, nghost)
    U_next = (1.0 / 3.0) * U_phys + (2.0 / 3.0) * (U2 + dt * rhs3)

    return U_next


def SolverWeno5Rk3_MLP(U_phys, dx, dy, dt, model, device, gamma=1.4, threshold=0.5, nghost=3,
                       is_convergence_test=False):
    """
    纯净版 MLP 驱动的 三阶 TVD-RK 时间推进器
    """
    U_ext = apply_periodic_bc(U_phys, nghost=nghost)

    # 如果是收敛性测试，在整个 RK 步起点只锁定一次探测矩阵
    if is_convergence_test:
        prob_x, prob_y = get_MLP_prob_matrices(U_ext, dx, dy, gamma, threshold, nghost, model, device)

    # --- Stage 1 ---
    if not is_convergence_test:
        prob_x, prob_y = get_MLP_prob_matrices(U_ext, dx, dy, gamma, threshold, nghost, model, device)
    rhs1 = compute_rhs_2d_with_MLP(U_ext, dx, dy, prob_x, prob_y, gamma, nghost)
    U1 = U_phys + dt * rhs1

    # --- Stage 2 ---
    U1_ext = apply_periodic_bc(U1, nghost=nghost)
    if not is_convergence_test:
        prob_x, prob_y = get_MLP_prob_matrices(U1_ext, dx, dy, gamma, threshold, nghost, model, device)
    rhs2 = compute_rhs_2d_with_MLP(U1_ext, dx, dy, prob_x, prob_y, gamma, nghost)
    U2 = 0.75 * U_phys + 0.25 * (U1 + dt * rhs2)

    # --- Stage 3 ---
    U2_ext = apply_periodic_bc(U2, nghost=nghost)
    if not is_convergence_test:
        prob_x, prob_y = get_MLP_prob_matrices(U2_ext, dx, dy, gamma, threshold, nghost, model, device)
    rhs3 = compute_rhs_2d_with_MLP(U2_ext, dx, dy, prob_x, prob_y, gamma, nghost)
    U_next = (1.0 / 3.0) * U_phys + (2.0 / 3.0) * (U2 + dt * rhs3)

    return U_next