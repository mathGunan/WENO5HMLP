import numpy as np
from numba import jit, prange
from Errorandorder import *

def Weno5FDM1D(u_ext):
    eps = 1e-6
    N_ext = len(u_ext)
    N = N_ext - 6  # 实际物理点数

    u_left = np.zeros(N + 1)  # u^{-}_{i+1/2}
    u_right = np.zeros(N + 1)  # u^{+}_{i-1/2}
    # 最优线性权重
    #用于右端点的左重构-
    d0 = 3/10 #代表左移动0个模版
    d1 = 3/5 #代表左移动一个模版
    d2= 1/10#代表左移动两个模版

    #用于左端点的右重构+
    d0_tilde = 1/10
    d1_tilde = 3/5
    d2_tilde = 3/10


    for i in range(2, N + 4):
        #每一个小区间上，同时做右端点的左重构值和左端点的右重构值，并且会对于右重构会多一个最左边的ghost点，对于左重构会多一个最右边的ghost点
        # 获取当前模板的单元平均值,五点模版
        u_im2 = u_ext[i - 2]  # u_{i-2}
        u_im1 = u_ext[i - 1]  # u_{i-1}
        u_i = u_ext[i]  # u_i
        u_ip1 = u_ext[i + 1]  # u_{i+1}
        u_ip2 = u_ext[i + 2]  # u_{i+2}

        # 1. 计算子模板重构值，后续加权配上对应权重即可
        # 对于 u^{-}_{i+1/2}左重构
        u0_left = (2* u_i + 5 * u_ip1-u_ip2 )/6  # 左移0个模版
        u1_left = (-u_im1 + 5 * u_i+2*u_ip1 )/6  # 左移1个模版
        u2_left=(2* u_im2 -7 * u_im1+11*u_i)/6   # 左移2个模版


        # 对于 u^{+}_{i-1/2}右重构
        u0_right = (11* u_i -7 * u_ip1+2*u_ip2 )/6   # 左移0个模版
        u1_right = (2*u_im1 + 5 * u_i-u_ip1 )/6   # 左移1个模版
        u2_right = (-u_im2 +5 * u_im1+2*u_i)/6  # 左移2个模版


        # 2. 计算beta，其实是公用一套光滑因子
        beta0 = (13*(u_i-2*u_ip1+u_ip2) ** 2+3*(3*u_i-4*u_ip1+u_ip2)**2)/12
        beta1 = (13*(u_im1-2*u_i+u_ip1) ** 2+3*(u_im1-u_ip1)**2)/12
        beta2= (13*(u_im2-2*u_im1+u_i) ** 2+3*(u_im2-4*u_im1+3*u_i)**2)/12

        # 3. 计算非线性权重
        # 对于 u^{-}_{i+1/2}左重构
        alpha0_left = d0 / (eps + beta0) ** 2
        alpha1_left= d1 / (eps+ beta1) ** 2
        alpha2_left=d2/(eps+ beta2) ** 2

        sum_alpha_left = alpha0_left+alpha1_left+alpha2_left

        w0_left = alpha0_left / sum_alpha_left
        w1_left= alpha1_left / sum_alpha_left
        w2_left=alpha2_left/sum_alpha_left

        # 对于 u^{+}_{i-1/2}右重构
        alpha0_right = d0_tilde / (eps + beta0) ** 2
        alpha1_right= d1_tilde / (eps + beta1) ** 2
        alpha2_right = d2_tilde / (eps + beta2) ** 2

        sum_alpha_right = alpha0_right + alpha1_right + alpha2_right

        w0_right = alpha0_right / sum_alpha_right
        w1_right = alpha1_right / sum_alpha_right
        w2_right = alpha2_right / sum_alpha_right

        # 4. 组合得到最终重构值
        u_left_i = w0_left * u0_left + w1_left * u1_left+w2_left*u2_left  #u^{-}_{i+1/2}左重构
        u_right_i = w0_right * u0_right + w1_right * u1_right+w2_right*u2_right  # 对于 u^{+}_{i-1/2}右重构
        # 存储结果（注意索引映射）

        if 2 <= i and i <= N + 2:#对于左重构，最后一个点不要
            u_left[i - 2] = u_left_i

        if 3 <= i and i <= N + 3:#对于右重构，第一个点不要
            u_right[i -3] = u_right_i

    return u_left, u_right


def Weno5FDMvector(F, nghost=3):
    """
    向量化的二维WENO5重构，用于欧拉方程（4个分量）
    输入已加ghost cell的矩阵 [4, Ny+2*nghost, Nx+2*nghost]

    参数:
        F: 通量数组 [4, Ny+2*nghost, Nx+2*nghost]

    返回:
        F_left_x, F_right_x: x方向重构 [4, Ny, Nx+1] (内部网格的界面)
        F_left_y, F_right_y: y方向重构 [4, Ny+1, Nx] (内部网格的界面)
    """
    num_components = F.shape[0]
    Ny_tot, Nx_tot = F.shape[1], F.shape[2]
    Ny = Ny_tot - 2 * nghost  # 内部网格y方向点数
    Nx = Nx_tot - 2 * nghost  # 内部网格x方向点数

    # 初始化输出数组 (只存储内部网格的界面值)
    F_left_x = np.zeros((num_components, Ny, Nx + 1))  # [4, Ny, Nx+1]
    F_right_x = np.zeros((num_components, Ny, Nx + 1))  # [4, Ny, Nx+1]
    F_left_y = np.zeros((num_components, Ny + 1, Nx))  # [4, Ny+1, Nx]
    F_right_y = np.zeros((num_components, Ny + 1, Nx))  # [4, Ny+1, Nx]

    # 对每个分量分别进行重构
    for comp in range(num_components):
        # x方向重构（对每一行）
        for j in range(nghost, Ny_tot - nghost):  # 只遍历内部行
            F_1d = F[comp, j, :]
            F_left_1d, F_right_1d = Weno5FDM1D(F_1d)#对每一个物理行进行weno重构
            # 存储内部网格的界面值
            F_left_x[comp, j - nghost, :] = F_left_1d
            F_right_x[comp, j - nghost, :] = F_right_1d

        # y方向重构（对每一列）
        for i in range(nghost, Nx_tot - nghost):  # 只遍历内部列
            F_1d = F[comp, :, i]
            F_left_1d, F_right_1d = Weno5FDM1D(F_1d)#对每一物理列进行Weno重构
            # 存储内部网格的界面值
            F_left_y[comp, :, i - nghost] = F_left_1d
            F_right_y[comp, :, i - nghost] = F_right_1d

    return F_left_x, F_right_x, F_left_y, F_right_y


def hybridreconstruction1D(u_ext, prob_ext):
    #输入的均为一维数组
    N_ext = len(u_ext)
    N = N_ext - 6  # 物理网格点数
    u_left = np.zeros(N + 1)  # 左重构
    u_right = np.zeros(N + 1)  # 右重构
    eps = 1e-6
    for i in range(2, N + 4):
        # 获取当前模板的单元平均值
        u_im2 = u_ext[i - 2]
        u_im1 = u_ext[i - 1]
        u_i = u_ext[i]
        u_ip1 = u_ext[i + 1]
        u_ip2 = u_ext[i + 2]
        '''
        #每一个小区间上，
        同时做右端点的左重构值和左端点的右重构值
        ，并且会对于右重构会多一个最左边的ghost点，
        对于左重构会多一个最右边的ghost点
        '''

        # 检查当前单元是否使用线性重构
        use_linear = prob_ext[i-2]
        if use_linear:
            # 线性重构
            # 对于 右端点u^{-}_{i+1/2} 左重构
            u_left_i = (2 * u_im2 - 13 * u_im1 + 47 * u_i + 27 * u_ip1 - 3 * u_ip2) / 60
            # 对于 左端点u^{+}_{i-1/2} 右重构
            u_right_i = (-3 * u_im2 + 27 * u_im1 + 47 * u_i - 13 * u_ip1 + 2 * u_ip2) / 60
        else:
            # WENO5 重构
            # 最优线性权重
            d0 = 3 / 10
            d1 = 3 / 5
            d2 = 1 / 10

            d0_tilde = 1 / 10
            d1_tilde = 3 / 5
            d2_tilde = 3 / 10

            # 子模板重构值
            # 对于 u^{-}_{i+1/2} 左重构
            u0_left = (2 * u_i + 5 * u_ip1 - u_ip2) / 6
            u1_left = (-u_im1 + 5 * u_i + 2 * u_ip1) / 6
            u2_left = (2 * u_im2 - 7 * u_im1 + 11 * u_i) / 6

            # 对于 u^{+}_{i-1/2} 右重构
            u0_right = (11 * u_i - 7 * u_ip1 + 2 * u_ip2) / 6
            u1_right = (2 * u_im1 + 5 * u_i - u_ip1) / 6
            u2_right = (-u_im2 + 5 * u_im1 + 2 * u_i) / 6

            # 光滑因子
            beta0 = (13 * (u_i - 2 * u_ip1 + u_ip2) ** 2 + 3 * (3 * u_i - 4 * u_ip1 + u_ip2) ** 2) / 12
            beta1 = (13 * (u_im1 - 2 * u_i + u_ip1) ** 2 + 3 * (u_im1 - u_ip1) ** 2) / 12
            beta2 = (13 * (u_im2 - 2 * u_im1 + u_i) ** 2 + 3 * (u_im2 - 4 * u_im1 + 3 * u_i) ** 2) / 12

            # 非线性权重
            # 左重构权重
            alpha0_left = d0 / (eps + beta0) ** 2
            alpha1_left = d1 / (eps + beta1) ** 2
            alpha2_left = d2 / (eps + beta2) ** 2
            sum_alpha_left = alpha0_left + alpha1_left + alpha2_left
            w0_left = alpha0_left / sum_alpha_left
            w1_left = alpha1_left / sum_alpha_left
            w2_left = alpha2_left / sum_alpha_left

            # 右重构权重
            alpha0_right = d0_tilde / (eps + beta0) ** 2
            alpha1_right = d1_tilde / (eps + beta1) ** 2
            alpha2_right = d2_tilde / (eps + beta2) ** 2
            sum_alpha_right = alpha0_right + alpha1_right + alpha2_right
            w0_right = alpha0_right / sum_alpha_right
            w1_right = alpha1_right / sum_alpha_right
            w2_right = alpha2_right / sum_alpha_right

            # 组合重构值
            u_left_i = w0_left * u0_left + w1_left * u1_left + w2_left * u2_left
            u_right_i = w0_right * u0_right + w1_right * u1_right + w2_right * u2_right

        # 存储结果
        if 2 <= i <= N + 2:#对于左重构，最后一个点不要
            u_left[i - 2] = u_left_i
        if 3 <= i <= N + 3:#对于右重构，第一个点不要
            u_right[i - 3] = u_right_i

    return u_left, u_right


def hybridreconstructionvector(F, prob_x_all, prob_y_all, nghost=3, eps=1e-6):
    """
    二维混合重构 - 结合线性重构和WENO5重构
    输入已加ghost cell的矩阵 [4, Ny+2*nghost, Nx+2*nghost]
    prob_x_all：4*(Ny+2)*(Nx+2)
    prob_y_all:4*(Ny+2)*(Nx+2)
    """
    num_components = F.shape[0]
    Ny_tot, Nx_tot = F.shape[1], F.shape[2]
    Ny = Ny_tot - 2 * nghost
    Nx = Nx_tot - 2 * nghost

    # 初始化输出数组
    F_left_x = np.zeros((num_components, Ny, Nx + 1))
    F_right_x = np.zeros((num_components, Ny, Nx + 1))
    F_left_y = np.zeros((num_components, Ny + 1, Nx))
    F_right_y = np.zeros((num_components, Ny + 1, Nx))

    # 对每个分量分别进行重构
    for comp in range(num_components):
        # x方向重构（对每一行）
        for j in range(nghost, Ny_tot - nghost):
            j_internal = j - nghost+1

            # 获取当前行的概率
            prob_row = prob_x_all[comp, j_internal, :]  # 形状 [Nx+2]

            F_1d = F[comp, j, :]  # 取出一行（包含ghost cell）

            # 使用混合重构
            F_left_1d, F_right_1d = hybridreconstruction1D(F_1d, prob_row)

            # 存储内部网格的界面值
            F_left_x[comp, j_internal-1, :] = F_left_1d
            F_right_x[comp, j_internal-1, :] = F_right_1d

        # y方向重构（对每一列）
        for i in range(nghost, Nx_tot - nghost):
            i_internal = i - nghost+1

            # 获取当前列的概率
            prob_col = prob_y_all[comp, :, i_internal]  # 形状 [Ny+1]

            F_1d = F[comp, :, i]  # 取出一列（包含ghost cell）


            # 使用混合重构
            F_left_1d, F_right_1d = hybridreconstruction1D(F_1d, prob_col)

            # 存储内部网格的界面值
            F_left_y[comp, :, i_internal-1] = F_left_1d
            F_right_y[comp, :, i_internal-1] = F_right_1d

    return F_left_x, F_right_x, F_left_y, F_right_y
