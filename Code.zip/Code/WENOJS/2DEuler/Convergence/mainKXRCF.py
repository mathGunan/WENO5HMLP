import csv
import time
import numpy as np
from Errorandorder import L1_error, L2_error, Linf_error, convergence_order
from RK3 import SolverWeno5Rk3_KXRCF
from IC import IC, rho_exact

gamma = 1.4


def compute_single_run(N, T_final=0.3):
    nx = ny = N
    Lx = Ly = 2 * np.pi
    dx = Lx / nx
    dy = Ly / ny
    dt = dx ** (5.0 / 3.0)  # 精准匹配高阶精度时间步长需求

    x = np.linspace(dx / 2, 2 * np.pi - dx / 2, nx)
    y = np.linspace(dy / 2, 2 * np.pi - dy / 2, ny)
    Xc, Yc = np.meshgrid(x, y, indexing='xy')

    U = IC(Xc, Yc)
    t = 0.0
    iteration = 0

    start_time = time.time()
    while t < T_final:
        if t + dt > T_final:
            dt = T_final - t

        # 激活收敛阶状态约束：一步仅执行一次 prob 分配
        U = SolverWeno5Rk3_KXRCF(U, dx, dy, dt, gamma=gamma, threshold=1.0, nghost=3, is_convergence_test=True)

        t += dt
        iteration += 1

    cpu_time = time.time() - start_time
    rho_num = U[0, :, :]
    rho_ex = rho_exact(Xc, Yc, T_final)

    E1 = L1_error(rho_num, rho_ex)
    E2 = L2_error(rho_num, rho_ex)
    Einf = Linf_error(rho_num, rho_ex)

    print(f"网格规模 N={N} 计算完毕，耗时: {cpu_time:.4f}s")
    return (N, dx, E1, E2, Einf, cpu_time)


def main():
    print("====================================================")
    print(" 开启 2D Euler (WENO5 + KXRCF) 空间收敛性自动化验证 ")
    print("====================================================")

    test_N = [20, 40, 80,160]
    T_final = 0.3
    results = []

    for N in test_N:
        res = compute_single_run(N, T_final=T_final)
        results.append(res)

    dxs = [r[1] for r in results]
    errors_L1 = [r[2] for r in results]
    errors_L2 = [r[3] for r in results]
    errors_inf = [r[4] for r in results]
    cputimes = [r[5] for r in results]

    order_l1 = ["--"] + list(convergence_order(errors_L1, dxs))
    order_l2 = ["--"] + list(convergence_order(errors_L2, dxs))
    order_inf = ["--"] + list(convergence_order(errors_inf, dxs))

    csv_filename = "Weno5KXRCFFDM2DEuler_results.csv"
    with open(csv_filename, mode='w', newline='', encoding='utf-8') as f:
        writer = csv.writer(f)
        writer.writerow(
            ["N", "dx", "L1_Error", "L1_Order", "L2_Error", "L2_Order", "Linf_Error", "Linf_Order", "CPU_Time(s)"])
        for i, r in enumerate(results):
            o1 = f"{order_l1[i]:.2f}" if isinstance(order_l1[i], float) else order_l1[i]
            o2 = f"{order_l2[i]:.2f}" if isinstance(order_l2[i], float) else order_l2[i]
            oinf = f"{order_inf[i]:.2f}" if isinstance(order_inf[i], float) else order_inf[i]
            writer.writerow(
                [r[0], f"{r[1]:.6e}", f"{errors_L1[i]:.6e}", o1, f"{errors_L2[i]:.6e}", o2, f"{errors_inf[i]:.6e}",
                 oinf, f"{cputimes[i]:.4f}"])

    print(f"\n成果成功写入本地学术文件: {csv_filename}")


if __name__ == "__main__":
    main()