import csv
import time
import numpy as np
import torch
from RK3 import *  # 完美对齐您修改后的RK3函数名
from IC import *
from model import *
from helperfunction import *

gamma = 1.4


def compute_single_run_kxrcf(N, T_final=0.8):
    """
    单次网格规模的 KXRCF 探测器 Riemann 问题计算算子
    """
    nx = ny = N
    Lx = Ly = 1.0
    dx = Lx / nx
    dy = Ly / ny

    # 网格中心坐标
    x = np.linspace(dx / 2, Lx - dx / 2, nx)
    y = np.linspace(dy / 2, Ly - dy / 2, ny)
    Xc, Yc = np.meshgrid(x, y, indexing='xy')

    # 初始条件
    U = riemann_IC(Xc, Yc)  # shape (4, ny, nx)

    # 时间推进
    t = 0.0
    iteration = 0

    start_time = time.time()

    while t < T_final:
        dt = compute_time_step(U, dx, dy)  # 基准步长解算
        if t + dt > T_final:
            dt = T_final - t

        # 调用传统不连续性探测版 TVD-RK3 求解器
        # 严格保持学术标准阈值 threshold=1.0 (Li & Qiu 文献规范)
        U = SolverKXRCFRk3(
            U_phys=U,
            dx=dx,
            dy=dy,
            dt=dt,
            gamma=gamma,
            threshold=1.0,
            nghost=3,
            epsilon=1e-6
        )
        t += dt
        iteration += 1

        if iteration % 50 == 0:
            progress = t / T_final * 100
            print(f"N={N}: 进度 {progress:.1f}%, 当前迭代步数 {iteration}")

    cpu_time = time.time() - start_time
    print(f"网格规模 {N}x{N} (KXRCF) 计算完毕，总耗时: {cpu_time:.4f} 秒")

    return Xc, Yc, U, cpu_time


def main():
    print("====================================================")
    print("  开启 2D Euler (WENO5KXRCF + Roe) Riemann 问题计算  ")
    print("====================================================")

    N = 400  # 先用小网格测试, 目标是 800*800
    T_final = 0.8

    # 执行仿真计算
    Xc, Yc, U_final, cpu_time = compute_single_run_kxrcf(N, T_final=T_final)

    # 提取最后时刻的 4 个完整物理守恒量分量
    rho_num = U_final[0, :, :]
    rhou_num = U_final[1, :, :]
    rhov_num = U_final[2, :, :]
    E_num = U_final[3, :, :]

    # 将二维空间网格及流场展平为一维列，以便标准 CSV 表格化存储
    x_flat = Xc.flatten()
    y_flat = Yc.flatten()
    rho_flat = rho_num.flatten()
    rhou_flat = rhou_num.flatten()
    rhov_flat = rhov_num.flatten()
    E_flat = E_num.flatten()

    # 规范化 CSV 命名，与 MLP 版本形成完美对比组
    csv_filename = f"Weno5KXRCF2DEulerRiemann_{N}x{N}_results.csv"

    with open(csv_filename, mode='w', newline='', encoding='utf-8') as f:
        writer = csv.writer(f)

        # 1. 在 CSV 头部写入全局元数据（便于读取 CPU 时间并进行效率收敛性对比）
        writer.writerow(["# Global Metadata", f"Total_CPU_Time_Seconds: {cpu_time:.6f}"])

        # 2. 写入标准的列标题
        writer.writerow(["X", "Y", "Density(rho)", "Momentum_X(rho_u)", "Momentum_Y(rho_v)", "Energy(E)"])

        # 3. 逐行写入各个离散网格点上的数值解
        for i in range(len(x_flat)):
            writer.writerow([
                f"{x_flat[i]:.6e}",
                f"{y_flat[i]:.6e}",
                f"{rho_flat[i]:.6e}",
                f"{rhou_flat[i]:.6e}",
                f"{rhov_flat[i]:.6e}",
                f"{E_flat[i]:.6e}"
            ])

    print("----------------------------------------------------")
    print(f"KXRCF 流场解及时间度量保存完毕。最终 CSV 文件路径: {csv_filename}")
    print("====================================================")


if __name__ == "__main__":
    main()