import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

'''
Joint Post-process for 2D Euler Riemann Equation: 3x3 子图联合二维等高线绘制 (纯线条、Viridis 渐变色、无右侧大标题版)
横向对比: Column 1 (WENO5-JS), Column 2 (WENO5-KXRCF), Column 3 (WENO5-H-MLP)
纵向对比: Row 1 (N=100), Row 2 (N=200), Row 3 (N=400)
'''


def load_csv_data(filepath, N):
    """
    高效读取 CSV 数据，跳过元数据行，并将展平的数据重构为二维矩阵
    """
    if not os.path.exists(filepath):
        print(f"警告: 未找到文件 {filepath}")
        return None, None, None

    skip_rows = 0
    with open(filepath, 'r', encoding='utf-8') as f:
        for line in f:
            if line.startswith('#'):
                skip_rows += 1
            else:
                break

    df = pd.read_csv(filepath, skiprows=skip_rows)

    # 重构为 (N, N) 空间矩阵
    X = df['X'].values.reshape(N, N)
    Y = df['Y'].values.reshape(N, N)
    rho = df['Density(rho)'].values.reshape(N, N)

    return X, Y, rho


def main():
    # 设定学术期刊高分辨率出版标准
    plt.rcParams.update({
        'text.usetex': False
    })

    row_resolutions = [100, 200, 400]

    # 列（Columns）：包含绘制所需的标签、文件名模板和颜色
    col_schemes = [
        {'key': 'PureWENO5', 'label': 'WENO5', 'template': "PureWENO5_2DEulerRiemann_{N}x{N}_results.csv"},
        {'key': 'Weno5KXRCF', 'label': 'KXRCF', 'template': "Weno5KXRCF2DEulerRiemann_{N}x{N}_results.csv"},
        {'key': 'Weno5MLP', 'label': 'MLP', 'template': "Weno5MLP2DEulerRiemann_{N}x{N}_results.csv"}
    ]

    # 自动化生成学术子图序号 ['(a)', '(b)', ..., '(i)']
    sub_indices = [f"({chr(97 + i)})" for i in range(9)]

    # 调整总画布比例为 30x31，预留出底部大尺寸小标题空间
    fig, axes = plt.subplots(3, 3, figsize=(30, 31))

    # 范围 0.1 到 1.8，共 34 条等高线
    global_levels = np.linspace(0.1, 1.8, 34)
    cmap_choice = 'viridis'

    # 遍历 3x3 矩阵开始绘制
    for row_idx, N in enumerate(row_resolutions):
        for col_idx, scheme in enumerate(col_schemes):
            ax = axes[row_idx, col_idx]

            # 动态生成当前位置对应的 CSV 文件名
            filename = scheme['template'].format(N=N)
            X, Y, rho = load_csv_data(filename, N)

            if rho is not None:
                # 使用 ax.contour（不填充颜色块），同时应用 viridis 渐变色作用于线条本身
                ax.contour(X, Y, rho,
                           levels=global_levels,
                           cmap=cmap_choice,
                           linewidths=1.0)
            else:
                ax.text(0.5, 0.5, f'Data Missing\n{scheme["label"]}\nN = {N}',
                        ha='center', va='center', fontsize=24, color='red')
                ax.set_xlim(0.0, 1.0)
                ax.set_ylim(0.0, 1.0)
                continue

            # 保持物理长宽比 1:1
            ax.set_aspect('equal')
            ax.grid(True, linestyle=':', alpha=0.3)

            # =========================================================================
            # 【极致刻度与基本几何界限设置】
            # =========================================================================
            ax.set_xlim(0.0, 1.0)
            ax.set_ylim(0.0, 1.0)
            ax.set_xticks([0.0, 0.5, 1.0])
            ax.set_yticks([0.0, 0.5, 1.0])

            # =========================================================================
            # 【精确控标：X 轴全开，Y 轴仅第一列有标签数字】
            # =========================================================================
            # 1. X 轴配置：所有子图全面显示 X 轴刻度大数字和标签
            ax.tick_params(axis='x', direction='in', top=True, right=True,
                           length=5, width=1.0, labelsize=38, pad=20)
            ax.set_xlabel('X', fontsize=45, labelpad=18)

            # 2. Y 轴配置：只有第一列（col_idx == 0）才有数字和 ylabel，其余完全隐去
            if col_idx == 0:
                ax.set_ylabel('Y', fontsize=45, labelpad=15)
                ax.tick_params(axis='y', direction='in', top=True, right=True,
                               length=5, width=1.0, labelsize=38, pad=20)
            else:
                # 非第一列图，内部朝内的刻度线保留（学术规范），但隐藏数字
                ax.tick_params(axis='y', direction='in', top=True, right=True,
                               length=5, width=1.0, labelleft=False)

            # =========================================================================
            # 🟢 【子图正下方小标题精密定位（整合方法名与显式二维网格）】
            # =========================================================================
            flat_idx = row_idx * 3 + col_idx
            full_title = fr"{sub_indices[flat_idx]} {scheme['label']} ($\mathrm{{N}}_x=\mathrm{{N}}_y={N}$)"

            # 沿用控制间距下的标题高度
            title_y_position = -0.32
            ax.text(0.5, title_y_position, full_title, transform=ax.transAxes,
                    fontsize=45, va='top', ha='center')

    # =========================================================================
    # 【大图压缩留白区】：强制压缩 padding，将空间完美让渡给绘图域
    # =========================================================================
    plt.tight_layout(rect=[0.04, 0.04, 0.96, 0.97], h_pad=3.5, w_pad=3.0)

    output_pdf = "2D_Euler_Riemann1_compare.pdf"
    plt.savefig(output_pdf, dpi=300)
    print(f"\n📊 [绘图成功] 整合格式的 3x3 高清纯线条 Euler 图像已成功导出至: {output_pdf}")
    plt.show()


if __name__ == "__main__":
    main()