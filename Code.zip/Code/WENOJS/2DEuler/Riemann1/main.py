import csv
import time
import numpy as np
from RK3 import SolverWeno5Rk3  # 严格导入刚刚为您改写好的纯 WENO5 RK3 推进器
from IC import *
from helperfunction import *

gamma = 1.4



def compute_single_run(N, T_final=0.8):
    """
    单次网格规模的纯五阶 WENO5 基准 Riemann 问题计算算子
    """
    nx = ny = N
    Lx = Ly = 1.0
    dx = Lx / nx
    dy = Ly / ny

    # 网格中心坐标
    x = np.linspace(dx / 2, Lx - dx / 2, nx)
    y = np.linspace(dy / 2, Ly - dy / 2, ny)
    Xc, Yc = np.meshgrid(x, y, indexing='xy')

    # 初始条件
    U = riemann_IC(Xc, Yc)  # shape (4, ny, nx)

    # 时间推进
    t = 0.0
    iteration = 0

    start_time = time.time()

    while t < T_final:
        # 基于当前流场动态计算 CFL 约束步长
        dt = compute_time_step(U, dx, dy, gamma)

        if t + dt > T_final:
            dt = T_final - t

        # 调用全场标准五阶 WENO5 + Roe 推进器
        U = SolverWeno5Rk3(
            U_phys=U,
            dx=dx,
            dy=dy,
            dt=dt,
            gamma=gamma,
            nghost=3,
            epsilon=1e-6
        )
        t += dt
        iteration += 1

        # 仅在每 50 步迭代时执行一次高效的进度输出
        if iteration % 50 == 0:
            progress = (t / T_final) * 100
            print(f"N={N}: 进度 {progress:.1f}%, 迭代步数 {iteration}, 物理时间 t={t:.4f}")

    cpu_time = time.time() - start_time
    print(f"网格规模 {N}x{N} (Pure WENO5) 计算完毕，总耗时: {cpu_time:.4f} 秒")

    return Xc, Yc, U, cpu_time


def main():
    print("====================================================")
    print("  开启 2D Euler (Pure WENO5 + Roe) Riemann 问题基准计算  ")
    print("====================================================")

    N = 400  # 先用小网格测试, 目标是 800*800
    T_final = 0.8

    # 执行仿真计算
    Xc, Yc, U_final, cpu_time = compute_single_run(N, T_final=T_final)

    # 提取最后时刻的 4 个完整守恒量分量
    rho_num = U_final[0, :, :]
    rhou_num = U_final[1, :, :]
    rhov_num = U_final[2, :, :]
    E_num = U_final[3, :, :]

    # 将二维空间网格及流场展平为一维列，以便标准 CSV 表格化存储
    x_flat = Xc.flatten()
    y_flat = Yc.flatten()
    rho_flat = rho_num.flatten()
    rhou_flat = rhou_num.flatten()
    rhov_flat = rhov_num.flatten()
    E_flat = E_num.flatten()

    # 规范化 CSV 命名
    csv_filename = f"PureWENO5_2DEulerRiemann_{N}x{N}_results.csv"

    with open(csv_filename, mode='w', newline='', encoding='utf-8') as f:
        writer = csv.writer(f)

        # 1. 在 CSV 头部写入全局元数据
        writer.writerow(["# Global Metadata", f"Total_CPU_Time_Seconds: {cpu_time:.6f}"])

        # 2. 写入标准的【守恒量】列标题
        writer.writerow(["X", "Y", "Density(rho)", "Momentum_X(rho_u)", "Momentum_Y(rho_v)", "Energy(E)"])

        # 3. 逐行写入流场各网格点上的位置与守恒量分量
        for i in range(len(x_flat)):
            writer.writerow([
                f"{x_flat[i]:.6e}",
                f"{y_flat[i]:.6e}",
                f"{rho_flat[i]:.6e}",
                f"{rhou_flat[i]:.6e}",
                f"{rhov_flat[i]:.6e}",
                f"{E_flat[i]:.6e}"
            ])

    print("----------------------------------------------------")
    print(f"纯 WENO5 基准流场守恒量数据保存完毕。最终 CSV 文件路径: {csv_filename}")
    print("====================================================")


if __name__ == "__main__":
    main()