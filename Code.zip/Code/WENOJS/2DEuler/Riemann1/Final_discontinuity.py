import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import torch
from helperfunction import *

'''
Joint Post-process for 2D Euler Riemann Discontinuity Detectors: 3x4 子图联合二维间断点综合汇总大图
横向对比 (Columns):
  - Col 1: MLP (X Direction)   |  Col 2: KXRCF (X Direction)
  - Col 3: MLP (Y Direction)   |  Col 4: KXRCF (Y Direction)
纵向对比 (Rows):
  - Row 1 (N=100), Row 2 (N=200), Row 3 (N=400)
物理与边界约束：
  1. 严格适配文件名：Weno5MLP2DEulerRiemann_{N}x{N}_results.csv / Weno5KXRCF2DEulerRiemann_{N}x{N}_results.csv
  2. 自动过滤带有 '#' 的全局元数据行，并完美映射自定义列名（如 Density(rho) 等）。
  3. 边界条件在函数内部采用严格的零梯度外流边界（Outflow / Neumann BC）进行 nghost=3 的全向外推。
  4. 画面排版约束：3x4 所有子图无死角强制补齐 xlabel 与 xticks 刻度。
'''

gamma = 1.4
model = None
device = None


def get_model():
    """全局获取神经网络模型"""
    global model, device
    if model is None:
        if torch.backends.mps.is_available():
            device = torch.device("mps")
        else:
            device = torch.device("cpu")

        ckpt = torch.load('best_model.pth', map_location=device)
        model = Weno5FDMMLP().to(device)
        model.load_state_dict(ckpt['model_state_dict'])
        model.eval()
        print("▶ [物理绑定] 神经网络模型加载完成，输入特征严格绑定物理比熵场切片。")
    return model, device


def load_and_predict_euler_riemann1(N, mlp_model, mlp_device, kxrcf_threshold=1.0, mlp_threshold=0.5):
    """
    单次读取各解算器的 CSV 文件，由守恒量精确还原比熵，在内部处理 Outflow 幽灵层。
    """
    nghost = 3
    dx = 1.0 / N
    dy = 1.0 / N

    # 严格对齐最新文件名
    mlp_file = f"Weno5MLP2DEulerRiemann_{N}x{N}_results.csv"
    kxrcf_file = f"Weno5KXRCF2DEulerRiemann_{N}x{N}_results.csv"

    if not os.path.exists(mlp_file) or not os.path.exists(kxrcf_file):
        print(f"❌ 警告: 未找到 N={N} 的对应数据文件，跳过该网格层级。")
        return None, None, None, None, None, None

    # ---- [数据流 1: MLP 分支] ----
    df_mlp = pd.read_csv(mlp_file, comment='#')

    X_mesh = df_mlp["X"].values.reshape(N, N, order='C')
    Y_mesh = df_mlp["Y"].values.reshape(N, N, order='C')

    rho_m = np.maximum(df_mlp["Density(rho)"].values.reshape(N, N, order='C'), 1e-14)
    u_m = df_mlp["Momentum_X(rho_u)"].values.reshape(N, N, order='C') / rho_m
    v_m = df_mlp["Momentum_Y(rho_v)"].values.reshape(N, N, order='C') / rho_m
    E_m = df_mlp["Energy(E)"].values.reshape(N, N, order='C')
    p_m = np.maximum((gamma - 1.0) * (E_m - 0.5 * rho_m * (u_m ** 2 + v_m ** 2)), 1e-14)
    entropy_mlp_core = p_m / np.maximum(rho_m ** gamma, 1e-12)

    # 适配零梯度外流边界条件（Outflow BC）
    entropy_mlp = np.zeros((N + 2 * nghost, N + 2 * nghost), dtype=np.float32)
    entropy_mlp[nghost:-nghost, nghost:-nghost] = entropy_mlp_core
    for k in range(nghost):
        entropy_mlp[nghost:-nghost, k] = entropy_mlp_core[:, 0]  # 左
        entropy_mlp[nghost:-nghost, -nghost + k] = entropy_mlp_core[:, -1]  # 右
    for k in range(nghost):
        entropy_mlp[k, :] = entropy_mlp[nghost, :]  # 下
        entropy_mlp[-nghost + k, :] = entropy_mlp[-nghost - 1, :]  # 上

    # ---- [数据流 2: KXRCF 分支] ----
    df_kxrcf = pd.read_csv(kxrcf_file, comment='#')

    rho_k = np.maximum(df_kxrcf["Density(rho)"].values.reshape(N, N, order='C'), 1e-14)
    u_k = df_kxrcf["Momentum_X(rho_u)"].values.reshape(N, N, order='C') / rho_k
    v_k = df_kxrcf["Momentum_Y(rho_v)"].values.reshape(N, N, order='C') / rho_k
    E_k = df_kxrcf["Energy(E)"].values.reshape(N, N, order='C')
    p_k = np.maximum((gamma - 1.0) * (E_k - 0.5 * rho_k * (u_k ** 2 + v_k ** 2)), 1e-14)
    entropy_kxrcf_core = p_k / np.maximum(rho_k ** gamma, 1e-12)

    # 适配零梯度外流边界条件（Outflow BC）
    entropy_kxrcf = np.zeros((N + 2 * nghost, N + 2 * nghost), dtype=np.float32)
    entropy_kxrcf[nghost:-nghost, nghost:-nghost] = entropy_kxrcf_core
    for k in range(nghost):
        entropy_kxrcf[nghost:-nghost, k] = entropy_kxrcf_core[:, 0]  # 左
        entropy_kxrcf[nghost:-nghost, -nghost + k] = entropy_kxrcf_core[:, -1]  # 右
    for k in range(nghost):
        entropy_kxrcf[k, :] = entropy_kxrcf[nghost, :]  # 下
        entropy_kxrcf[-nghost + k, :] = entropy_kxrcf[-nghost - 1, :]  # 上

    # =========================================================================
    # 初始化 2D 内场 troubled-point 布尔遮罩 (Shape: N x N)
    # =========================================================================
    mask_mlp_x = np.zeros((N, N), dtype=bool)
    mask_mlp_y = np.zeros((N, N), dtype=bool)
    mask_kxrcf_x = np.zeros((N, N), dtype=bool)
    mask_kxrcf_y = np.zeros((N, N), dtype=bool)

    # 🛠️ 1. X 方向扫描
    for j in range(N):
        jj = j + nghost

        # [MLP 行切片预测]
        entropy_slice_x_m = entropy_mlp[jj, :]
        prob_array_x_m = predict_2d(entropy_slice_x_m, dx, mlp_model, mlp_device)
        prob_x_m = np.where(prob_array_x_m > mlp_threshold, 1.0, 0.0)
        for i in range(N):
            if prob_x_m[i] == 0.0:
                mask_mlp_x[j, i] = True

        # [KXRCF 行切片计算]
        for i in range(N):
            idx_ext = i + nghost
            u0_l = (entropy_kxrcf[jj, idx_ext - 2] + 22 * entropy_kxrcf[jj, idx_ext - 1] + entropy_kxrcf[jj, idx_ext]) / 24.0
            u1_l = (entropy_kxrcf[jj, idx_ext - 2] - entropy_kxrcf[jj, idx_ext - 2]) * 0.0 + (entropy_kxrcf[jj, idx_ext] - entropy_kxrcf[jj, idx_ext - 2]) / 2.0
            u2_l = (entropy_kxrcf[jj, idx_ext - 2] - 2 * entropy_kxrcf[jj, idx_ext - 1] + entropy_kxrcf[jj, idx_ext]) / 2.0

            u0_c = (entropy_kxrcf[jj, idx_ext - 1] + 22 * entropy_kxrcf[jj, idx_ext] + entropy_kxrcf[jj, idx_ext + 1]) / 24.0
            u1_c = (entropy_kxrcf[jj, idx_ext + 1] - entropy_kxrcf[jj, idx_ext - 1]) / 2.0
            u2_c = (entropy_kxrcf[jj, idx_ext - 1] - 2 * entropy_kxrcf[jj, idx_ext] + entropy_kxrcf[jj, idx_ext + 1]) / 2.0

            u0_r = (entropy_kxrcf[jj, idx_ext] + 22 * entropy_kxrcf[jj, idx_ext + 1] + entropy_kxrcf[jj, idx_ext + 2]) / 24.0
            u1_r = (entropy_kxrcf[jj, idx_ext + 2] - entropy_kxrcf[jj, idx_ext]) / 2.0
            u2_r = (entropy_kxrcf[jj, idx_ext] - 2 * entropy_kxrcf[jj, idx_ext + 1] + entropy_kxrcf[jj, idx_ext + 2]) / 2.0

            edge_R_of_L = u0_l + 0.5 * u1_l + (1.0 / 6.0) * u2_l
            edge_L_of_C = u0_c - 0.5 * u1_c + (1.0 / 6.0) * u2_c
            edge_R_of_C = u0_c + 0.5 * u1_c + (1.0 / 6.0) * u2_c
            edge_L_of_R = u0_r - 0.5 * u1_r + (1.0 / 6.0) * u2_r

            max_jump = np.max([np.abs(edge_L_of_C - edge_R_of_L), np.abs(edge_L_of_R - edge_R_of_C)])
            denominator = (dx ** 2.5) * (np.abs(entropy_kxrcf[jj, idx_ext]) + 1e-10)

            if (max_jump / denominator) > kxrcf_threshold:
                mask_kxrcf_x[j, i] = True

    # 🛠️ 2. Y 方向扫描
    for i in range(N):
        ii = i + nghost

        # [MLP 列切片预测]
        entropy_slice_y_m = entropy_mlp[:, ii]
        prob_array_y_m = predict_2d(entropy_slice_y_m, dy, mlp_model, mlp_device)
        prob_y_m = np.where(prob_array_y_m > mlp_threshold, 1.0, 0.0)
        for j in range(N):
            if prob_y_m[j] == 0.0:
                mask_mlp_y[j, i] = True

        # [KXRCF 列切片计算]
        for j in range(N):
            idx_ext = j + nghost
            u0_l = (entropy_kxrcf[idx_ext - 2, ii] + 22 * entropy_kxrcf[idx_ext - 1, ii] + entropy_kxrcf[idx_ext, ii]) / 24.0
            u1_l = (entropy_kxrcf[idx_ext, ii] - entropy_kxrcf[idx_ext - 2, ii]) / 2.0
            u2_l = (entropy_kxrcf[idx_ext - 2, ii] - 2 * entropy_kxrcf[idx_ext - 1, ii] + entropy_kxrcf[idx_ext, ii]) / 2.0

            u0_c = (entropy_kxrcf[idx_ext - 1, ii] + 22 * entropy_kxrcf[idx_ext, ii] + entropy_kxrcf[idx_ext + 1, ii]) / 24.0
            u1_c = (entropy_kxrcf[idx_ext + 1, ii] - entropy_kxrcf[idx_ext - 1, ii]) / 2.0
            u2_c = (entropy_kxrcf[idx_ext - 1, ii] - 2 * entropy_kxrcf[idx_ext, ii] + entropy_kxrcf[idx_ext + 1, ii]) / 2.0

            u0_r = (entropy_kxrcf[idx_ext, ii] + 22 * entropy_kxrcf[idx_ext + 1, ii] + entropy_kxrcf[idx_ext + 2, ii]) / 24.0
            u1_r = (entropy_kxrcf[idx_ext + 2, ii] - entropy_kxrcf[idx_ext, ii]) / 2.0
            u2_r = (entropy_kxrcf[idx_ext, ii] - 2 * entropy_kxrcf[idx_ext + 1, ii] + entropy_kxrcf[idx_ext + 2, ii]) / 2.0

            edge_R_of_L = u0_l + 0.5 * u1_l + (1.0 / 6.0) * u2_l
            edge_L_of_C = u0_c - 0.5 * u1_c + (1.0 / 6.0) * u2_c
            edge_R_of_C = u0_c + 0.5 * u1_c + (1.0 / 6.0) * u2_c
            edge_L_of_R = u0_r - 0.5 * u1_r + (1.0 / 6.0) * u2_r

            max_jump = np.max([np.abs(edge_L_of_C - edge_R_of_L), np.abs(edge_L_of_R - edge_R_of_C)])
            denominator = (dy ** 2.5) * (np.abs(entropy_kxrcf[idx_ext, ii]) + 1e-10)

            if (max_jump / denominator) > kxrcf_threshold:
                mask_kxrcf_y[j, i] = True

    print(f"   📊 网格 N={N:<3} 物理比熵扫描完毕 | MLP [X:{np.sum(mask_mlp_x):<4} Y:{np.sum(mask_mlp_y):<4}] | KXRCF [X:{np.sum(mask_kxrcf_x):<4} Y:{np.sum(mask_kxrcf_y):<4}]")
    return X_mesh, Y_mesh, mask_mlp_x, mask_mlp_y, mask_kxrcf_x, mask_kxrcf_y


def main():
    nx_list = [100, 200, 400]

    col_configs = [
        ('MLP', 2, 'X Direction'),  # Col 1
        ('KXRCF', 4, 'X Direction'),  # Col 2
        ('MLP', 3, 'Y Direction'),  # Col 3
        ('KXRCF', 5, 'Y Direction')  # Col 4
    ]

    mlp_model, mlp_device = get_model()
    sub_indices = [f"({chr(97 + i)})" for i in range(12)]

    print(fr"====== 🚀 正在启动 2D Euler Riemann 间断探测多轴汇总图生成 ======")

    data_cache = {}
    for N in nx_list:
        res = load_and_predict_euler_riemann1(N, mlp_model, mlp_device, kxrcf_threshold=1.0, mlp_threshold=0.5)
        if res[0] is not None:
            data_cache[N] = res

    print("========================================================================\n")

    stats_summary = []

    # 初始化高质量大画布
    fig, axes = plt.subplots(3, 4, figsize=(38, 31))

    for row_idx, N in enumerate(nx_list):
        if N not in data_cache:
            continue
        row_data = data_cache[N]

        X_flat = row_data[0].flatten()
        Y_flat = row_data[1].flatten()

        for col_idx, (method, data_idx, dir_name) in enumerate(col_configs):
            ax = axes[row_idx, col_idx]
            current_mask_flat = row_data[data_idx].flatten()

            total_points = N * N
            troubled_points = np.sum(current_mask_flat)
            percentage = (troubled_points / total_points) * 100

            stats_summary.append({
                "Resolution": f"{N}x{N}",
                "Method": method,
                "Direction": dir_name,
                "Troubled_Count": troubled_points,
                "Total_Count": total_points,
                "Ratio_Pct": percentage
            })

            marker_size = 25 if N <= 100 else (10 if N <= 200 else 3)

            ax.scatter(X_flat[current_mask_flat], Y_flat[current_mask_flat],
                       s=marker_size, c='red', marker='s', edgecolors='none')

            ax.set_aspect('equal')
            ax.set_xlim(0.0, 1.0)
            ax.set_ylim(0.0, 1.0)
            ax.set_xticks([0.0, 0.5, 1.0])
            ax.set_yticks([0.0, 0.5, 1.0])

            # ✨ [核心修改] 彻底打破行限制，让 3x4 每一张子图均拥有统一的高清 X 轴刻度和标签
            ax.tick_params(axis='x', direction='in', top=True, right=True, length=5, width=1.0, labelsize=38, pad=20)
            ax.set_xlabel('X', fontsize=45, labelpad=18)

            # Y轴控制：依然只在最左侧第一列激活刻度，防止子图之间过度重合、保持学术美感
            if col_idx == 0:
                ax.set_ylabel('Y', fontsize=45, labelpad=15)
                ax.tick_params(axis='y', direction='in', top=True, right=True, length=5, width=1.0, labelsize=38, pad=20)
            else:
                ax.tick_params(axis='y', direction='in', top=True, right=True, length=5, width=1.0, labelleft=False)

            # 双行子图小标题排版
            flat_idx = row_idx * 4 + col_idx

            first_line_title = fr"{sub_indices[flat_idx]} {method}, {dir_name}"
            ax.text(0.5, -0.32, transform=ax.transAxes, s=first_line_title, fontsize=40, va='top', ha='center')

            second_line_mesh = fr"($N_x=N_y={N}$)"
            ax.text(0.5, -0.42, transform=ax.transAxes, s=second_line_mesh, fontsize=40, va='top', ha='center')

    # 终端量化统计表独立输出
    print("\n" + "=" * 80)
    print(f"{'2D Euler Riemann 间断点探测百分比量化统计表':^72}")
    print("=" * 80)
    print(f"{'网格规模':<12} | {'探测算子':<8} | {'扫描方向':<14} | {'间断点数':<10} | {'总网格数':<10} | {'占比 (Ratio)'}")
    print("-" * 80)
    for item in stats_summary:
        print(f"{item['Resolution']:<12} | {item['Method']:<8} | {item['Direction']:<14} | {item['Troubled_Count']:<10} | {item['Total_Count']:<10} | {item['Ratio_Pct']:.4f}%")
    print("=" * 80 + "\n")

    # 紧凑版面微调：4.5 的纵向填充间距（h_pad）可以完美包容多出来的第一、二行 X 标签，绝不重叠
    plt.tight_layout(rect=[0.03, 0.05, 0.97, 0.97], h_pad=4.5, w_pad=2.5)

    output_pdf = "2DEuler_Riemann1_Discontinuity.pdf"
    plt.savefig(output_pdf, dpi=300)
    print(f"📊 3x4 综合大图已保存至: {output_pdf}")
    plt.show()


if __name__ == "__main__":
    main()