import csv
import time
import numpy as np
import torch
from RK3 import SolverWeno5Rk3_MLP  # 完美对齐您修改后的RK3函数名
from IC import *
from model import *
from helperfunction import *

gamma = 1.4


def compute_single_run(N, model, device, T_final=0.8):
    """
    单次网格规模的 Riemann 问题计算算子（透传 model 和 device，避免重复加载）
    """
    nx = ny = N
    Lx = Ly = 1.0
    dx = Lx / nx
    dy = Ly / ny

    # 网格中心坐标
    x = np.linspace(dx / 2, Lx - dx / 2, nx)
    y = np.linspace(dy / 2, Ly - dy / 2, ny)
    Xc, Yc = np.meshgrid(x, y, indexing='xy')

    # 初始条件
    U = riemann_IC(Xc, Yc)  # shape (4, ny, nx)

    # 时间推进
    t = 0.0
    iteration = 0

    start_time = time.time()

    # 冻结 PyTorch 梯度引擎，加速内场前向特征推理过程
    with torch.no_grad():
        while t < T_final:
            dt = compute_time_step(U, dx, dy)  # 基准步长解算
            if t + dt > T_final:
                dt = T_final - t

            # 调用内场判定版 TVD-RK3 求解器
            U = SolverWeno5Rk3_MLP(
                U_phys=U,
                dx=dx,
                dy=dy,
                dt=dt,
                model=model,
                device=device,
                gamma=gamma,
                threshold=0.5,
                nghost=3
            )
            t += dt
            iteration += 1

            if iteration % 50 == 0:
                progress = t / T_final * 100
                print(f"N={N}: 进度 {progress:.1f}%, 当前迭代步数 {iteration}")

    cpu_time = time.time() - start_time
    print(f"网格规模 {N}x{N} 计算完毕，总耗时: {cpu_time:.4f} 秒")

    return Xc, Yc, U, cpu_time


def main():
    print("====================================================")
    print("  开启 2D Euler (WENO5MLP + Roe) Riemann 问题常态化计算  ")
    print("====================================================")

    # 全局只加载一次神经网络模型与硬件后端
    model, device = get_model()
    print(f"当前计算后端硬件映射为: {device}")

    N = 400  # 先用小网格测试, 目标是 800*800
    T_final = 0.8

    # 执行仿真计算
    Xc, Yc, U_final, cpu_time = compute_single_run(N, model, device, T_final=T_final)

    # 提取最后时刻的4个完整守恒量分量
    rho_num = U_final[0, :, :]
    rhou_num = U_final[1, :, :]
    rhov_num = U_final[2, :, :]
    E_num = U_final[3, :, :]

    # 将二维空间网格展平为一维列，以便标准 CSV 表格化存储
    x_flat = Xc.flatten()
    y_flat = Yc.flatten()
    rho_flat = rho_num.flatten()
    rhou_flat = rhou_num.flatten()
    rhov_flat = rhov_num.flatten()
    E_flat = E_num.flatten()

    # 规范化 CSV 命名
    csv_filename = f"Weno5MLP2DEulerRiemann_{N}x{N}_results.csv"

    with open(csv_filename, mode='w', newline='', encoding='utf-8') as f:
        writer = csv.writer(f)

        # 1. 在 CSV 头部前两行写入全局元数据（如总 CPU 时间）
        writer.writerow(["# Global Metadata", f"Total_CPU_Time_Seconds: {cpu_time:.6f}"])

        # 2. 写入标准的列标题
        writer.writerow(["X", "Y", "Density(rho)", "Momentum_X(rho_u)", "Momentum_Y(rho_v)", "Energy(E)"])

        # 3. 逐行写入流场各网格点上的位置与守恒量分量
        for i in range(len(x_flat)):
            writer.writerow([
                f"{x_flat[i]:.6e}",
                f"{y_flat[i]:.6e}",
                f"{rho_flat[i]:.6e}",
                f"{rhou_flat[i]:.6e}",
                f"{rhov_flat[i]:.6e}",
                f"{E_flat[i]:.6e}"
            ])

    print("----------------------------------------------------")
    print(f"流场数据及时间度量保存完毕。最终 CSV 文件路径: {csv_filename}")
    print("====================================================")


if __name__ == "__main__":
    main()