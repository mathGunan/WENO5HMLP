import numpy as np
def riemann_IC(Xc, Yc):
    """
    四象限二维 Riemann 问题（Lax–Liu 型）初始条件
    输入:
        Xc, Yc: 网格中心坐标数组，形状 (Ny, Nx)
    输出:
        U: 守恒量矩阵, shape (4, Ny, Nx)
           [rho, rho*u, rho*v, E]
    """
    GAMMA = 1.4
    Ny, Nx = Xc.shape

    # 分界线
    x0, y0 = 0.8, 0.8

    # 四象限状态
    # Q1: x > x0, y > y0
    rho1, u1, v1, p1 = 1.5,     0.0,   0.0,   1.5
    # Q2: x < x0, y > y0
    rho2, u2, v2, p2 = 0.5323,  1.206, 0.0,   0.3
    # Q3: x < x0, y < y0
    rho3, u3, v3, p3 = 0.138,   1.206, 1.206, 0.029
    # Q4: x > x0, y < y0
    rho4, u4, v4, p4 = 0.5323,  0.0,   1.206, 0.3

    # 创建空数组
    rho = np.zeros_like(Xc)
    u   = np.zeros_like(Xc)
    v   = np.zeros_like(Xc)
    p   = np.zeros_like(Xc)

    # 使用布尔掩码向量化赋值 —— 比双重 for 循环快很多
    q1 = (Xc >= x0) & (Yc >= y0)
    q2 = (Xc <  x0) & (Yc >= y0)
    q3 = (Xc <  x0) & (Yc <  y0)
    q4 = (Xc >= x0) & (Yc <  y0)

    rho[q1], u[q1], v[q1], p[q1] = rho1, u1, v1, p1
    rho[q2], u[q2], v[q2], p[q2] = rho2, u2, v2, p2
    rho[q3], u[q3], v[q3], p[q3] = rho3, u3, v3, p3
    rho[q4], u[q4], v[q4], p[q4] = rho4, u4, v4, p4

    # 转换为守恒量形式
    E = p / (GAMMA - 1.0) + 0.5 * rho * (u**2 + v**2)
    U = np.array([rho, rho * u, rho * v, E])

    return U
