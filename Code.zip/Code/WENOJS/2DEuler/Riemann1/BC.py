import numpy as np

def apply_outflow_bc(U, nghost=3):

    pad_width = ((0, 0), (nghost, nghost), (nghost, nghost))

    U_ext = np.pad(U, pad_width, mode='edge')

    return U_ext


if __name__ == '__main__':
    # 创建 2x3 的小网格测试
    Ny, Nx = 2, 2
    U = np.zeros((1, Ny, Nx))  # 只用一个变量测试

    # 填充简单数据
    U[0, :, :] = np.array([[1, 2],
                           [3, 4]])

    u_ext=apply_outflow_bc(U)
    print(u_ext)


