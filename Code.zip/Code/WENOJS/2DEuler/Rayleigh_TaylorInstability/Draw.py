import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import os

# 1. 风格设置，确保符合 JCP 论文的高清出版与版面美学
plt.rcParams.update({
    "font.size": 20,
    "axes.labelsize": 16,
    "xtick.labelsize": 13,
    "ytick.labelsize": 13,
    "figure.titlesize": 20
})

# 2. 定义分辨率和格式配置
resolutions = ['30x120', '60x240', '120x480']
scheme_labels = ['Pure WENO5', 'WENO5 with KXRCF', 'WENO5-H-MLP']

# 专门用于小标题显示的格式简称，严格对应第一列、第二列和第三列
display_names = ['WENO5', 'KXRCF', 'MLP']

# 子图标签前缀序列（对应 3x3 矩阵的一维展开索引）
sub_indices = ['(a)', '(b)', '(c)', '(d)', '(e)', '(f)', '(g)', '(h)', '(i)']

# 文件名模板映射字典
file_templates = {
    'Pure WENO5': 'PureWENO5_RayleighTaylor_{res}_results.csv',
    'WENO5 with KXRCF': 'WENO5KXRCF_RayleighTaylor_{res}_Th1.0_results.csv',
    'WENO5-H-MLP': 'WENO5MLP_RayleighTaylor_{res}_P0.5_results.csv'
}

# ==================== 【手动控制等高线范围】 ====================
# 请根据您 RT 算例的实际密度范围进行调整（例如最小值为 0.9，最大值为 2.2）
density_min = 0.9
density_max = 2.35
levels_num = 30  # 等高线层数

# 根据设定的上下限自动生成对齐的色阶刻度
custom_levels = np.linspace(density_min, density_max, levels_num)
# =========================================================================

# 3. 创建 3x3 画布
# 【核心修改点 1】：将 sharex 设置为 False，确保每一行、每一张图的 X 轴刻度和标签默认不被隐藏
fig, axes = plt.subplots(3, 3, figsize=(10, 14), sharex=False, sharey=True)

# 4. 循环读取数据并绘制流场
for i, res in enumerate(resolutions):
    # 解析当前的 nx 和 ny
    nx, ny = map(int, res.split('x'))

    for j, scheme in enumerate(scheme_labels):
        ax = axes[i, j]
        filename = file_templates[scheme].format(res=res)

        if os.path.exists(filename):
            print(f"正在读取并绘制: {filename} ...")

            # 过滤元数据行，精准读取表头
            df = pd.read_csv(filename, comment='#')

            # 重构 2D 矩阵
            X = df['X'].values.reshape((ny, nx))
            Y = df['Y'].values.reshape((ny, nx))
            rho = df['Density(rho)'].values.reshape((ny, nx))

            # 绘制全场密度等高线
            cf = ax.contourf(X, Y, rho, levels=custom_levels, cmap='jet', extend='both')

        else:
            # 数据文件缺失时提醒
            ax.text(0.5, 0.5, f"Missing:\n{filename}",
                    ha='center', va='center', color='red', fontsize=9)

        # 严格保持物理区域 1:4 的真实比例
        ax.set_aspect('equal')
        ax.set_xlim(0.0, 0.25)
        ax.set_ylim(0.0, 1.0)

        # 规范化轴刻度间距
        ax.set_xticks([0.0, 0.25])
        ax.set_yticks([0.0, 0.5, 1.0])

        # 【核心修改点 2】：不再用 if i == 2 限制，使得每一张子图都拥有自己的 X 轴标签
        ax.set_xlabel(r'X')

        if j == 0:
            ax.set_ylabel(r'Y')

        # 【核心修改点 3】：由于解除 sharex 后第一、二行子图产生了刻度标签，
        # 为了避免小标题与 X 轴标签重叠，将文本的 y 位置从 -0.14 下调至 -0.22
        flat_idx = i * 3 + j
        full_title = fr"{sub_indices[flat_idx]} {display_names[j]} ($\mathrm{{N}}_x \times \mathrm{{N}}_y = {nx} \times {ny}$)"

        ax.text(0.5, -0.18, full_title, transform=ax.transAxes,
                ha='center', va='top', fontsize=13)

# 5. 调整整体版面并导出高分辨率 PDF
plt.tight_layout()
# 【核心修改点 4】：适当增加 hspace 空间（从 0.22 增至 0.35），留给第一、二行出现的 Xlabel 以及向下微调后的小标题，防止与下方的子图重叠
plt.subplots_adjust(left=0.08, right=0.98, top=0.96, bottom=0.06, wspace=0.15, hspace=0.35)

output_pdf = "RT_compare.pdf"
plt.savefig(output_pdf, dpi=300, bbox_inches='tight')
print(f"\n====================================================")
print(f"🎉 成功生成出版级 3x3 密度对比图(所有子图包含独立的 X 轴标签): {output_pdf}")
print(f"====================================================")
plt.show()