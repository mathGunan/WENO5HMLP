import numpy as np
from BC import apply_BC_RT
from ROEFLUX import *

def SolverWeno5Rk3(U_phys, dx, dy, dt, gamma=5.0/3.0, nghost=3):
    """
    纯五阶 WENO5 右端项对应的 TVD-RK3 时间推进求解器
    """
    # === Stage 1 ===
    U_ext = apply_BC_RT(U_phys, gamma, nghost)
    rhs1 = compute_rhs_pure_weno5(U_ext, dx, dy, gamma, nghost)
    U1 = U_phys + dt * rhs1

    # === Stage 2 ===
    U1_ext = apply_BC_RT(U1, gamma, nghost)
    rhs2 = compute_rhs_pure_weno5(U1_ext, dx, dy, gamma, nghost)
    U2 = 0.75 * U_phys + 0.25 * (U1 + dt * rhs2)

    # === Stage 3 ===
    U2_ext = apply_BC_RT(U2, gamma, nghost)
    rhs3 = compute_rhs_pure_weno5(U2_ext, dx, dy, gamma, nghost)
    U_next = (1.0 / 3.0) * U_phys + (2.0 / 3.0) * (U2 + dt * rhs3)

    return U_next


def SolverKXRCRk3(U_phys, dx, dy, dt, gamma=5.0/3.0, nghost=3, threshold=1.0):
    """
    KXRCF 间断检测器调控的混合自适应格式对应的 TVD-RK3 时间推进求解器
    """
    # === Stage 1 ===
    U_ext = apply_BC_RT(U_phys, gamma, nghost)
    rhs1 = compute_rhs_KXRCF(U_ext, dx, dy, gamma, threshold, nghost)
    U1 = U_phys + dt * rhs1

    # === Stage 2 ===
    U1_ext = apply_BC_RT(U1, gamma, nghost)
    rhs2 = compute_rhs_KXRCF(U1_ext, dx, dy, gamma, threshold, nghost)
    U2 = 0.75 * U_phys + 0.25 * (U1 + dt * rhs2)

    # === Stage 3 ===
    U2_ext = apply_BC_RT(U2, gamma, nghost)
    rhs3 = compute_rhs_KXRCF(U2_ext, dx, dy, gamma, threshold, nghost)
    U_next = (1.0 / 3.0) * U_phys + (2.0 / 3.0) * (U2 + dt * rhs3)

    return U_next


def SolverMLPRk3(U_phys, dx, dy, dt, gamma, model, device, nghost=3, threshold=0.5):
    """
    使用 MLP 神经网络调控的混合自适应格式对应的 TVD-RK3 时间推进求解器
    （完美对齐内场预测架构与带有非齐次源项的右端项计算）
    """
    # === Stage 1 ===
    U_ext = apply_BC_RT(U_phys, gamma, nghost)
    # 调用最新的 compute_rhs_2d_with_MLP，严格传递所有控制参数
    rhs1 = compute_rhs_2d_with_MLP(
        U_ext, dx, dy, model, device,
        gamma=gamma, threshold=threshold, nghost=nghost
    )
    U1 = U_phys + dt * rhs1

    # === Stage 2 ===
    U1_ext = apply_BC_RT(U1, gamma, nghost)
    rhs2 = compute_rhs_2d_with_MLP(
        U1_ext, dx, dy, model, device,
        gamma=gamma, threshold=threshold, nghost=nghost
    )
    U2 = 0.75 * U_phys + 0.25 * (U1 + dt * rhs2)

    # === Stage 3 ===
    U2_ext = apply_BC_RT(U2, gamma, nghost)
    rhs3 = compute_rhs_2d_with_MLP(
        U2_ext, dx, dy, model, device,
        gamma=gamma, threshold=threshold, nghost=nghost
    )
    U_next = (1.0 / 3.0) * U_phys + (2.0 / 3.0) * (U2 + dt * rhs3)

    return U_next