import csv
import time
import numpy as np
from RK3 import SolverWeno5Rk3
from IC import rayleigh_taylor_IC
from BC import apply_BC_RT
from helperfunction import compute_time_step  # 严格导入专用的时间步长计算函数

gamma = 5.0 / 3.0


def compute_single_run(Nx, Ny, T_final=1.95):
    """
    单次网格规模的纯五阶 WENO5 基准 Rayleigh-Taylor 不稳定性计算算子
    """
    ng = 3
    nx = Nx
    ny = Ny
    Lx = 0.25
    Ly = 1.0
    dx = Lx / nx
    dy = Ly / ny
    cfl = 0.5
    epsilon = 1e-6  # WENO5 非线性权重防溢出的平滑小量

    # 网格中心坐标
    x = np.linspace(dx / 2, Lx - dx / 2, nx)
    y = np.linspace(dy / 2, Ly - dy / 2, ny)
    Xc, Yc = np.meshgrid(x, y, indexing='xy')

    # 初始条件 (返回纯物理域 [4, ny, nx])
    U = rayleigh_taylor_IC(Xc, Yc)

    # 时间推进
    t = 0.0
    iteration = 0
    start_time = time.time()

    while t < T_final:
        # 1. 应用边界条件得到包含 ghost cells 的扩展数组 (用于更严谨地评估全场，包括边缘的特征波速)
        U_ext = apply_BC_RT(U, gamma=gamma, ng=ng)

        # 2. 【核心修改】：替换为您专用的、包含重力源项稳定性约束的时间步长计算公式
        # 传入完全体扩展数组 U_ext，显式指定比热比 gamma、安全系数 cfl=0.5 以及重力加速度 gravity=1.0
        dt = compute_time_step(U_ext, dx, dy, gamma=gamma, cfl=cfl, gravity=1.0)

        # 最后一步 dt 修正，保证 t 不超过 T_final
        if t + dt > T_final:
            dt = T_final - t

        # 严格执行 WENO5 + RK3 推进重构 (返回纯物理域)
        U = SolverWeno5Rk3(U, dx, dy, dt, gamma=gamma, nghost=ng)

        t += dt
        iteration += 1

        # 仅在每 50 步迭代时执行一次高效的进度输出，并打印流场密度极值监控趋势
        if iteration % 50 == 0 or t >= T_final:
            progress = (t / T_final) * 100
            min_rho = np.min(U[0])
            max_rho = np.max(U[0])
            print(f"[Pure WENO5] 网格规模 {Nx}x{Ny}: 进度 {progress:.1f}%, 迭代步数 {iteration}, "
                  f"物理时间 t={t:.4f}, dt={dt:.6f}, 密度区间: [{min_rho:.4f}, {max_rho:.4f}]")

            # 实施底层安全熔断
            if np.isnan(min_rho):
                print("❌ 检测到流场发散 (NaN)！熔断程序以保护计算资源。")
                break

    cpu_time = time.time() - start_time
    print(f"纯 WENO5 Rayleigh-Taylor 计算完成，总耗时: {cpu_time:.4f} 秒，总迭代次数: {iteration}")

    return Xc, Yc, U, cpu_time


def main():
    print("====================================================")
    print("  开启 2D Euler (Pure WENO5 + Roe) Rayleigh-Taylor 基准计算  ")
    print("====================================================")

    # 网格分辨率完全对齐标准比例
    Nx = 60  # x 方向的网格点数
    Ny = 240  # y 方向的网格点数
    T_final = 1.95

    # 执行仿真计算
    Xc, Yc, U_final, cpu_time = compute_single_run(Nx, Ny, T_final=T_final)

    # 提取最后时刻的 4 个完整守恒量分量
    rho_num = U_final[0, :, :]
    rhou_num = U_final[1, :, :]
    rhov_num = U_final[2, :, :]
    E_num = U_final[3, :, :]

    # 将二维空间网格及流场展平为一维列，以便标准 CSV 表格化存储
    x_flat = Xc.flatten()
    y_flat = Yc.flatten()
    rho_flat = rho_num.flatten()
    rhou_flat = rhou_num.flatten()
    rhov_flat = rhov_num.flatten()
    E_flat = E_num.flatten()

    # 规范化 CSV 命名，清晰标记为 PureWENO5 算法和 RayleighTaylor 问题
    csv_filename = f"PureWENO5_RayleighTaylor_{Nx}x{Ny}_results.csv"

    # 使用标准库 csv 进行安全写入
    with open(csv_filename, mode='w', newline='', encoding='utf-8') as f:
        writer = csv.writer(f)

        # 1. 在 CSV 头部前两行写入全局元数据，保留总 CPU 时间以供后续效率对比
        writer.writerow(["# Global Metadata", f"Total_CPU_Time_Seconds: {cpu_time:.6f}"])

        # 2. 写入标准的【守恒量】列标题
        writer.writerow(["X", "Y", "Density(rho)", "Momentum_X(rho_u)", "Momentum_Y(rho_v)", "Energy(E)"])

        # 3. 逐行写入流场各网格点上的位置与守恒量分量（严格使用学术规范的 .6e 科学计数法）
        for i in range(len(x_flat)):
            writer.writerow([
                f"{x_flat[i]:.6e}",
                f"{y_flat[i]:.6e}",
                f"{rho_flat[i]:.6e}",
                f"{rhou_flat[i]:.6e}",
                f"{rhov_flat[i]:.6e}",
                f"{E_flat[i]:.6e}"
            ])

    print("----------------------------------------------------")
    print(f"纯 WENO5 Rayleigh-Taylor 基准流场数据保存完毕。最终 CSV 文件路径: {csv_filename}")
    print("====================================================")


if __name__ == "__main__":
    main()