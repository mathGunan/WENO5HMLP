import csv
import time
import numpy as np
from RK3 import SolverMLPRk3  # 严格导入已对齐新版接口的 MLP 推进器
from IC import rayleigh_taylor_IC
from BC import apply_BC_RT
from helperfunction import *

gamma = 5.0 / 3.0


def compute_single_run(Nx, Ny, T_final=1.95, P=0.5):
    """
    单次网格规模的神经网络自适应调控（WENO5-MLP） Rayleigh-Taylor 不稳定性计算算子
    """
    nghost = 3  # 统一使用 nghost 命名，无缝对接下游接口
    nx = Nx
    ny = Ny
    Lx = 0.25
    Ly = 1.0
    dx = Lx / nx
    dy = Ly / ny

    # 1. 生成二维网格中心坐标（indexing='xy' 产出形状 (ny, nx)）
    x = np.linspace(dx / 2, Lx - dx / 2, nx)
    y = np.linspace(dy / 2, Ly - dy / 2, ny)
    Xc, Yc = np.meshgrid(x, y, indexing='xy')

    # 2. 初始条件 (返回纯物理域 [4, ny, nx])
    U = rayleigh_taylor_IC(Xc, Yc)

    # 3. 只加载模型一次
    model, device = get_model()

    # 时间推进
    t = 0.0
    iteration = 0
    start_time = time.time()

    while t < T_final:
        # 【严格保持您的逻辑】：计算时间步长前，先利用边界函数扩展数组
        U_ext = apply_BC_RT(U, gamma=gamma, ng=nghost)

        # 利用完全体扩展数组计算当前步的安全时步 dt
        dt = compute_time_step(U_ext, dx, dy, gamma=gamma, cfl=0.5, gravity=1.0)

        # 最后一步 dt 修正，保证 t 不超过 T_final
        if t + dt > T_final:
            dt = T_final - t

        # 【标准挂载】：调用已经对齐时间子步、引入决策阈值 P 的 MLP 混合时间推进求解器
        # 显式传递传递当前算例的 gamma=5.0/3.0，防止其回退到默认的 1.4
        U = SolverMLPRk3(
            U_phys=U,
            dx=dx,
            dy=dy,
            dt=dt,
            gamma=gamma,
            model=model,
            device=device,
            nghost=nghost,
            threshold=P
        )

        t += dt
        iteration += 1

        # 仅在每 50 步迭代或终点时执行进度输出，并打印流场密度极值监控趋势
        if iteration % 50 == 0 or t >= T_final:
            progress = (t / T_final) * 100
            min_rho = np.min(U[0])
            max_rho = np.max(U[0])
            print(f"[WENO5-MLP] 网格规模 {Nx}x{Ny} (P={P}): 进度 {progress:.1f}%, 迭代步数 {iteration}, "
                  f"物理时间 t={t:.4f}, 密度区间: [{min_rho:.4f}, {max_rho:.4f}]")

            # 实施底层安全熔断
            if np.isnan(min_rho):
                print("❌ 检测到流场发散 (NaN)！熔断程序以保护计算资源。")
                break

    cpu_time = time.time() - start_time
    print(f"WENO5-MLP Rayleigh-Taylor 计算完成，总耗时: {cpu_time:.4f} 秒，总迭代次数: {iteration}")

    return Xc, Yc, U, cpu_time


def main():
    print("====================================================")
    print("  开启 2D Euler (WENO5MLP + Roe) Rayleigh-Taylor 基准计算  ")
    print("====================================================")

    # 网格分辨率与决策阈值设置
    Nx = 60  # x 方向的网格点数
    Ny = 240  # y 方向的网格点数
    T_final = 1.95
    P = 0.5  # Troubled-point 神经网络判定分类阈值

    # 执行仿真计算
    Xc, Yc, U_final, cpu_time = compute_single_run(Nx, Ny, T_final=T_final, P=P)

    # 提取最后时刻的 4 个完整守恒量分量
    rho_num = U_final[0, :, :]
    rhou_num = U_final[1, :, :]
    rhov_num = U_final[2, :, :]
    E_num = U_final[3, :, :]

    # 将二维空间网格及流场展平为一维列，以便标准 CSV 表格化存储
    x_flat = Xc.flatten()
    y_flat = Yc.flatten()
    rho_flat = rho_num.flatten()
    rhou_flat = rhou_num.flatten()
    rhov_flat = rhov_num.flatten()
    E_flat = E_num.flatten()

    # 规范化 CSV 命名，清晰标记为 WENO5MLP 算法、网格点数与分类阈值参数
    csv_filename = f"WENO5MLP_RayleighTaylor_{Nx}x{Ny}_P{P}_results.csv"

    # 使用标准库 csv 严格按规定格式安全写入
    with open(csv_filename, mode='w', newline='', encoding='utf-8') as f:
        writer = csv.writer(f)

        # 1. 在 CSV 头部前两行写入全局元数据（保留总 CPU 时间以供后续效率对比）
        writer.writerow(["# Global Metadata", f"Total_CPU_Time_Seconds: {cpu_time:.6f}"])

        # 2. 写入标准的【守恒量】列标题
        writer.writerow(["X", "Y", "Density(rho)", "Momentum_X(rho_u)", "Momentum_Y(rho_v)", "Energy(E)"])

        # 3. 逐行写入流场各网格点上的位置与守恒量分量
        for i in range(len(x_flat)):
            writer.writerow([
                f"{x_flat[i]:.6e}",
                f"{y_flat[i]:.6e}",
                f"{rho_flat[i]:.6e}",
                f"{rhou_flat[i]:.6e}",
                f"{rhov_flat[i]:.6e}",
                f"{E_flat[i]:.6e}"
            ])

    print("----------------------------------------------------")
    print(f"WENO5-MLP Rayleigh-Taylor 流场数据保存完毕。最终 CSV 文件路径: {csv_filename}")
    print("====================================================")


if __name__ == "__main__":
    main()