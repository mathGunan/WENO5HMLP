import numpy as np
from helperfunction import  *


def compute_rhs_pure_weno5(U_ext, dx, dy, gamma=5.0/3.0, nghost=3, epsilon=1e-6):
    """
    Rayleigh-Taylor 不稳定性 - 纯五阶 WENO5 + Roe 差分（全自包含，零外部自定义函数依赖）
    """
    n_vars, Ny_ext, Nx_ext = U_ext.shape
    Ny = Ny_ext - 2 * nghost
    Nx = Nx_ext - 2 * nghost
    g_grav = 1.0
    eps_flat = 1e-12
    gamma1 = gamma - 1.0

    # 1. 基础物理量与通量计算
    rho = np.maximum(U_ext[0], eps_flat)
    u = U_ext[1] / rho
    v = U_ext[2] / rho
    E = U_ext[3]
    p = np.maximum(gamma1 * (E - 0.5 * rho * (u ** 2 + v ** 2)), eps_flat)
    H = (E + p) / rho

    F = np.zeros_like(U_ext)
    G = np.zeros_like(U_ext)
    F[0], F[1], F[2], F[3] = U_ext[1], U_ext[1] * u + p, U_ext[1] * v, u * (E + p)
    G[0], G[1], G[2], G[3] = U_ext[2], U_ext[2] * u, U_ext[2] * v + p, v * (E + p)

    F_hat = np.zeros((4, Ny, Nx + 1))
    G_hat = np.zeros((4, Ny + 1, Nx))

    # ==========================================
    # ---- X 方向界面通量解算 (纯内联模式) ----
    # ==========================================
    for j in range(Ny):
        jj = j + nghost
        for i_face in range(Nx + 1):
            i_center = i_face + nghost
            iL, iR = i_center - 1, i_center

            # --- 内联 Roe 平均 ---
            rhoL, rhoR = rho[jj, iL], rho[jj, iR]
            if rhoL < 1e-8 or rhoR < 1e-8:
                u_tilde = 0.5 * (u[jj, iL] + u[jj, iR])
                v_tilde = 0.5 * (v[jj, iL] + v[jj, iR])
                H_tilde = 0.5 * (H[jj, iL] + H[jj, iR])
            else:
                rtL, rtR = np.sqrt(rhoL), np.sqrt(rhoR)
                denom = rtL + rtR
                u_tilde = (rtL * u[jj, iL] + rtR * u[jj, iR]) / denom
                v_tilde = (rtL * v[jj, iL] + rtR * v[jj, iR]) / denom
                H_tilde = (rtL * H[jj, iL] + rtR * H[jj, iR]) / denom

            V_sq = u_tilde ** 2 + v_tilde ** 2
            a_tilde = np.sqrt(np.maximum(gamma1 * (H_tilde - 0.5 * V_sq), eps_flat))
            alpha = np.max(np.abs([u_tilde - a_tilde, u_tilde, u_tilde, u_tilde + a_tilde]))

            # --- 内联 X 特征矩阵 (Lmat) ---
            Lmat = np.array([
                [H_tilde + (a_tilde / gamma1) * (u_tilde - a_tilde), -(u_tilde + a_tilde / gamma1), -v_tilde, 1.0],
                [-2 * H_tilde + 4 * a_tilde ** 2 / gamma1, 2 * u_tilde, 2 * v_tilde, -2.0],
                [-2 * v_tilde * a_tilde ** 2 / gamma1, 0.0, 2 * a_tilde ** 2 / gamma1, 0.0],
                [H_tilde - (a_tilde / gamma1) * (u_tilde + a_tilde), -u_tilde + a_tilde / gamma1, -v_tilde, 1.0]
            ]) * (gamma1 / (2.0 * a_tilde ** 2))

            # --- 内联 X 右特征矩阵 (Rmat) ---
            Rmat = np.array([
                [1.0, 1.0, 0.0, 1.0],
                [u_tilde - a_tilde, u_tilde, 0.0, u_tilde + a_tilde],
                [v_tilde, v_tilde, 1.0, v_tilde],
                [H_tilde - u_tilde * a_tilde, 0.5 * V_sq, v_tilde, H_tilde + u_tilde * a_tilde]
            ])

            # 特征投影
            ist, iend = i_center - 3, i_center + 3
            W_stencil = Lmat @ U_ext[:, jj, ist:iend]
            G_stencil = Lmat @ F[:, jj, ist:iend]

            G_plus = 0.5 * (G_stencil + alpha * W_stencil)
            G_minus = 0.5 * (G_stencil - alpha * W_stencil)

            # --- 内联五阶 WENO5 界面重构 ---
            Gp_iL, Gm_iR = np.zeros(4), np.zeros(4)
            for k in range(4):
                # 左重构 (使用前 5 点)
                v0, v1, v2, v3, v4 = G_plus[k, 0:5]
                b0 = (13 / 12) * (v0 - 2 * v1 + v2) ** 2 + 0.25 * (v0 - 4 * v1 + 3 * v2) ** 2
                b1 = (13 / 12) * (v1 - 2 * v2 + v3) ** 2 + 0.25 * (v1 - v3) ** 2
                b2 = (13 / 12) * (v2 - 2 * v3 + v4) ** 2 + 0.25 * (3 * v2 - 4 * v3 + v4) ** 2
                al0, al1, al2 = 0.1 / (epsilon + b0) ** 2, 0.6 / (epsilon + b1) ** 2, 0.3 / (epsilon + b2) ** 2
                s_al = al0 + al1 + al2
                Gp_iL[k] = (al0 * (2 * v0 - 7 * v1 + 11 * v2) + al1 * (-v1 + 5 * v2 + 2 * v3) + al2 * (
                            2 * v2 + 5 * v3 - v4)) / (6.0 * s_al)

                # 右重构 (使用后 5 点)
                v1, v2, v3, v4, v5 = G_minus[k, 1:6]
                b0 = (13 / 12) * (v5 - 2 * v4 + v3) ** 2 + 0.25 * (v5 - 4 * v4 + 3 * v3) ** 2
                b1 = (13 / 12) * (v4 - 2 * v3 + v2) ** 2 + 0.25 * (v4 - v2) ** 2
                b2 = (13 / 12) * (v3 - 2 * v2 + v1) ** 2 + 0.25 * (3 * v3 - 4 * v2 + v1) ** 2
                al0, al1, al2 = 0.3 / (epsilon + b0) ** 2, 0.6 / (epsilon + b1) ** 2, 0.1 / (epsilon + b2) ** 2
                s_al = al0 + al1 + al2
                Gm_iR[k] = (al0 * (2 * v5 - 7 * v4 + 11 * v3) + al1 * (-v4 + 5 * v3 + 2 * v2) + al2 * (
                            2 * v3 + 5 * v2 - v1)) / (6.0 * s_al)

            F_hat[:, j, i_face] = Rmat @ (Gp_iL + Gm_iR)

    # ==========================================
    # ---- Y 方向界面通量解算 (纯内联模式) ----
    # ==========================================
    for i in range(Nx):
        ii = i + nghost
        for j_face in range(Ny + 1):
            j_center = j_face + nghost
            jL, jR = j_center - 1, j_center

            # --- 内联 Roe 平均 ---
            rhoL, rhoR = rho[jL, ii], rho[jR, ii]
            if rhoL < 1e-8 or rhoR < 1e-8:
                u_tilde = 0.5 * (u[jL, ii] + u[jR, ii])
                v_tilde = 0.5 * (v[jL, ii] + v[jR, ii])
                H_tilde = 0.5 * (H[jL, ii] + H[jR, ii])
            else:
                rtL, rtR = np.sqrt(rhoL), np.sqrt(rhoR)
                denom = rtL + rtR
                u_tilde = (rtL * u[jL, ii] + rtR * u[jR, ii]) / denom
                v_tilde = (rtL * v[jL, ii] + rtR * v[jR, ii]) / denom
                H_tilde = (rtL * H[jL, ii] + rtR * H[jR, ii]) / denom

            V_sq = u_tilde ** 2 + v_tilde ** 2
            a_tilde = np.sqrt(np.maximum(gamma1 * (H_tilde - 0.5 * V_sq), eps_flat))
            alpha = np.max(np.abs([v_tilde - a_tilde, v_tilde, v_tilde, v_tilde + a_tilde]))

            # --- 内联 Y 特征矩阵 (Lmat) ---
            Lmat = np.array([
                [H_tilde + (a_tilde / gamma1) * (v_tilde - a_tilde), -u_tilde, -(v_tilde + a_tilde / gamma1), 1.0],
                [-2 * u_tilde * a_tilde ** 2 / gamma1, 2 * a_tilde ** 2 / gamma1, 0.0, 0.0],
                [-2 * H_tilde + 4 * a_tilde ** 2 / gamma1, 2 * u_tilde, 2 * v_tilde, -2.0],
                [H_tilde - (a_tilde / gamma1) * (v_tilde + a_tilde), -u_tilde, -v_tilde + a_tilde / gamma1, 1.0]
            ]) * (gamma1 / (2.0 * a_tilde ** 2))

            # --- 内联 Y 右特征矩阵 (Rmat) ---
            Rmat = np.array([
                [1.0, 0.0, 1.0, 1.0],
                [u_tilde, 1.0, u_tilde, u_tilde],
                [v_tilde - a_tilde, 0.0, v_tilde, v_tilde + a_tilde],
                [H_tilde - v_tilde * a_tilde, v_tilde, 0.5 * V_sq, H_tilde + v_tilde * a_tilde]
            ])

            jst, jend = j_center - 3, j_center + 3
            W_stencil = Lmat @ U_ext[:, jst:jend, ii]
            G_stencil = Lmat @ G[:, jst:jend, ii]

            G_plus = 0.5 * (G_stencil + alpha * W_stencil)
            G_minus = 0.5 * (G_stencil - alpha * W_stencil)

            # --- 内联五阶 WENO5 界面重构 ---
            Gp_jL, Gm_jR = np.zeros(4), np.zeros(4)
            for k in range(4):
                v0, v1, v2, v3, v4 = G_plus[k, 0:5]
                b0 = (13 / 12) * (v0 - 2 * v1 + v2) ** 2 + 0.25 * (v0 - 4 * v1 + 3 * v2) ** 2
                b1 = (13 / 12) * (v1 - 2 * v2 + v3) ** 2 + 0.25 * (v1 - v3) ** 2
                b2 = (13 / 12) * (v2 - 2 * v3 + v4) ** 2 + 0.25 * (3 * v2 - 4 * v3 + v4) ** 2
                al0, al1, al2 = 0.1 / (epsilon + b0) ** 2, 0.6 / (epsilon + b1) ** 2, 0.3 / (epsilon + b2) ** 2
                s_al = al0 + al1 + al2
                Gp_jL[k] = (al0 * (2 * v0 - 7 * v1 + 11 * v2) + al1 * (-v1 + 5 * v2 + 2 * v3) + al2 * (
                            2 * v2 + 5 * v3 - v4)) / (6.0 * s_al)

                v1, v2, v3, v4, v5 = G_minus[k, 1:6]
                b0 = (13 / 12) * (v5 - 2 * v4 + v3) ** 2 + 0.25 * (v5 - 4 * v4 + 3 * v3) ** 2
                b1 = (13 / 12) * (v4 - 2 * v3 + v2) ** 2 + 0.25 * (v4 - v2) ** 2
                b2 = (13 / 12) * (v3 - 2 * v2 + v1) ** 2 + 0.25 * (3 * v3 - 4 * v2 + v1) ** 2
                al0, al1, al2 = 0.3 / (epsilon + b0) ** 2, 0.6 / (epsilon + b1) ** 2, 0.1 / (epsilon + b2) ** 2
                s_al = al0 + al1 + al2
                Gm_jR[k] = (al0 * (2 * v5 - 7 * v4 + 11 * v3) + al1 * (-v4 + 5 * v3 + 2 * v2) + al2 * (
                            2 * v3 + 5 * v2 - v1)) / (6.0 * s_al)

            G_hat[:, j_face, i] = Rmat @ (Gp_jL + Gm_jR)

    # 3. 散度差分项组装
    rhs = np.zeros((4, Ny, Nx))
    rhs -= (F_hat[:, :, 1:] - F_hat[:, :, :-1]) / dx
    rhs -= (G_hat[:, 1:, :] - G_hat[:, :-1, :]) / dy

    # 4. 原生重力项与重力功项注入
    rho_phys = rho[nghost:-nghost, nghost:-nghost]
    v_phys = v[nghost:-nghost, nghost:-nghost]
    rhs[2, :, :] += rho_phys * g_grav
    rhs[3, :, :] += rho_phys * v_phys * g_grav

    return rhs


def compute_rhs_KXRCF(U_ext, dx, dy, gamma=5.0/3.0, threshold=1.0, nghost=3, epsilon=1e-6):
    """
    Rayleigh-Taylor 不稳定性 - KXRCF 混合自适应格式（全内联，支持高低阶动态重构）
    已修正海象运算符导致的变量未定义错误以及特征通量投影的维度匹配问题
    """
    n_vars, Ny_ext, Nx_ext = U_ext.shape
    Ny = Ny_ext - 2 * nghost
    Nx = Nx_ext - 2 * nghost
    g_grav = 1.0
    eps_flat = 1e-12
    gamma1 = gamma - 1.0

    # 基础物理量
    rho = np.maximum(U_ext[0], eps_flat)
    u = U_ext[1] / rho
    v = U_ext[2] / rho
    E = U_ext[3]
    p = np.maximum(gamma1 * (E - 0.5 * rho * (u ** 2 + v ** 2)), eps_flat)
    H = (E + p) / rho

    # 全局通量
    F = np.zeros_like(U_ext)
    G = np.zeros_like(U_ext)
    F[0], F[1], F[2], F[3] = U_ext[1], U_ext[1] * u + p, U_ext[1] * v, u * (E + p)
    G[0], G[1], G[2], G[3] = U_ext[2], U_ext[2] * u, U_ext[2] * v + p, v * (E + p)

    F_hat = np.zeros((4, Ny, Nx + 1))
    G_hat = np.zeros((4, Ny + 1, Nx))

    # ==========================================
    # ---- X 方向解算 ----
    # ==========================================
    for j in range(Ny):
        jj = j + nghost
        for i_face in range(Nx + 1):
            i_center = i_face + nghost
            iL, iR = i_center - 1, i_center

            # 间断检测判定
            is_troubled = np.abs(p[jj, iR] - p[jj, iL]) / max(p[jj, iL], 1e-5) > threshold

            # Roe 平均
            if rho[jj, iL] < 1e-8 or rho[jj, iR] < 1e-8:
                u_tilde, v_tilde, H_tilde = 0.5 * (u[jj, iL] + u[jj, iR]), 0.5 * (v[jj, iL] + v[jj, iR]), 0.5 * (
                            H[jj, iL] + H[jj, iR])
            else:
                denom = np.sqrt(rho[jj, iL]) + np.sqrt(rho[jj, iR])
                u_tilde = (np.sqrt(rho[jj, iL]) * u[jj, iL] + np.sqrt(rho[jj, iR]) * u[jj, iR]) / denom
                v_tilde = (np.sqrt(rho[jj, iL]) * v[jj, iL] + np.sqrt(rho[jj, iR]) * v[jj, iR]) / denom
                H_tilde = (np.sqrt(rho[jj, iL]) * H[jj, iL] + np.sqrt(rho[jj, iR]) * H[jj, iR]) / denom

            V_sq = u_tilde ** 2 + v_tilde ** 2
            a_tilde = np.sqrt(np.maximum(gamma1 * (H_tilde - 0.5 * V_sq), eps_flat))
            alpha = np.max(np.abs([u_tilde - a_tilde, u_tilde, u_tilde, u_tilde + a_tilde]))

            # 特征矩阵
            Lmat = np.array([
                [H_tilde + (a_tilde / gamma1) * (u_tilde - a_tilde), -(u_tilde + a_tilde / gamma1), -v_tilde, 1.0],
                [-2 * H_tilde + 4 * a_tilde ** 2 / gamma1, 2 * u_tilde, 2 * v_tilde, -2.0],
                [-2 * v_tilde * a_tilde ** 2 / gamma1, 0.0, 2 * a_tilde ** 2 / gamma1, 0.0],
                [H_tilde - (a_tilde / gamma1) * (u_tilde + a_tilde), -u_tilde + a_tilde / gamma1, -v_tilde, 1.0]
            ]) * (gamma1 / (2.0 * a_tilde ** 2))

            Rmat = np.array([
                [1.0, 1.0, 0.0, 1.0], [u_tilde - a_tilde, u_tilde, 0.0, u_tilde + a_tilde],
                [v_tilde, v_tilde, 1.0, v_tilde],
                [H_tilde - u_tilde * a_tilde, 0.5 * V_sq, v_tilde, H_tilde + u_tilde * a_tilde]
            ])

            # 特征投影 (固定 6 点模板：i_center-3 到 i_center+2)
            W_stencil = Lmat @ U_ext[:, jj, i_center - 3:i_center + 3]
            G_stencil = Lmat @ F[:, jj, i_center - 3:i_center + 3]
            G_plus, G_minus = 0.5 * (G_stencil + alpha * W_stencil), 0.5 * (G_stencil - alpha * W_stencil)

            Fn_hat_interface = np.zeros(4)
            for k in range(4):
                if is_troubled:
                    v0, v1, v2, v3, v4 = G_plus[k, 0:5]
                    b0 = (13 / 12) * (v0 - 2 * v1 + v2) ** 2 + 0.25 * (v0 - 4 * v1 + 3 * v2) ** 2
                    b1 = (13 / 12) * (v1 - 2 * v2 + v3) ** 2 + 0.25 * (v1 - v3) ** 2
                    b2 = (13 / 12) * (v2 - 2 * v3 + v4) ** 2 + 0.25 * (3 * v2 - 4 * v3 + v4) ** 2
                    s_al = 0.1 / (epsilon + b0) ** 2 + 0.6 / (epsilon + b1) ** 2 + 0.3 / (epsilon + b2) ** 2
                    Gp = (0.1 / (epsilon + b0) ** 2 * (2 * v0 - 7 * v1 + 11 * v2) + 0.6 / (epsilon + b1) ** 2 * (
                                -v1 + 5 * v2 + 2 * v3) + 0.3 / (epsilon + b2) ** 2 * (2 * v2 + 5 * v3 - v4)) / (
                                     6.0 * s_al)

                    v1, v2, v3, v4, v5 = G_minus[k, 1:6]
                    b0 = (13 / 12) * (v5 - 2 * v4 + v3) ** 2 + 0.25 * (v5 - 4 * v4 + 3 * v3) ** 2
                    b1 = (13 / 12) * (v4 - 2 * v3 + v2) ** 2 + 0.25 * (v4 - v2) ** 2
                    b2 = (13 / 12) * (v3 - 2 * v2 + v1) ** 2 + 0.25 * (3 * v3 - 4 * v2 + v1) ** 2
                    s_al = 0.3 / (epsilon + b0) ** 2 + 0.6 / (epsilon + b1) ** 2 + 0.1 / (epsilon + b2) ** 2
                    Gm = (0.3 / (epsilon + b0) ** 2 * (2 * v5 - 7 * v4 + 11 * v3) + 0.6 / (epsilon + b1) ** 2 * (
                                -v4 + 5 * v3 + 2 * v2) + 0.1 / (epsilon + b2) ** 2 * (2 * v3 + 5 * v2 - v1)) / (
                                     6.0 * s_al)
                else:
                    Gp = (2 * G_plus[k, 0] - 13 * G_plus[k, 1] + 47 * G_plus[k, 2] + 27 * G_plus[k, 3] - 3 * G_plus[
                        k, 4]) / 60.0
                    Gm = (-3 * G_minus[k, 1] + 27 * G_minus[k, 2] + 47 * G_minus[k, 3] - 13 * G_minus[k, 4] + 2 *
                          G_minus[k, 5]) / 60.0
                Fn_hat_interface[k] = Gp + Gm

            F_hat[:, j, i_face] = Rmat @ Fn_hat_interface

    # ==========================================
    # ---- Y 方向解算 ----
    # ==========================================
    for i in range(Nx):
        ii = i + nghost
        for j_face in range(Ny + 1):
            j_center = j_face + nghost
            jL, jR = j_center - 1, j_center

            # 间断检测判定
            is_troubled = np.abs(p[jR, ii] - p[jL, ii]) / max(p[jL, ii], 1e-5) > threshold

            # Roe 平均
            if rho[jL, ii] < 1e-8 or rho[jR, ii] < 1e-8:
                u_tilde, v_tilde, H_tilde = 0.5 * (u[jL, ii] + u[jR, ii]), 0.5 * (v[jL, ii] + v[jR, ii]), 0.5 * (
                            H[jL, ii] + H[jR, ii])
            else:
                denom = np.sqrt(rho[jL, ii]) + np.sqrt(rho[jR, ii])
                u_tilde = (np.sqrt(rho[jL, ii]) * u[jL, ii] + np.sqrt(rho[jR, ii]) * u[jR, ii]) / denom
                v_tilde = (np.sqrt(rho[jL, ii]) * v[jL, ii] + np.sqrt(rho[jR, ii]) * v[jR, ii]) / denom
                H_tilde = (np.sqrt(rho[jL, ii]) * H[jL, ii] + np.sqrt(rho[jR, ii]) * H[jR, ii]) / denom

            V_sq = u_tilde ** 2 + v_tilde ** 2
            a_tilde = np.sqrt(np.maximum(gamma1 * (H_tilde - 0.5 * V_sq), eps_flat))
            alpha = np.max(np.abs([v_tilde - a_tilde, v_tilde, v_tilde, v_tilde + a_tilde]))

            # Y 特征矩阵
            Lmat = np.array([
                [H_tilde + (a_tilde / gamma1) * (v_tilde - a_tilde), -u_tilde, -(v_tilde + a_tilde / gamma1), 1.0],
                [-2 * u_tilde * a_tilde ** 2 / gamma1, 2 * a_tilde ** 2 / gamma1, 0.0, 0.0],
                [-2 * H_tilde + 4 * a_tilde ** 2 / gamma1, 2 * u_tilde, 2 * v_tilde, -2.0],
                [H_tilde - (a_tilde / gamma1) * (v_tilde + a_tilde), -u_tilde, -v_tilde + a_tilde / gamma1, 1.0]
            ]) * (gamma1 / (2.0 * a_tilde ** 2))

            Rmat = np.array([
                [1.0, 0.0, 1.0, 1.0], [u_tilde, 1.0, u_tilde, u_tilde],
                [v_tilde - a_tilde, 0.0, v_tilde, v_tilde + a_tilde],
                [H_tilde - v_tilde * a_tilde, v_tilde, 0.5 * V_sq, H_tilde + v_tilde * a_tilde]
            ])

            # 特征投影 (修正切片错误：改为 j_center-3 到 j_center+3 的纵向切片，并匹配 Y 方向通量 G)
            W_stencil = Lmat @ U_ext[:, j_center - 3:j_center + 3, ii]
            G_stencil = Lmat @ G[:, j_center - 3:j_center + 3, ii]
            G_plus, G_minus = 0.5 * (G_stencil + alpha * W_stencil), 0.5 * (G_stencil - alpha * W_stencil)

            Gn_hat_interface = np.zeros(4)
            for k in range(4):
                if is_troubled:
                    v0, v1, v2, v3, v4 = G_plus[k, 0:5]
                    b0 = (13 / 12) * (v0 - 2 * v1 + v2) ** 2 + 0.25 * (v0 - 4 * v1 + 3 * v2) ** 2
                    b1 = (13 / 12) * (v1 - 2 * v2 + v3) ** 2 + 0.25 * (v1 - v3) ** 2
                    b2 = (13 / 12) * (v2 - 2 * v3 + v4) ** 2 + 0.25 * (3 * v2 - 4 * v3 + v4) ** 2
                    s_al = 0.1 / (epsilon + b0) ** 2 + 0.6 / (epsilon + b1) ** 2 + 0.3 / (epsilon + b2) ** 2
                    Gp = (0.1 / (epsilon + b0) ** 2 * (2 * v0 - 7 * v1 + 11 * v2) + 0.6 / (epsilon + b1) ** 2 * (
                                -v1 + 5 * v2 + 2 * v3) + 0.3 / (epsilon + b2) ** 2 * (2 * v2 + 5 * v3 - v4)) / (
                                     6.0 * s_al)

                    v1, v2, v3, v4, v5 = G_minus[k, 1:6]
                    b0 = (13 / 12) * (v5 - 2 * v4 + v3) ** 2 + 0.25 * (v5 - 4 * v4 + 3 * v3) ** 2
                    b1 = (13 / 12) * (v4 - 2 * v3 + v2) ** 2 + 0.25 * (v4 - v2) ** 2
                    b2 = (13 / 12) * (v3 - 2 * v2 + v1) ** 2 + 0.25 * (3 * v3 - 4 * v2 + v1) ** 2
                    s_al = 0.3 / (epsilon + b0) ** 2 + 0.6 / (epsilon + b1) ** 2 + 0.1 / (epsilon + b2) ** 2
                    Gm = (0.3 / (epsilon + b0) ** 2 * (2 * v5 - 7 * v4 + 11 * v3) + 0.6 / (epsilon + b1) ** 2 * (
                                -v4 + 5 * v3 + 2 * v2) + 0.1 / (epsilon + b2) ** 2 * (2 * v3 + 5 * v2 - v1)) / (
                                     6.0 * s_al)
                else:
                    Gp = (2 * G_plus[k, 0] - 13 * G_plus[k, 1] + 47 * G_plus[k, 2] + 27 * G_plus[k, 3] - 3 * G_plus[
                        k, 4]) / 60.0
                    Gm = (-3 * G_minus[k, 1] + 27 * G_minus[k, 2] + 47 * G_minus[k, 3] - 13 * G_minus[k, 4] + 2 *
                          G_minus[k, 5]) / 60.0
                Gn_hat_interface[k] = Gp + Gm

            G_hat[:, j_face, i] = Rmat @ Gn_hat_interface

    # ==========================================
    # ---- 散度组装与源项 ----
    # ==========================================
    rhs = np.zeros((4, Ny, Nx))
    rhs -= (F_hat[:, :, 1:] - F_hat[:, :, :-1]) / dx
    rhs -= (G_hat[:, 1:, :] - G_hat[:, :-1, :]) / dy

    # 源项注入 (Rayleigh-Taylor 重力功)
    rhs[2, :, :] += rho[nghost:-nghost, nghost:-nghost] * g_grav
    rhs[3, :, :] += rho[nghost:-nghost, nghost:-nghost] * v[nghost:-nghost, nghost:-nghost] * g_grav

    return rhs


def compute_rhs_2d_with_MLP(U_ext, dx, dy, model, device, gamma=1.4, threshold=0.5, nghost=3, epsilon=1e-6):
    """
    二维 Euler 空间右端项 (RHS) 计算函数。
    【内场预测架构】：神经网络预测逻辑完全集成在函数内部，逐行/逐列提取一维物理比熵切片
    实时产生内场的 prob_x 和 prob_y 判定序列。

    【Rayleigh-Taylor 不稳定性版】：保持原有重构及网络逻辑零修改，仅在底部引入重力源项（非齐次项）
    """
    n_vars, Ny_ext, Nx_ext = U_ext.shape
    assert n_vars == 4, "二维Euler应有4个守恒变量"
    Ny = Ny_ext - 2 * nghost
    Nx = Nx_ext - 2 * nghost

    # =========================================================================
    # 1. 全场中心点物理量及物理通量解算
    # =========================================================================
    rho = np.maximum(U_ext[0], 1e-14)
    u = U_ext[1] / rho
    v = U_ext[2] / rho
    E = U_ext[3]
    p = np.maximum((gamma - 1.0) * (E - 0.5 * rho * (u ** 2 + v ** 2)), 1e-14)
    H = (E + p) / rho

    F = np.zeros_like(U_ext)  # x方向通量
    G = np.zeros_like(U_ext)  # y方向通量
    F[0], F[1], F[2], F[3] = rho * u, rho * u ** 2 + p, rho * u * v, u * (E + p)
    G[0], G[1], G[2], G[3] = rho * v, rho * u * v, rho * v ** 2 + p, v * (E + p)

    # 计算全流场统一、尺度不变的物理热力学标量熵 (s = p / rho^gamma)用于网络特征提取
    entropy = p / np.maximum(rho ** gamma, 1e-12)

    F_hat = np.zeros((4, Ny, Nx + 1))  # x方向界面数值通量
    G_hat = np.zeros((4, Ny + 1, Nx))  # y方向界面数值通量

    # =========================================================================
    # 2. X 方向界面通量计算 (逐行处理，内部动态调用 predict_2d 产生 prob_x)
    # =========================================================================
    for j in range(Ny):
        jj = j + nghost

        # 【集成在内部】：直接提取该行包含所有 ghost 单元的完整一维熵切片
        entropy_slice_x = entropy[jj, :]
        # 调用你的一维神经网络算子（严格传递 4 个参数）
        prob_array_x = predict_2d(entropy_slice_x, dx, model, device)
        # 二值化生成当前行的 troubled-point 判定序列（长度为 Nx + 2）
        prob_x = np.where(prob_array_x > threshold, 1.0, 0.0)

        # 行内遍历所有 X 方向截面 i+1/2
        for i_face in range(Nx + 1):
            i_center = i_face + nghost
            iL, iR = i_center - 1, i_center

            # Roe 平均态计算
            rhoL, rhoR = rho[jj, iL], rho[jj, iR]
            uL, uR = u[jj, iL], u[jj, iR]
            vL, vR = v[jj, iL], v[jj, iR]
            HL, HR = H[jj, iL], H[jj, iR]

            rtL, rtR = np.sqrt(rhoL), np.sqrt(rhoR)
            denom = rtL + rtR
            u_t = (rtL * uL + rtR * uR) / denom
            v_t = (rtL * vL + rtR * vR) / denom
            H_t = (rtL * HL + rtR * HR) / denom
            a_t = np.sqrt(np.maximum((gamma - 1.0) * (H_t - 0.5 * (u_t ** 2 + v_t ** 2)), 1e-14))

            # 构造特征变换矩阵 (X 方向)
            gamma1 = gamma - 1.0
            V_sq = u_t ** 2 + v_t ** 2
            R_mat = np.array([
                [1.0, 1.0, 0.0, 1.0],
                [u_t - a_t, u_t, 0.0, u_t + a_t],
                [v_t, v_t, 1.0, v_t],
                [H_t - u_t * a_t, 0.5 * V_sq, v_t, H_t + u_t * a_t]
            ])
            L_mat = np.array([
                [H_t + (a_t / gamma1) * (u_t - a_t), -(u_t + a_t / gamma1), -v_t, 1.0],
                [-2 * H_t + 4 * a_t ** 2 / gamma1, 2 * u_t, 2 * v_t, -2.0],
                [-2 * v_t * a_t ** 2 / gamma1, 0.0, 2 * a_t ** 2 / gamma1, 0.0],
                [H_t - (a_t / gamma1) * (u_t + a_t), -u_t + a_t / gamma1, -v_t, 1.0]
            ])
            L_mat = (gamma1 / (2.0 * a_t ** 2)) * L_mat

            # 投影到特征空间
            stencil = slice(i_center - 3, i_center + 3)
            W_stencil = L_mat @ U_ext[:, jj, stencil]
            G_stencil = L_mat @ F[:, jj, stencil]

            alpha_val = np.max(np.abs([u_t - a_t, u_t, u_t + a_t]))
            G_plus = 0.5 * (G_stencil + alpha_val * W_stencil)
            G_minus = 0.5 * (G_stencil - alpha_val * W_stencil)

            Gp_iL = np.zeros(4)
            Gm_iR = np.zeros(4)

            # 四个物理守恒通道共享由神经网络在内部生成的标量 prob_x 探测算子
            for k in range(4):
                # --- 正通量左重构 ---
                if prob_x[i_face] == 1.0:  # 走 Linear5 高阶线性重构
                    g = G_plus[k, :]
                    Gp_iL[k] = (2 * g[0] - 13 * g[1] + 47 * g[2] + 27 * g[3] - 3 * g[4]) / 60.0
                else:  # 回退到经典无振荡 WENO5 重构
                    g = G_plus[k, :]
                    p1 = (2 * g[0] - 7 * g[1] + 11 * g[2]) / 6.0
                    p2 = (-g[1] + 5 * g[2] + 2 * g[3]) / 6.0
                    p3 = (2 * g[2] + 5 * g[3] - g[4]) / 6.0
                    b1 = (13 / 12) * (g[0] - 2 * g[1] + g[2]) ** 2 + 0.25 * (g[0] - 4 * g[1] + 3 * g[2]) ** 2
                    b2 = (13 / 12) * (g[1] - 2 * g[2] + g[3]) ** 2 + 0.25 * (g[1] - g[3]) ** 2
                    b3 = (13 / 12) * (g[2] - 2 * g[3] + g[4]) ** 2 + 0.25 * (3 * g[2] - 4 * g[3] + g[4]) ** 2
                    al1 = 0.1 / (epsilon + b1) ** 2
                    al2 = 0.6 / (epsilon + b2) ** 2
                    al3 = 0.3 / (epsilon + b3) ** 2
                    w_sum = al1 + al2 + al3
                    Gp_iL[k] = (al1 * p1 + al2 * p2 + al3 * p3) / w_sum

                # --- 负通量右重构 ---
                if prob_x[i_face + 1] == 1.0:  # 走 Linear5 右侧重构
                    g = G_minus[k, :]
                    Gm_iR[k] = (-3 * g[1] + 27 * g[2] + 47 * g[3] - 13 * g[4] + 2 * g[5]) / 60.0
                else:  # 回退到标准五阶 WENO5
                    g = G_minus[k, :]
                    p1 = (-g[1] + 5 * g[2] + 2 * g[3]) / 6.0
                    p2 = (2 * g[2] + 5 * g[3] - g[4]) / 6.0
                    p3 = (11 * g[3] - 7 * g[4] + 2 * g[5]) / 6.0
                    b1 = (13 / 12) * (g[1] - 2 * g[2] + g[3]) ** 2 + 0.25 * (g[1] - 4 * g[2] + 3 * g[3]) ** 2
                    b2 = (13 / 12) * (g[2] - 2 * g[3] + g[4]) ** 2 + 0.25 * (g[2] - g[4]) ** 2
                    b3 = (13 / 12) * (g[3] - 2 * g[4] + g[5]) ** 2 + 0.25 * (3 * g[3] - 4 * g[4] + g[5]) ** 2
                    al1 = 0.3 / (epsilon + b1) ** 2
                    al2 = 0.6 / (epsilon + b2) ** 2
                    al3 = 0.1 / (epsilon + b3) ** 2
                    w_sum = al1 + al2 + al3
                    Gm_iR[k] = (al1 * p1 + al2 * p2 + al3 * p3) / w_sum

            F_hat[:, j, i_face] = R_mat @ (Gp_iL + Gm_iR)

    # =========================================================================
    # 3. Y 方向界面通量计算 (逐列处理，内部动态调用 predict_2d 产生 prob_y)
    # =========================================================================
    for i in range(Nx):
        ii = i + nghost

        # 【集成在内部】：直接提取该列包含所有 ghost 单元的完整一维熵切片
        entropy_slice_y = entropy[:, ii]
        # 调用你的一维神经网络算子，空间尺度参数传入 dy
        prob_array_y = predict_2d(entropy_slice_y, dy, model, device)
        # 二值化生成当前列的 troubled-point 判定序列（长度为 Ny + 2）
        prob_y = np.where(prob_array_y > threshold, 1.0, 0.0)

        # 列内遍历所有 Y 方向截面 j+1/2
        for j_face in range(Ny + 1):
            j_center = j_face + nghost
            jL, jR = j_center - 1, j_center

            rhoL, rhoR = rho[jL, ii], rho[jR, ii]
            uL, uR = u[jL, ii], u[jR, ii]
            vL, vR = v[jL, ii], v[jR, ii]
            HL, HR = H[jL, ii], H[jR, ii]

            rtL, rtR = np.sqrt(rhoL), np.sqrt(rhoR)
            denom = rtL + rtR
            u_t = (rtL * uL + rtR * uR) / denom
            v_t = (rtL * vL + rtR * vR) / denom
            H_t = (rtL * HL + rtR * HR) / denom
            a_t = np.sqrt(np.maximum((gamma - 1.0) * (H_t - 0.5 * (u_t ** 2 + v_t ** 2)), 1e-14))

            # 构造特征变换矩阵 (Y 方向)
            gamma1 = gamma - 1.0
            V_sq = u_t ** 2 + v_t ** 2
            R_mat = np.array([
                [1.0, 0.0, 1.0, 1.0],
                [u_t, 1.0, u_t, u_t],
                [v_t - a_t, 0.0, v_t, v_t + a_t],
                [H_t - v_t * a_t, v_t, 0.5 * V_sq, H_t + v_t * a_t]
            ])
            L_mat = np.array([
                [H_t + (a_t / gamma1) * (v_t - a_t), -u_t, -(v_t + a_t / gamma1), 1.0],
                [-2 * u_t * a_t ** 2 / gamma1, 2 * a_t ** 2 / gamma1, 0.0, 0.0],
                [-2 * H_t + 4 * a_t ** 2 / gamma1, 2 * u_t, 2 * v_t, -2.0],
                [H_t - (a_t / gamma1) * (v_t + a_t), -u_t, -v_t + a_t / gamma1, 1.0]
            ])
            L_mat = (gamma1 / (2.0 * a_t ** 2)) * L_mat

            # 投影到特征空间
            stencil = slice(j_center - 3, j_center + 3)
            W_stencil = L_mat @ U_ext[:, stencil, ii]
            G_stencil = L_mat @ G[:, stencil, ii]  # 乘的是 Y 方向物理通量 G

            alpha_val = np.max(np.abs([v_t - a_t, v_t, v_t + a_t]))
            G_plus = 0.5 * (G_stencil + alpha_val * W_stencil)
            G_minus = 0.5 * (G_stencil - alpha_val * W_stencil)

            Gp_iL = np.zeros(4)
            Gm_iR = np.zeros(4)

            for k in range(4):
                # --- 正通量左(下)重构 ---
                if prob_y[j_face] == 1.0:  # 判定为光滑
                    g = G_plus[k, :]
                    Gp_iL[k] = (2 * g[0] - 13 * g[1] + 47 * g[2] + 27 * g[3] - 3 * g[4]) / 60.0
                else:  # 判定为 troubled-point
                    g = G_plus[k, :]
                    p1 = (2 * g[0] - 7 * g[1] + 11 * g[2]) / 6.0
                    p2 = (-g[1] + 5 * g[2] + 2 * g[3]) / 6.0
                    p3 = (2 * g[2] + 5 * g[3] - g[4]) / 6.0
                    b1 = (13 / 12) * (g[0] - 2 * g[1] + g[2]) ** 2 + 0.25 * (g[0] - 4 * g[1] + 3 * g[2]) ** 2
                    b2 = (13 / 12) * (g[1] - 2 * g[2] + g[3]) ** 2 + 0.25 * (g[1] - g[3]) ** 2
                    b3 = (13 / 12) * (g[2] - 2 * g[3] + g[4]) ** 2 + 0.25 * (3 * g[2] - 4 * g[3] + g[4]) ** 2
                    al1 = 0.1 / (epsilon + b1) ** 2
                    al2 = 0.6 / (epsilon + b2) ** 2
                    al3 = 0.3 / (epsilon + b3) ** 2
                    w_sum = al1 + al2 + al3
                    Gp_iL[k] = (al1 * p1 + al2 * p2 + al3 * p3) / w_sum

                # --- 负通量右(上)重构 ---
                if prob_y[j_face + 1] == 1.0:  # 判定为光滑
                    g = G_minus[k, :]
                    Gm_iR[k] = (-3 * g[1] + 27 * g[2] + 47 * g[3] - 13 * g[4] + 2 * g[5]) / 60.0
                else:  # 回退到标准五阶 WENO5
                    g = G_minus[k, :]
                    p1 = (-g[1] + 5 * g[2] + 2 * g[3]) / 6.0
                    p2 = (2 * g[2] + 5 * g[3] - g[4]) / 6.0
                    p3 = (11 * g[3] - 7 * g[4] + 2 * g[5]) / 6.0
                    b1 = (13 / 12) * (g[1] - 2 * g[2] + g[3]) ** 2 + 0.25 * (g[1] - 4 * g[2] + 3 * g[3]) ** 2
                    b2 = (13 / 12) * (g[2] - 2 * g[3] + g[4]) ** 2 + 0.25 * (g[2] - g[4]) ** 2
                    b3 = (13 / 12) * (g[3] - 2 * g[4] + g[5]) ** 2 + 0.25 * (3 * g[3] - 4 * g[4] + g[5]) ** 2
                    al1 = 0.3 / (epsilon + b1) ** 2
                    al2 = 0.6 / (epsilon + b2) ** 2
                    al3 = 0.1 / (epsilon + b3) ** 2
                    w_sum = al1 + al2 + al3
                    Gm_iR[k] = (al1 * p1 + al2 * p2 + al3 * p3) / w_sum

            G_hat[:, j_face, i] = R_mat @ (Gp_iL + Gm_iR)

    # =========================================================================
    # 4. 空间总残差守恒组合及非齐次源项耦合 (RHS = -dF/dx - dG/dy + Source)
    # =========================================================================
    rhs = np.zeros((4, Ny, Nx))
    rhs -= (F_hat[:, :, 1:] - F_hat[:, :, :-1]) / dx
    rhs -= (G_hat[:, 1:, :] - G_hat[:, :-1, :]) / dy

    # ---- 仅在此处添加 Rayleigh-Taylor 不稳定性所需的重力非齐次项 ----
    g_grav = 1.0
    # 准确截取物理内部区域对应的密度 (rho) 和 y 方向速度 (v)
    rho_core = rho[nghost:-nghost, nghost:-nghost]
    v_core = v[nghost:-nghost, nghost:-nghost]

    # 注入源项：y方向动量方程源项 rho * g，能量方程源项 rho * v * g
    rhs[2, :, :] += rho_core * g_grav
    rhs[3, :, :] += rho_core * v_core * g_grav

    return rhs