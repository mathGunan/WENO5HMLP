import numpy as np

def apply_BC_RT(U_phys, gamma=5.0 / 3.0, ng=3):
    """
    Rayleigh–Taylor instability 边界条件设置
    输入:
        U_phys : 物理域守恒量数组 [4, Ny, Nx]
        gamma : 比热比 (默认 5/3)
        ng : ghost cell 层数 (默认 3)
    输出:
        U_ext : 包含ghost cells的扩展数组 [4, Ny+2*ng, Nx+2*ng]
    """
    n_vars, Ny, Nx = U_phys.shape

    # 创建包含ghost cells的扩展数组
    U_ext = np.zeros((n_vars, Ny + 2 * ng, Nx + 2 * ng))

    # 将物理域数据复制到扩展数组的中心
    U_ext[:, ng:-ng, ng:-ng] = U_phys

    # ---- 辅助函数 ----
    def cons_to_prim(Ui):
        rho = np.maximum(Ui[0], 1e-12)  # 防止0密度
        u = Ui[1] / rho
        v = Ui[2] / rho
        E = Ui[3]
        p = np.maximum((gamma - 1.0) * (E - 0.5 * rho * (u ** 2 + v ** 2)), 1e-12)  # 防止负压
        return rho, u, v, p

    # ---- 左边界 reflective ----
    for i in range(ng):
        U_ext[:, :, i] = U_ext[:, :, 2 * ng - 1 - i]
    rho, u, v, p = cons_to_prim(U_ext[:, :, :ng])
    u = -u  # 法向速度取反
    # 切向速度v保持不变
    U_ext[0, :, :ng] = rho
    U_ext[1, :, :ng] = rho * u
    U_ext[2, :, :ng] = rho * v  # v保持不变
    U_ext[3, :, :ng] = p / (gamma - 1.0) + 0.5 * rho * (u ** 2 + v ** 2)

    # ---- 右边界 reflective ----
    for i in range(ng):
        U_ext[:, :, -i - 1] = U_ext[:, :, -2 * ng + i]
    rho, u, v, p = cons_to_prim(U_ext[:, :, -ng:])
    u = -u  # 法向速度取反
    # 切向速度v保持不变
    U_ext[0, :, -ng:] = rho
    U_ext[1, :, -ng:] = rho * u
    U_ext[2, :, -ng:] = rho * v  # v保持不变
    U_ext[3, :, -ng:] = p / (gamma - 1.0) + 0.5 * rho * (u ** 2 + v ** 2)

    # ---- 下边界 y=0 固定 ----
    rho_b, u_b, v_b, p_b = 2.0, 0.0, 0.0, 1.0
    E_b = p_b / (gamma - 1.0) + 0.5 * rho_b * (u_b ** 2 + v_b ** 2)
    U_ext[0, :ng, :] = rho_b
    U_ext[1, :ng, :] = rho_b * u_b
    U_ext[2, :ng, :] = rho_b * v_b
    U_ext[3, :ng, :] = E_b

    # ---- 上边界 y=1 固定 ----
    rho_t, u_t, v_t, p_t = 1.0, 0.0, 0.0, 2.5
    E_t = p_t / (gamma - 1.0) + 0.5 * rho_t * (u_t ** 2 + v_t ** 2)
    U_ext[0, -ng:, :] = rho_t
    U_ext[1, -ng:, :] = rho_t * u_t
    U_ext[2, -ng:, :] = rho_t * v_t
    U_ext[3, -ng:, :] = E_t

    return U_ext