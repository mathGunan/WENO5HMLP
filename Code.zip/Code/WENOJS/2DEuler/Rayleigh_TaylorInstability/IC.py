import numpy as np

#没问题
def rayleigh_taylor_IC(Xc, Yc):
    """
    Rayleigh–Taylor instability 初始条件

    输入:
        Xc, Yc : 网格中心坐标 (Ny, Nx)
    输出:
        U : 守恒量矩阵 (4, Ny, Nx)
            U[0] = rho
            U[1] = rho * u
            U[2] = rho * v
            U[3] = E
    """
    GAMMA = 5.0 / 3.0

    # 创建数组
    rho = np.zeros_like(Xc)
    u = np.zeros_like(Xc)
    v = np.zeros_like(Xc)
    p = np.zeros_like(Xc)

    # 条件分段
    mask_lower = (Yc < 0.5)  # 下半部 (重流体)
    mask_upper = ~mask_lower # 上半部 (轻流体)

    # 下半部分：ρ=2, p=1+2y
    rho[mask_lower] = 2.0
    p[mask_lower] = 1.0 + 2.0 * Yc[mask_lower]

    # 上半部分：ρ=1, p=1.5+y
    rho[mask_upper] = 1.0
    p[mask_upper] = 1.5 + Yc[mask_upper]

    # 声速 (局部)
    c = np.sqrt(GAMMA * p / rho)

    # 初始扰动：v = -0.025 * c * cos(8πx)
    u[:] = 0.0
    v[:] = -0.025 * c * np.cos(8.0 * np.pi * Xc)

    # 总能量
    E = p / (GAMMA - 1.0) + 0.5 * rho * (u**2 + v**2)

    # 组装守恒变量
    U = np.zeros((4, ) + Xc.shape)
    U[0, :, :] = rho
    U[1, :, :] = rho * u
    U[2, :, :] = rho * v
    U[3, :, :] = E

    return U



