import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import torch
from helperfunction import *

'''
Joint Post-process for 2D Rayleigh-Taylor Discontinuity Detectors: 3x4 子图联合二维间断点综合汇总大图
横向对比 (Columns):
  - Col 1: MLP (X Direction)   |  Col 2: KXRCF (X Direction)
  - Col 3: MLP (Y Direction)   |  Col 4: KXRCF (Y Direction)
纵向对比 (Rows):
  - Row 1 (30x120), Row 2 (60x240), Row 3 (120x480)
物理与边界约束：
  1. 严格适配文件名：Weno5MLP_RayleighTaylor_{res}_P0.5_results.csv / WENO5KXRCF_RayleighTaylor_{res}_Th1.0_results.csv
  2. 自动过滤带有 '#' 的全局元数据行，并完美映射自定义列名（如 Density(rho) 等）。
  3. 边界条件：左右反射（法向速度反向）、上下固定值边界（严格绑定 RT 物理场算例）。
'''

gamma = 5.0 / 3.0
model = None
device = None


def get_model():
    """全局获取神经网络模型"""
    global model, device
    if model is None:
        if torch.backends.mps.is_available():
            device = torch.device("mps")
        else:
            device = torch.device("cpu")

        ckpt = torch.load('best_model.pth', map_location=device)
        model = Weno5FDMMLP().to(device)
        model.load_state_dict(ckpt['model_state_dict'])
        model.eval()
        print("▶ [物理绑定] 神经网络模型加载完成，输入特征严格绑定物理比熵场切片。")
    return model, device


def apply_custom_rt_bc(rho_core, rhou_core, rhov_core, E_core, nx, ny, ng=3):
    """
    将 RT 算例专属边界条件应用到守恒量扩展矩阵上
    """
    U_phys = np.zeros((4, ny, nx))
    U_phys[0, :, :] = rho_core
    U_phys[1, :, :] = rhou_core
    U_phys[2, :, :] = rhov_core
    U_phys[3, :, :] = E_core

    U_ext = np.zeros((4, ny + 2 * ng, nx + 2 * ng))
    U_ext[:, ng:-ng, ng:-ng] = U_phys

    def cons_to_prim(Ui):
        rho = np.maximum(Ui[0], 1e-12)
        u = Ui[1] / rho
        v = Ui[2] / rho
        E = Ui[3]
        p = np.maximum((gamma - 1.0) * (E - 0.5 * rho * (u ** 2 + v ** 2)), 1e-12)
        return rho, u, v, p

    # ---- 1. 左边界 reflective ----
    for i in range(ng):
        U_ext[:, :, i] = U_ext[:, :, 2 * ng - 1 - i]
    rho, u, v, p = cons_to_prim(U_ext[:, :, :ng])
    u = -u
    U_ext[0, :, :ng] = rho
    U_ext[1, :, :ng] = rho * u
    U_ext[2, :, :ng] = rho * v
    U_ext[3, :, :ng] = p / (gamma - 1.0) + 0.5 * rho * (u ** 2 + v ** 2)

    # ---- 2. 右边界 reflective ----
    for i in range(ng):
        U_ext[:, :, -i - 1] = U_ext[:, :, -2 * ng + i]
    rho, u, v, p = cons_to_prim(U_ext[:, :, -ng:])
    u = -u
    U_ext[0, :, -ng:] = rho
    U_ext[1, :, -ng:] = rho * u
    U_ext[2, :, -ng:] = rho * v
    U_ext[3, :, -ng:] = p / (gamma - 1.0) + 0.5 * rho * (u ** 2 + v ** 2)

    # ---- 3. 下边界 y=0 固定 ----
    rho_b, u_b, v_b, p_b = 2.0, 0.0, 0.0, 1.0
    E_b = p_b / (gamma - 1.0) + 0.5 * rho_b * (u_b ** 2 + v_b ** 2)
    U_ext[0, :ng, :] = rho_b
    U_ext[1, :ng, :] = rho_b * u_b
    U_ext[2, :ng, :] = rho_b * v_b
    U_ext[3, :ng, :] = E_b

    # ---- 4. 上边界 y=1 固定 ----
    rho_t, u_t, v_t, p_t = 1.0, 0.0, 0.0, 2.5
    E_t = p_t / (gamma - 1.0) + 0.5 * rho_t * (u_t ** 2 + v_t ** 2)
    U_ext[0, -ng:, :] = rho_t
    U_ext[1, -ng:, :] = rho_t * u_t
    U_ext[2, -ng:, :] = rho_t * v_t
    U_ext[3, -ng:, :] = E_t

    rho_ext = np.maximum(U_ext[0, :, :], 1e-12)
    u_ext = U_ext[1, :, :] / rho_ext
    v_ext = U_ext[2, :, :] / rho_ext
    E_ext = U_ext[3, :, :]
    p_ext = np.maximum((gamma - 1.0) * (E_ext - 0.5 * rho_ext * (u_ext ** 2 + v_ext ** 2)), 1e-12)
    entropy_ext = p_ext / np.maximum(rho_ext ** gamma, 1e-12)

    return entropy_ext


def load_and_predict_rt(nx, ny, mlp_model, mlp_device, kxrcf_threshold=1.0, mlp_threshold=0.5):
    """
    单次读取各解算器的 CSV 文件，注入 RT 真实边界条件。
    """
    nghost = 3
    dx = 0.25 / nx
    dy = 1.0 / ny
    res_str = f"{nx}x{ny}"

    mlp_file = f"Weno5MLP_RayleighTaylor_{res_str}_P0.5_results.csv"
    kxrcf_file = f"WENO5KXRCF_RayleighTaylor_{res_str}_Th1.0_results.csv"

    if not os.path.exists(mlp_file) or not os.path.exists(kxrcf_file):
        print(f"❌ 警告: 未找到 {res_str} 的对应数据文件，跳过该网格层级。")
        return None, None, None, None, None, None

    # ---- [数据流 1: MLP 分支] ----
    df_mlp = pd.read_csv(mlp_file, comment='#')
    X_mesh = df_mlp["X"].values.reshape(ny, nx, order='C')
    Y_mesh = df_mlp["Y"].values.reshape(ny, nx, order='C')

    rho_m = df_mlp["Density(rho)"].values.reshape(ny, nx, order='C')
    rhou_m = df_mlp["Momentum_X(rho_u)"].values.reshape(ny, nx, order='C')
    rhov_m = df_mlp["Momentum_Y(rho_v)"].values.reshape(ny, nx, order='C')
    E_m = df_mlp["Energy(E)"].values.reshape(ny, nx, order='C')
    entropy_mlp = apply_custom_rt_bc(rho_m, rhou_m, rhov_m, E_m, nx, ny, nghost)

    # ---- [数据流 2: KXRCF 分支] ----
    df_kxrcf = pd.read_csv(kxrcf_file, comment='#')
    rho_k = df_kxrcf["Density(rho)"].values.reshape(ny, nx, order='C')
    rhou_k = df_kxrcf["Momentum_X(rho_u)"].values.reshape(ny, nx, order='C')
    rhov_k = df_kxrcf["Momentum_Y(rho_v)"].values.reshape(ny, nx, order='C')
    E_k = df_kxrcf["Energy(E)"].values.reshape(ny, nx, order='C')
    entropy_kxrcf = apply_custom_rt_bc(rho_k, rhou_k, rhov_k, E_k, nx, ny, nghost)

    mask_mlp_x = np.zeros((ny, nx), dtype=bool)
    mask_mlp_y = np.zeros((ny, nx), dtype=bool)
    mask_kxrcf_x = np.zeros((ny, nx), dtype=bool)
    mask_kxrcf_y = np.zeros((ny, nx), dtype=bool)

    # 🛠️ 1. X 方向扫描
    for j in range(ny):
        jj = j + nghost
        entropy_slice_x_full_m = entropy_mlp[jj, :]
        prob_array_x_m = predict_2d(entropy_slice_x_full_m, dx, mlp_model, mlp_device)
        prob_x_m = np.where(prob_array_x_m > mlp_threshold, 1.0, 0.0)
        for i in range(nx):
            if prob_x_m[i] == 0.0:
                mask_mlp_x[j, i] = True

        for i in range(nx):
            idx_ext = i + nghost
            u0_l = (entropy_kxrcf[jj, idx_ext - 2] + 22 * entropy_kxrcf[jj, idx_ext - 1] + entropy_kxrcf[
                jj, idx_ext]) / 24.0
            u1_l = (entropy_kxrcf[jj, idx_ext] - entropy_kxrcf[jj, idx_ext - 2]) / 2.0
            u2_l = (entropy_kxrcf[jj, idx_ext - 2] - 2 * entropy_kxrcf[jj, idx_ext - 1] + entropy_kxrcf[
                jj, idx_ext]) / 2.0

            u0_c = (entropy_kxrcf[jj, idx_ext - 1] + 22 * entropy_kxrcf[jj, idx_ext] + entropy_kxrcf[
                jj, idx_ext + 1]) / 24.0
            u1_c = (entropy_kxrcf[jj, idx_ext + 1] - entropy_kxrcf[jj, idx_ext - 1]) / 2.0
            u2_c = (entropy_kxrcf[jj, idx_ext - 1] - 2 * entropy_kxrcf[jj, idx_ext] + entropy_kxrcf[
                jj, idx_ext + 1]) / 2.0

            u0_r = (entropy_kxrcf[jj, idx_ext] + 22 * entropy_kxrcf[jj, idx_ext + 1] + entropy_kxrcf[
                jj, idx_ext + 2]) / 24.0
            u1_r = (entropy_kxrcf[jj, idx_ext + 2] - entropy_kxrcf[jj, idx_ext]) / 2.0
            u2_r = (entropy_kxrcf[jj, idx_ext] - 2 * entropy_kxrcf[jj, idx_ext + 1] + entropy_kxrcf[
                jj, idx_ext + 2]) / 2.0

            edge_R_of_L = u0_l + 0.5 * u1_l + (1.0 / 6.0) * u2_l
            edge_L_of_C = u0_c - 0.5 * u1_c + (1.0 / 6.0) * u2_c
            edge_R_of_C = u0_c + 0.5 * u1_c + (1.0 / 6.0) * u2_c
            edge_L_of_R = u0_r - 0.5 * u1_r + (1.0 / 6.0) * u2_r

            max_jump = np.max([np.abs(edge_L_of_C - edge_R_of_L), np.abs(edge_L_of_R - edge_R_of_C)])
            denominator = (dx ** 2.5) * (np.abs(entropy_kxrcf[jj, idx_ext]) + 1e-10)

            if (max_jump / denominator) > kxrcf_threshold:
                mask_kxrcf_x[j, i] = True

    # 🛠️ 2. Y 方向扫描
    for i in range(nx):
        ii = i + nghost
        entropy_slice_y_full_m = entropy_mlp[:, ii]
        prob_array_y_m = predict_2d(entropy_slice_y_full_m, dy, mlp_model, mlp_device)
        prob_y_m = np.where(prob_array_y_m > mlp_threshold, 1.0, 0.0)
        for j in range(ny):
            if prob_y_m[j] == 0.0:
                mask_mlp_y[j, i] = True

        for j in range(ny):
            idx_ext = j + nghost
            u0_l = (entropy_kxrcf[idx_ext - 2, ii] + 22 * entropy_kxrcf[idx_ext - 1, ii] + entropy_kxrcf[
                idx_ext, ii]) / 24.0
            u1_l = (entropy_kxrcf[idx_ext, ii] - entropy_kxrcf[idx_ext - 2, ii]) / 2.0
            u2_l = (entropy_kxrcf[idx_ext - 2, ii] - 2 * entropy_kxrcf[idx_ext - 1, ii] + entropy_kxrcf[
                idx_ext, ii]) / 2.0

            u0_c = (entropy_kxrcf[idx_ext - 1, ii] + 22 * entropy_kxrcf[idx_ext, ii] + entropy_kxrcf[
                idx_ext + 1, ii]) / 24.0
            u1_c = (entropy_kxrcf[idx_ext + 1, ii] - entropy_kxrcf[idx_ext - 1, ii]) / 2.0
            u2_c = (entropy_kxrcf[idx_ext - 1, ii] - 2 * entropy_kxrcf[idx_ext, ii] + entropy_kxrcf[
                idx_ext + 1, ii]) / 2.0

            u0_r = (entropy_kxrcf[idx_ext, ii] + 22 * entropy_kxrcf[idx_ext + 1, ii] + entropy_kxrcf[
                idx_ext + 2, ii]) / 24.0
            u1_r = (entropy_kxrcf[idx_ext + 2, ii] - entropy_kxrcf[idx_ext, ii]) / 2.0
            u2_r = (entropy_kxrcf[idx_ext, ii] - 2 * entropy_kxrcf[idx_ext + 1, ii] + entropy_kxrcf[
                idx_ext + 2, ii]) / 2.0

            edge_R_of_L = u0_l + 0.5 * u1_l + (1.0 / 6.0) * u2_l
            edge_L_of_C = u0_c - 0.5 * u1_c + (1.0 / 6.0) * u2_c
            edge_R_of_C = u0_c + 0.5 * u1_c + (1.0 / 6.0) * u2_c
            edge_L_of_R = u0_r - 0.5 * u1_r + (1.0 / 6.0) * u2_r

            max_jump = np.max([np.abs(edge_L_of_C - edge_R_of_L), np.abs(edge_L_of_R - edge_R_of_C)])
            denominator = (dy ** 2.5) * (np.abs(entropy_kxrcf[idx_ext, ii]) + 1e-10)

            if (max_jump / denominator) > kxrcf_threshold:
                mask_kxrcf_y[j, i] = True

    print(
        f"   📊 网格 {nx}x{ny:<3} 物理比熵扫描完毕 | MLP [X:{np.sum(mask_mlp_x):<4} Y:{np.sum(mask_mlp_y):<4}] | KXRCF [X:{np.sum(mask_kxrcf_x):<4} Y:{np.sum(mask_kxrcf_y):<4}]")
    return X_mesh, Y_mesh, mask_mlp_x, mask_mlp_y, mask_kxrcf_x, mask_kxrcf_y


def main():
    resolution_pairs = [(30, 120), (60, 240), (120, 480)]

    col_configs = [
        ('MLP', 2, 'X Direction'),  # Col 1
        ('KXRCF', 4, 'X Direction'),  # Col 2
        ('MLP', 3, 'Y Direction'),  # Col 3
        ('KXRCF', 5, 'Y Direction')  # Col 4
    ]

    mlp_model, mlp_device = get_model()
    sub_indices = [f"({chr(97 + i)})" for i in range(12)]

    print(fr"====== 🚀 正在启动 2D Rayleigh-Taylor 间断探测多轴汇总图生成 ======")

    data_cache = {}
    for nx, ny in resolution_pairs:
        res = load_and_predict_rt(nx, ny, mlp_model, mlp_device, kxrcf_threshold=1.0, mlp_threshold=0.5)
        if res[0] is not None:
            data_cache[(nx, ny)] = res

    print("========================================================================\n")

    stats_summary = []

    # 稍微拓宽画布宽度，为两行独立标题的展开留足空间
    fig, axes = plt.subplots(3, 4, figsize=(21, 27))

    for row_idx, (nx, ny) in enumerate(resolution_pairs):
        if (nx, ny) not in data_cache:
            continue
        row_data = data_cache[(nx, ny)]

        X_flat = row_data[0].flatten()
        Y_flat = row_data[1].flatten()

        for col_idx, (method, data_idx, dir_name) in enumerate(col_configs):
            ax = axes[row_idx, col_idx]
            current_mask_flat = row_data[data_idx].flatten()

            total_points = nx * ny
            troubled_points = np.sum(current_mask_flat)
            percentage = (troubled_points / total_points) * 100

            stats_summary.append({
                "Resolution": f"{nx}x{ny}",
                "Method": method,
                "Direction": dir_name,
                "Troubled_Count": troubled_points,
                "Total_Count": total_points,
                "Ratio_Pct": percentage
            })

            marker_size = 12 if nx <= 30 else (5 if nx <= 60 else 1.2)

            ax.scatter(X_flat[current_mask_flat], Y_flat[current_mask_flat],
                       s=marker_size, c='red', marker='s', edgecolors='none')

            ax.set_aspect('equal')
            ax.set_xlim(0.0, 0.25)
            ax.set_ylim(0.0, 1.0)
            ax.set_xticks([0.0, 0.25])
            ax.set_yticks([0.0, 0.5, 1.0])

            ax.tick_params(axis='both', which='major', direction='in', top=True, right=True, length=5, labelsize=22,
                           pad=6)
            ax.set_xlabel('X', fontsize=30, labelpad=4)

            if col_idx == 0:
                ax.set_ylabel('Y', fontsize=30, labelpad=4)
            else:
                ax.tick_params(axis='y', labelleft=False)

            # 🛠️ 【核心修改点：小标题双行排版控制】
            # 将主标题（序号+算子）与副标题（方向+分辨率）通过换行符分离，并让其在 X 轴标签正下方垂直堆叠
            flat_idx = row_idx * 4 + col_idx

            line1 = fr"{sub_indices[flat_idx]} {method}"
            line2 = fr"{dir_name} ($\mathrm{{N}}_x \times \mathrm{{N}}_y = {nx} \times {ny}$)"
            full_title_two_lines = f"{line1}\n{line2}"

            # y=-0.15 确保第一行不紧贴 X 标签，va='top' 让多行文本自上而下自然延伸
            ax.text(0.5, -0.15, transform=ax.transAxes, s=full_title_two_lines,
                    fontsize=20, va='top', ha='center', linespacing=1.2)

    # 🟢 终端独立格式化打印量化统计表
    print("\n" + "=" * 80)
    print(f"{'2D Rayleigh-Taylor 间断点探测百分比量化统计表':^72}")
    print("=" * 80)
    print(
        f"{'网格规模':<12} | {'探测算子':<8} | {'扫描方向':<14} | {'间断点数':<10} | {'总网格数':<10} | {'占比 (Ratio)'}")
    print("-" * 80)
    for item in stats_summary:
        print(
            f"{item['Resolution']:<12} | {item['Method']:<8} | {item['Direction']:<14} | {item['Troubled_Count']:<10} | {item['Total_Count']:<10} | {item['Ratio_Pct']:.4f}%")
    print("=" * 80 + "\n")

    # 💡 由于小标题变为双行占用更多垂直空间，我们将 hspace 略微放松到 0.28，既紧凑又绝不重叠
    plt.tight_layout(rect=[0.02, 0.03, 0.98, 0.98])
    plt.subplots_adjust(wspace=0.14, hspace=0.28)

    output_pdf = "RT_Discontinuity.pdf"
    plt.savefig(output_pdf, dpi=300, bbox_inches='tight')
    print(f"📊 3x4 RT 综合大图（已完备修正物理边界并启用双行小标题）已保存至: {output_pdf}")
    plt.show()


if __name__ == "__main__":
    main()