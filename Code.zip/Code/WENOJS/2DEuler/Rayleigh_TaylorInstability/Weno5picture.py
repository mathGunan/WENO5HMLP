import numpy as np
import matplotlib.pyplot as plt

# ------------------------
# 加载数据
# ------------------------
Nx = 30
Ny = 120
filename_prefix = f"Weno5FDM2DRT_{Nx}x{Ny}_results"
npz_filename = f"{filename_prefix}.npz"

data = np.load(npz_filename)
rho = data['rho']  # 内部网格密度 (Ny, Nx)


print(f"密度最小值: {np.min(rho):.6f}")
print(f"密度最大值: {np.max(rho):.6f}")

# ------------------------
# 网格坐标
# ------------------------
Lx = 0.25
Ly = 1.0
dx = Lx / Nx
dy = Ly / Ny

x = np.linspace(dx/2, Lx-dx/2, Nx)
y = np.linspace(dy/2, Ly-dy/2, Ny)
X, Y = np.meshgrid(x, y, indexing='xy')

# ------------------------
# 绘图 - 自动适应数据范围
# ------------------------
plt.figure(figsize=(3, 10))  # 高度大于宽度，适应 y 轴长

# 自动设置颜色范围
levels = np.linspace(0.9, 2.35, 30)

# 填色等高线
cp = plt.contour(X, Y, rho, levels, cmap='viridis')

xticks = [0.0, 0.10,0.20]
yticks = [0.0,0.2, 0.4, 0.6, 0.8,1.0]
plt.xticks(xticks)
plt.yticks(yticks)

# 设置坐标轴范围
plt.xlim(0, Lx)
plt.ylim(0, Ly)
plt.tight_layout()
# 保存 PDF 文件
plt.savefig(f"{filename_prefix}.pdf", bbox_inches='tight', dpi=600)
plt.show()
