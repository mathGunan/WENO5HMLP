import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

'''
Joint Post-process for 2D Euler Implosion Problem: 3x3 子图联合二维全域等高线填充图
区域限制: X 轴 [0.0, 1.5] | Y 轴 [0.0, 1.5]
横向对比: Column 1 (WENO5), Column 2 (KXRCF), Column 3 (MLP)
纵向对比: Row 1 (N=100), Row 2 (N=200), Row 3 (N=400)
'''

def load_csv_data(filepath, N):
    """
    高效读取 CSV 数据，并将展平的数据重构为二维矩阵。
    同步返回全域内的极值。
    """
    if not os.path.exists(filepath):
        print(f"❌ 警告: 未找到文件 {filepath}")
        return None, None, None, None, None

    skip_rows = 0
    with open(filepath, 'r', encoding='utf-8') as f:
        for line in f:
            if line.startswith('#'):
                skip_rows += 1
            else:
                break

    df = pd.read_csv(filepath, skiprows=skip_rows)

    # 重构为 (N, N) 空间矩阵
    X = df['X'].values.reshape(N, N)
    Y = df['Y'].values.reshape(N, N)
    rho = df['Density(rho)'].values.reshape(N, N)

    rho_min = rho.min()
    rho_max = rho.max()

    return X, Y, rho, rho_min, rho_max


def main():
    plt.rcParams.update({
        'text.usetex': False
    })

    # 纵向分辨率
    row_resolutions = [100, 200, 400]

    # 列（Columns）：严格规范为 WENO5, KXRCF, MLP 命名
    col_schemes = [
        {'key': 'PureWENO5', 'label': 'WENO5', 'template': "Weno52DEulerImplosion_{N}x{N}_results.csv"},
        {'key': 'Weno5KXRCF', 'label': 'KXRCF', 'template': "Weno5KXRCF2DEulerImplosion_{N}x{N}_Th1.0_results.csv"},
        {'key': 'Weno5MLP', 'label': 'MLP', 'template': "Weno5MLP2DEulerImplosion_{N}x{N}_P0.5_results.csv"}
    ]

    # 自动化生成学术子图序号 ['(a)', '(b)', ..., '(i)']
    sub_indices = [f"({chr(97 + i)})" for i in range(9)]

    # 设定内爆问题的全域区间
    xmin, xmax = 0.0, 1.5
    ymin, ymax = 0.0, 1.5

    print(f"====== 🚀 正在扫描 [{xmin}, {xmax}] 全域内的 2D Euler 内爆问题密度极值 ======")

    # 1. 第一遍预加载：扫描极值
    data_cache = {}
    all_mins = []
    all_maxs = []

    for N in row_resolutions:
        for col_idx, scheme in enumerate(col_schemes):
            filename = scheme['template'].format(N=N)
            X, Y, rho, r_min, r_max = load_csv_data(filename, N)
            data_cache[(N, col_idx)] = (X, Y, rho)
            if rho is not None:
                all_mins.append(r_min)
                all_maxs.append(r_max)
                print(f"   📊 网格 [{N}x{N:<3}] | 格式 [{scheme['label']:<5}] -> rho_min = {r_min:9.6f} | rho_max = {r_max:9.6f}")

    if not all_mins:
        print("❌ 错误: 未能读取到任何有效数据，请检查当前目录下是否存在对应的 CSV 文件。")
        return

    global_min_detected = min(all_mins)
    global_max_detected = max(all_maxs)
    print("=========================================================================")
    print(f"💡 [建议控标范围]: global_levels = np.linspace({global_min_detected:.2f}, {global_max_detected:.2f}, 45)")
    print("=========================================================================\n")

    # =========================================================================
    # 🟢 【手动控标区】：获取打印结果后可在此输入您的确切范围
    # =========================================================================
    global_levels = np.linspace(0.06, 0.3, 30)
    cmap_choice = 'viridis'

    fig, axes = plt.subplots(3, 3, figsize=(30, 31))

    # 遍历 3x3 矩阵开始绘制
    for row_idx, N in enumerate(row_resolutions):
        for col_idx, scheme in enumerate(col_schemes):
            ax = axes[row_idx, col_idx]
            X, Y, rho = data_cache[(N, col_idx)]

            if rho is not None:
                X_filled = np.clip(X, xmin, xmax)
                Y_filled = np.clip(Y, ymin, ymax)

                # Step 1: 颜色填充
                cf = ax.contourf(X_filled, Y_filled, rho,
                                 levels=global_levels,
                                 cmap=cmap_choice,
                                 extend='both')

                # Step 2: 极细轮廓线
                ax.contour(X, Y, rho,
                           levels=global_levels,
                           colors='black',
                           linewidths=0.4,
                           alpha=0.8)
            else:
                ax.text(0.5, 0.5, f'Data Missing\n{scheme["label"]}\nN = {N}',
                        ha='center', va='center', fontsize=24, color='red')
                ax.set_xlim(xmin, xmax)
                ax.set_ylim(ymin, ymax)
                continue

            ax.set_aspect('equal')
            ax.grid(True, linestyle=':', alpha=0.2, color='white')

            # 轴范围与刻度设置
            ax.set_xlim(xmin, xmax)
            ax.set_ylim(ymin, ymax)
            ax.set_xticks([0.0, 0.5, 1.0, 1.5])
            ax.set_yticks([0.0, 0.5, 1.0, 1.5])

            # X 轴标签配置
            ax.tick_params(axis='x', direction='in', top=True, right=True,
                           length=5, width=1.0, labelsize=38, pad=20)
            ax.set_xlabel('X', fontsize=45, labelpad=18)

            # Y 轴标签配置
            if col_idx == 0:
                ax.set_ylabel('Y', fontsize=45, labelpad=15)
                ax.tick_params(axis='y', direction='in', top=True, right=True,
                               length=5, width=1.0, labelsize=38, pad=20)
            else:
                ax.tick_params(axis='y', direction='in', top=True, right=True,
                               length=5, width=1.0, labelleft=False)

            # 子图正下方小标题精密定位
            flat_idx = row_idx * 3 + col_idx
            full_title = fr"{sub_indices[flat_idx]} {scheme['label']} ($\mathrm{{N}}_x=\mathrm{{N}}_y={N}$)"

            title_y_position = -0.32
            ax.text(0.5, title_y_position, full_title, transform=ax.transAxes,
                    fontsize=45, va='top', ha='center')

    plt.tight_layout(rect=[0.04, 0.04, 0.96, 0.97], h_pad=3.5, w_pad=3.0)

    output_pdf = "2DEuler_Implosion_compare.pdf"
    plt.savefig(output_pdf, dpi=300)
    print(f"\n📊 [绘图成功] 全域 3x3 颜色填充内爆问题图像已成功导出至: {output_pdf}")
    plt.show()


if __name__ == "__main__":
    main()