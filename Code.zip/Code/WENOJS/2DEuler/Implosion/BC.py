import numpy as np


def apply_solid_wall_bc(U, nghost=3):
    """
    为欧拉方程应用固壁边界条件（滑移条件）
    Parameters:
    U: 守恒变量 [4, ny, nx]
    nghost: 虚拟网格层数

    Returns:
    U_ext: 扩展后的守恒变量 [4, ny+2*nghost, nx+2*nghost]
    """
    # 扩展数组 [4, ny+2*nghost, nx+2*nghost]
    U_ext = np.zeros((4, U.shape[1] + 2 * nghost, U.shape[2] + 2 * nghost))

    # 内部区域赋值
    U_ext[:, nghost:-nghost, nghost:-nghost] = U.copy()

    # 应用固壁边界条件到虚拟网格点
    for i in range(nghost):
        # 左边界 (x = 0) - 法向为x方向
        U_ext[0, :, nghost - 1 - i] = U_ext[0, :, nghost + i]  # 密度: 对称
        U_ext[1, :, nghost - 1 - i] = -U_ext[1, :, nghost + i]  # x动量: 反对称 (法向)
        U_ext[2, :, nghost - 1 - i] = U_ext[2, :, nghost + i]  # y动量: 对称 (切向)
        U_ext[3, :, nghost - 1 - i] = U_ext[3, :, nghost + i]  # 总能量: 对称

        # 右边界 (x = Lx) - 法向为x方向
        U_ext[0, :, -nghost + i] = U_ext[0, :, -nghost - 1 - i]  # 密度: 对称
        U_ext[1, :, -nghost + i] = -U_ext[1, :, -nghost - 1 - i]  # x动量: 反对称 (法向)
        U_ext[2, :, -nghost + i] = U_ext[2, :, -nghost - 1 - i]  # y动量: 对称 (切向)
        U_ext[3, :, -nghost + i] = U_ext[3, :, -nghost - 1 - i]  # 总能量: 对称

        # 下边界 (y = 0) - 法向为y方向
        U_ext[0, nghost - 1 - i, :] = U_ext[0, nghost + i, :]  # 密度: 对称
        U_ext[1, nghost - 1 - i, :] = U_ext[1, nghost + i, :]  # x动量: 对称 (切向)
        U_ext[2, nghost - 1 - i, :] = -U_ext[2, nghost + i, :]  # y动量: 反对称 (法向)
        U_ext[3, nghost - 1 - i, :] = U_ext[3, nghost + i, :]  # 总能量: 对称

        # 上边界 (y = Ly) - 法向为y方向
        U_ext[0, -nghost + i, :] = U_ext[0, -nghost - 1 - i, :]  # 密度: 对称
        U_ext[1, -nghost + i, :] = U_ext[1, -nghost - 1 - i, :]  # x动量: 对称 (切向)
        U_ext[2, -nghost + i, :] = -U_ext[2, -nghost - 1 - i, :]  # y动量: 反对称 (法向)
        U_ext[3, -nghost + i, :] = U_ext[3, -nghost - 1 - i, :]  # 总能量: 对称

    return U_ext  # 正确的缩进 - 在循环外返回！