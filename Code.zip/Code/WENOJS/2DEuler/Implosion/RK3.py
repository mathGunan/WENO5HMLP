from ROEFLUX import *
from BC import *


def SolverWeno5Rk3(U_phys, dx, dy, dt, gamma=1.4, nghost=3, epsilon=1e-6):
    """
    纯五阶 WENO5 + Roe 格式的全局三步 TVD-Runge-Kutta 时间推进器。
    完美对齐 compute_rhs_pure_weno5 函数接口。
    """
    # =========================================================================
    # === Stage 1 ===
    # =========================================================================
    U_ext = apply_solid_wall_bc(U_phys, nghost=nghost)

    # 调用纯五阶 WENO5 右端项计算算子
    rhs1 = compute_rhs_pure_weno5(
        U_ext=U_ext,
        dx=dx,
        dy=dy,
        gamma=gamma,
        nghost=nghost,
        epsilon=epsilon
    )
    U1 = U_phys + dt * rhs1

    # =========================================================================
    # === Stage 2 ===
    # =========================================================================
    U1_ext = apply_solid_wall_bc(U1, nghost=nghost)

    # 针对第一子步更新后的中间流场 U1_ext 重新计算全局空间残差
    rhs2 = compute_rhs_pure_weno5(
        U_ext=U1_ext,
        dx=dx,
        dy=dy,
        gamma=gamma,
        nghost=nghost,
        epsilon=epsilon
    )
    U2 = 0.75 * U_phys + 0.25 * (U1 + dt * rhs2)

    # =========================================================================
    # === Stage 3 ===
    # =========================================================================
    U2_ext = apply_solid_wall_bc(U2, nghost=nghost)

    # 针对第二子步更新后的中间流场 U2_ext 进行最终的空间通量解算
    rhs3 = compute_rhs_pure_weno5(
        U_ext=U2_ext,
        dx=dx,
        dy=dy,
        gamma=gamma,
        nghost=nghost,
        epsilon=epsilon
    )
    U_next = (1.0 / 3.0) * U_phys + (2.0 / 3.0) * (U2 + dt * rhs3)

    return U_next


def SolverKXRCFRk3(U_phys, dx, dy, dt, gamma=1.4, threshold=1.0, nghost=3, epsilon=1e-6):
    """
    二维 Euler 方程三阶 TVD-Runge-Kutta 时间推进器。
    【严格物理对齐】：每个 Stage 内部调用基于一维物理标量熵判定的高精度空间算子。

    参数:
        U_phys    : ndarray, shape (4, Ny, Nx) -> 当前时步的真实物理域守恒变量
        dx, dy    : float -> 网格间距
        dt        : float -> 当前步长 (由 CFL 条件动态计算得到)
        gamma     : float -> 比热比
        threshold : float -> 比熵间断探测器学术阈值 (对齐一维锁死 1.0)
        nghost    : int -> 幽灵层数量
        epsilon   : float -> WENO5 光滑指示器小量

    返回:
        U_next    : ndarray, shape (4, Ny, Nx) -> 下一个时步的物理域守恒变量
    """

    # =========================================================================
    # === Stage 1 ===
    # =========================================================================
    # 1. 施加二维边界条件（填充幽灵层），此处采用您主程序对应的流出边界或通用边界函数
    U_ext = apply_solid_wall_bc(U_phys, nghost)

    # 2. 计算空间残差右端项（基于严格的一维标量比熵 KXRCF/MLP 混合探测逻辑）
    rhs1 = compute_rhs_KXRCF(
        U_ext, dx, dy, gamma=gamma, threshold=threshold, nghost=nghost, epsilon=epsilon
    )

    # 3. 更新第一步中间态
    U1 = U_phys + dt * rhs1

    # =========================================================================
    # === Stage 2 ===
    # =========================================================================
    # 1. 对第一步中间态物理域应用边界层扩展
    U1_ext = apply_solid_wall_bc(U1, nghost)

    # 2. 计算中间态 U1 下的空间物理残差
    rhs2 = compute_rhs_KXRCF(
        U1_ext, dx, dy, gamma=gamma, threshold=threshold, nghost=nghost, epsilon=epsilon
    )

    # 3. 凸组合更新第二步中间态（严格满足三阶 TVD 稳定性约束）
    U2 = 0.75 * U_phys + 0.25 * U1 + 0.25 * dt * rhs2

    # =========================================================================
    # === Stage 3 ===
    # =========================================================================
    # 1. 对第二步中间态物理域应用边界层扩展
    U2_ext = apply_solid_wall_bc(U2, nghost)

    # 2. 计算中间态 U2 下的空间物理残差
    rhs3 = compute_rhs_KXRCF(
        U2_ext, dx, dy, gamma=gamma, threshold=threshold, nghost=nghost, epsilon=epsilon
    )

    # 3. 最终组合，得到下一时步的完全守恒物性场 U_next
    U_next = (1.0 / 3.0) * U_phys + (2.0 / 3.0) * U2 + (2.0 / 3.0) * dt * rhs3

    return U_next




def SolverWeno5Rk3_MLP(U_phys, dx, dy, dt, model, device, gamma=1.4, threshold=0.5, nghost=3):
    """
    常规物理仿真版：在每一个 Runge-Kutta 子步内伴随 RHS 计算自动动态产生并更新内场 prob 矩阵
    """
    # -------------------------------------------------------------------------
    # --- Stage 1 ---
    # -------------------------------------------------------------------------
    U_ext = apply_solid_wall_bc(U_phys, nghost=nghost)

    # 完美透传 model 和 device，由 RHS 内部动态提取当前 U_ext 的一维熵切片并生成 prob 矩阵
    rhs1 = compute_rhs_2d_with_MLP(
        U_ext=U_ext,
        dx=dx,
        dy=dy,
        model=model,
        device=device,
        gamma=gamma,
        threshold=threshold,
        nghost=nghost
    )
    U1 = U_phys + dt * rhs1

    # -------------------------------------------------------------------------
    # --- Stage 2 ---
    # -------------------------------------------------------------------------
    U1_ext = apply_solid_wall_bc(U1, nghost=nghost)

    # 针对 Stage 1 更新后的中间流场 U1_ext，由 RHS 内部重新前向推理以准确追踪激波位置
    rhs2 = compute_rhs_2d_with_MLP(
        U_ext=U1_ext,
        dx=dx,
        dy=dy,
        model=model,
        device=device,
        gamma=gamma,
        threshold=threshold,
        nghost=nghost
    )
    U2 = 0.75 * U_phys + 0.25 * (U1 + dt * rhs2)

    # -------------------------------------------------------------------------
    # --- Stage 3 ---
    # -------------------------------------------------------------------------
    U2_ext = apply_solid_wall_bc(U2, nghost=nghost)

    # 针对 Stage 2 更新后的中间流场 U2_ext，由 RHS 内部第三次调用神经网络更新 troubled-point 判定
    rhs3 = compute_rhs_2d_with_MLP(
        U_ext=U2_ext,
        dx=dx,
        dy=dy,
        model=model,
        device=device,
        gamma=gamma,
        threshold=threshold,
        nghost=nghost
    )
    U_next = (1.0 / 3.0) * U_phys + (2.0 / 3.0) * (U2 + dt * rhs3)

    return U_next


