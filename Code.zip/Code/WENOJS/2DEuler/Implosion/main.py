import csv
import time
import numpy as np
from RK3 import *
from IC import *
from helperfunction import *

gamma = 1.4


def compute_single_run(N, T_final=3.2):
    """
    单次网格规模的 2D Euler 内爆问题（Implosion Problem）计算算子
    定义域已更新为 [0, 1.5] x [0, 1.5]，最终时间为 3.2
    """
    nx = ny = N
    Lx = Ly = 1.5  # 内爆问题物理空间定义域为 0 ~ 1.5
    dx = Lx / nx
    dy = Ly / ny

    # 网格中心坐标
    x = np.linspace(dx / 2, Lx - dx / 2, nx)
    y = np.linspace(dy / 2, Ly - dy / 2, ny)
    Xc, Yc = np.meshgrid(x, y, indexing='xy')

    # 初始条件 (包含 4 个守恒量)
    U = IC(Xc, Yc)  # shape (4, ny, nx)

    # 时间推进
    t = 0.0
    iteration = 0
    start_time = time.time()

    while t < T_final:
        dt = compute_time_step(U, dx, dy)
        if t + dt > T_final:
            dt = T_final - t
        U = SolverWeno5Rk3(U, dx, dy, dt)
        t += dt
        iteration += 1

        if iteration % 50 == 0:
            progress = t / T_final * 100
            print(f"N={N}: 进度 {progress:.1f}%, 迭代 {iteration}")

    cpu_time = time.time() - start_time
    print(f"总耗时 (秒): {cpu_time:.4f}")

    return Xc, Yc, U, cpu_time


def main():
    print("开始 2D Euler (WENO5 + Roe) implosion problem...")
    N = 200  # 先用小网格测试,目标是400*400
    T_final = 3.2  # 计算最终截止物理时间为 3.2

    # 执行仿真计算
    Xc, Yc, U_final, cpu_time = compute_single_run(N, T_final=T_final)

    # 提取最后时刻的 4 个完整守恒量分量
    rho_num = U_final[0, :, :]
    rhou_num = U_final[1, :, :]
    rhov_num = U_final[2, :, :]
    E_num = U_final[3, :, :]

    # 将二维空间网格及流场展平为一维列，以便标准 CSV 表格化存储
    x_flat = Xc.flatten()
    y_flat = Yc.flatten()
    rho_flat = rho_num.flatten()
    rhou_flat = rhou_num.flatten()
    rhov_flat = rhov_num.flatten()
    E_flat = E_num.flatten()

    # 规范化 CSV 命名，清晰标记为 WENO5 算法与网格点数参数
    csv_filename = f"Weno52DEulerImplosion_{N}x{N}_results.csv"

    # 使用标准库 csv 严格按规定格式安全写入
    with open(csv_filename, mode='w', newline='', encoding='utf-8') as f:
        writer = csv.writer(f)

        # 1. 在 CSV 头部前两行写入全局元数据
        writer.writerow(["# Global Metadata", f"Total_CPU_Time_Seconds: {cpu_time:.6f}"])

        # 2. 写入标准的【守恒量】列标题
        writer.writerow(["X", "Y", "Density(rho)", "Momentum_X(rho_u)", "Momentum_Y(rho_v)", "Energy(E)"])

        # 3. 逐行写入流场各网格点上的位置与守恒量分量
        for i in range(len(x_flat)):
            writer.writerow([
                f"{x_flat[i]:.6e}",
                f"{y_flat[i]:.6e}",
                f"{rho_flat[i]:.6e}",
                f"{rhou_flat[i]:.6e}",
                f"{rhov_flat[i]:.6e}",
                f"{E_flat[i]:.6e}"
            ])

    print("----------------------------------------------------")
    print(f"内爆问题流场 CSV 数据保存完毕。最终 CSV 文件路径: {csv_filename}")
    print("====================================================")


if __name__ == "__main__":
    main()