import numpy as np


def IC(Xc, Yc):
    """
    二维欧拉方程爆炸问题 (Example 11 in WENO3-SNN Paper)
    该算例模拟高压高密度圆柱区域向外膨胀的过程。
    输入:
        Xc, Yc: 网格中心坐标数组，形状 (Ny, Nx)，范围通常为 [0, 1.5] x [0, 1.5]
    输出:
        U: 守恒量矩阵, shape (4, Ny, Nx)
           [rho, rho*u, rho*v, E]
    """
    GAMMA = 1.4

    # --- 初始状态参数设定 ---
    # 圆内状态 (Inside)
    rho_in, u_in, v_in, p_in = 1.0, 0.0, 0.0, 1.0
    # 圆外状态 (Outside)
    rho_out, u_out, v_out, p_out = 0.125, 0.0, 0.0, 0.1

    # 几何参数：圆心在 (0, 0)，半径的平方 R^2 = 0.4^2 = 0.16
    R_squared = 0.16

    # --- 初始化变量 ---
    rho = np.full_like(Xc, rho_out)
    u = np.zeros_like(Xc)
    v = np.zeros_like(Xc)
    p = np.full_like(Xc, p_out)

    # --- 使用圆方程定义区域 ---
    # 计算每个网格点到原点的距离平方
    dist_squared = Xc ** 2 + Yc ** 2

    # 掩码：判定哪些点在圆内
    inside_mask = dist_squared < R_squared

    # 赋值圆内状态
    rho[inside_mask] = rho_in
    u[inside_mask] = u_in
    v[inside_mask] = v_in
    p[inside_mask] = p_in

    # --- 转换为守恒量形式 ---
    # 能量 E = P/(gamma-1) + 0.5*rho*(u^2 + v^2)
    E = p / (GAMMA - 1.0) + 0.5 * rho * (u ** 2 + v ** 2)
    U = np.stack([rho, rho * u, rho * v, E])

    return U