import csv
import time
import numpy as np
from RK3 import SolverWeno5Rk3_MLP  # 严格导入匹配您最新接口的 MLP 时间推进求解器
from IC import *
from helperfunction import *

gamma = 1.4


def compute_single_run_MLP(N, T_final=3.2, P=0.5):
    """
    单次网格规模的神经网络自适应调控（WENO5-MLP）内爆问题计算算子
    定义域已更新为 [0, 1.5] x [0, 1.5]，最终时间为 3.2
    """
    nghost = 3  # 统一使用物理区域 3 层 ghost cells 约定
    nx = ny = N
    Lx = Ly = 1.5  # 内爆问题物理空间定义域修改为 0 ~ 1.5
    dx = Lx / nx
    dy = Ly / ny

    # 网格中心坐标
    x = np.linspace(dx / 2, Lx - dx / 2, nx)
    y = np.linspace(dy / 2, Ly - dy / 2, ny)
    Xc, Yc = np.meshgrid(x, y, indexing='xy')

    # 初始条件 (返回纯物理域 [4, ny, nx])
    U = IC(Xc, Yc)

    # 只加载模型一次
    model, device = get_model()

    # 时间推进
    t = 0.0
    iteration = 0
    start_time = time.time()

    while t < T_final:
        # 基于当前物理场 U 计算安全时步 dt
        dt = compute_time_step(U, dx, dy)

        # 最后一步 dt 修正，保证 t 不超过 T_final
        if t + dt > T_final:
            dt = T_final - t

        # 调用已经对齐新接口的 SolverWeno5Rk3_MLP 求解器，严格传递控制参数
        # 内部会全自动动态调用对应的固壁边界条件（apply_solid_wall_bc）
        U = SolverWeno5Rk3_MLP(
            U_phys=U,
            dx=dx,
            dy=dy,
            dt=dt,
            model=model,
            device=device,
            gamma=gamma,
            threshold=P,
            nghost=nghost
        )

        t += dt
        iteration += 1

        if iteration % 50 == 0 or t >= T_final:
            progress = (t / T_final) * 100
            min_rho = np.min(U[0])
            print(f"[WENO5-MLP] 网格规模 {N}x{N} (P={P}): 进度 {progress:.1f}%, 迭代步数 {iteration}, 物理时间 t={t:.4f}")

            # 安全熔断检查
            if np.isnan(min_rho):
                print("❌ 检测到流场发散 (NaN)！熔断程序以保护计算资源。")
                break

    cpu_time = time.time() - start_time
    print(f"WENO5-MLP 内爆问题计算完成，总耗时: {cpu_time:.4f} 秒，总迭代次数: {iteration}")

    return Xc, Yc, U, cpu_time


def main():
    print("====================================================")
    print("  开启 2D Euler (WENO5MLP + Roe) Implosion 基准计算  ")
    print("====================================================")

    N = 200        # 先用小网格测试, 目标是 400*400
    T_final = 3.2  # 计算最终截止物理时间修改为 3.2
    P = 0.5        # Troubled-point 神经网络判定分类阈值

    # 执行仿真计算
    Xc, Yc, U_final, cpu_time = compute_single_run_MLP(N, T_final=T_final, P=P)

    # 提取最后时刻的 4 个完整守恒量分量
    rho_num = U_final[0, :, :]
    rhou_num = U_final[1, :, :]
    rhov_num = U_final[2, :, :]
    E_num = U_final[3, :, :]

    # 将二维空间网格及流场展平为一维列，以便标准 CSV 表格化存储
    x_flat = Xc.flatten()
    y_flat = Yc.flatten()
    rho_flat = rho_num.flatten()
    rhou_flat = rhou_num.flatten()
    rhov_flat = rhov_num.flatten()
    E_flat = E_num.flatten()

    # 规范化 CSV 命名，清晰标记为 WENO5MLP 算法、网格点数与分类阈值参数
    csv_filename = f"Weno5MLP2DEulerImplosion_{N}x{N}_P{P}_results.csv"

    # 使用标准库 csv 严格按规定格式安全写入
    with open(csv_filename, mode='w', newline='', encoding='utf-8') as f:
        writer = csv.writer(f)

        # 1. 在 CSV 头部前两行写入全局元数据（保留总 CPU 时间以供后续效率/加速比对比）
        writer.writerow(["# Global Metadata", f"Total_CPU_Time_Seconds: {cpu_time:.6f}"])

        # 2. 写入标准的【守恒量】列标题
        writer.writerow(["X", "Y", "Density(rho)", "Momentum_X(rho_u)", "Momentum_Y(rho_v)", "Energy(E)"])

        # 3. 逐行写入流场各网格点上的位置与守恒量分量
        for i in range(len(x_flat)):
            writer.writerow([
                f"{x_flat[i]:.6e}",
                f"{y_flat[i]:.6e}",
                f"{rho_flat[i]:.6e}",
                f"{rhou_flat[i]:.6e}",
                f"{rhov_flat[i]:.6e}",
                f"{E_flat[i]:.6e}"
            ])

    print("----------------------------------------------------")
    print(f"WENO5-MLP 内爆问题流场 CSV 数据保存完毕。最终 CSV 文件路径: {csv_filename}")
    print("====================================================")


if __name__ == "__main__":
    main()