import csv
import numpy as np
import matplotlib.pyplot as plt

# 完美对接您的专用函数模块 (包含边界条件等基本框架)
from BC import *
from helperfunction import *

'''
Joint Post-process for 3 Hyperbolic Conservation Laws Problems (3x3 Canvas)
【数据源硬核对齐】：彻底剔除原 MLP 数据集，全盘加载由 WENO5-H-KXRCF 求解器生成的真实数值解 CSV。
【特征与边界硬核对齐】：
  - Row 0 (Sedov) & Row 1 (Double Blast): 输入KXRCF的物理熵经过 apply_reflective_bc_scalar 的镜像反射拓扑。
  - Row 2 (Shu-Osher): 输入KXRCF的物理熵经过 apply_shu_osher_bc_scalar 的左固定流入、右零阶外推拓扑。
【图例规范严格闭锁】：全局图例有且仅有两个标签：'Reference' 与 'WENO5-H-KXRCF'，不掺杂任何多余符号。
【高阶指标统计保留】：控制台深度打印每个算例及对应网格分辨率下 KXRCF 智能捕捉的坏点总数与高精度百分比。
'''


def load_euler_csv_data_generic(filename):
    """
    通用安全读取标准 CSV 数据，自适应兼容三种经典问题的列名
    """
    x_center, rho_numerical, p_numerical = [], [], []
    try:
        with open(filename, mode='r', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            for row in reader:
                # 兼容 x 坐标轴列名
                if "x" in row:
                    x_center.append(float(row["x"]))
                elif "x_center" in row:
                    x_center.append(float(row["x_center"]))

                # 兼容密度列名
                if "rho" in row:
                    rho_numerical.append(float(row["rho"]))
                elif "Exact_solution_T" in row:
                    rho_numerical.append(float(row["Exact_solution_T"]))
                elif "rho_primitive" in row:
                    rho_numerical.append(float(row["rho_primitive"]))

                # 兼容压力列名
                if "p" in row:
                    p_numerical.append(float(row["p"]))
                elif "p_primitive" in row:
                    p_numerical.append(float(row["p_primitive"]))
                else:
                    p_numerical.append(0.0)
    except FileNotFoundError:
        print(f"❌ 警告: 未找到文件 {filename}")
        return None, None, None
    return np.array(x_center), np.array(rho_numerical), np.array(p_numerical)


def apply_reflective_bc_scalar(entropy_1d, nghost=3):
    """针对标量非线性物理熵的刚性反射墙边界条件 (镜像映射)"""
    N = len(entropy_1d)
    entropy_ext = np.zeros(N + 2 * nghost)
    entropy_ext[nghost:-nghost] = entropy_1d
    entropy_ext[:nghost] = entropy_1d[nghost - 1::-1]
    entropy_ext[-nghost:] = entropy_1d[-1:-nghost - 1:-1]
    return entropy_ext


def apply_shu_osher_bc_scalar(entropy_1d, gamma=1.4, nghost=3):
    """针对 Shu-Osher 问题标量物理熵的定制边界条件：左边固定流入熵，右边自由流出（零阶外推）"""
    N = len(entropy_1d)
    entropy_ext = np.zeros(N + 2 * nghost)
    entropy_ext[nghost:-nghost] = entropy_1d

    rho_L, p_L = 3.857143, 10.3333
    entropy_L = p_L / (rho_L ** gamma)
    for i in range(nghost):
        entropy_ext[i] = entropy_L

    for i in range(nghost):
        entropy_ext[-nghost + i] = entropy_1d[-1]

    return entropy_ext


def run_kxrcf_core_logic(entropy_ext, dx, N, threshold=1.0, nghost=3):
    """
    核心KXRCF探测核心机制：直接提取自您编写的高阶特征界面跳跃代码逻辑。
    """
    prob_length = N + 2
    is_troubled_full = np.zeros(prob_length, dtype=bool)

    for i in range(prob_length):
        idx_ext = i + (nghost - 1)

        # 您的精确 KXRCF 界面重构多项式系数
        u0_l = (entropy_ext[idx_ext - 2] + 22 * entropy_ext[idx_ext - 1] + entropy_ext[idx_ext]) / 24.0
        u1_l = (entropy_ext[idx_ext] - entropy_ext[idx_ext - 2]) / 2.0
        u2_l = (entropy_ext[idx_ext - 2] - 2 * entropy_ext[idx_ext - 1] + entropy_ext[idx_ext]) / 2.0

        u0_c = (entropy_ext[idx_ext - 1] + 22 * entropy_ext[idx_ext] + entropy_ext[idx_ext + 1]) / 24.0
        u1_c = (entropy_ext[idx_ext + 1] - entropy_ext[idx_ext - 1]) / 2.0
        u2_c = (entropy_ext[idx_ext - 1] - 2 * entropy_ext[idx_ext] + entropy_ext[idx_ext + 1]) / 2.0

        u0_r = (entropy_ext[idx_ext] + 22 * entropy_ext[idx_ext + 1] + entropy_ext[idx_ext + 2]) / 24.0
        u1_r = (entropy_ext[idx_ext + 2] - entropy_ext[idx_ext]) / 2.0
        u2_r = (entropy_ext[idx_ext] - 2 * entropy_ext[idx_ext + 1] + entropy_ext[idx_ext + 2]) / 2.0

        edge_R_of_L = u0_l + 0.5 * u1_l + (1.0 / 6.0) * u2_l
        edge_L_of_C = u0_c - 0.5 * u1_c + (1.0 / 6.0) * u2_c

        edge_R_of_C = u0_c + 0.5 * u1_c + (1.0 / 6.0) * u2_c
        edge_L_of_R = u0_r - 0.5 * u1_r + (1.0 / 6.0) * u2_r

        # 特征跳跃量计算
        delta_left = np.abs(edge_L_of_C - edge_R_of_L)
        delta_right = np.abs(edge_L_of_R - edge_R_of_C)
        max_jump = np.max([delta_left, delta_right])

        # 严格执行您的分母标准化因子逻辑 (dx ** 2.5) 与 1e-10 保护
        denominator = (dx ** 2.5) * (np.abs(entropy_ext[idx_ext]) + 1e-10)
        kappa_val = max_jump / denominator

        if kappa_val > threshold:
            is_troubled_full[i] = True

    return is_troubled_full[1:N + 1]


def main():
    nx_list = [100, 200, 400]
    # 3x3 矩阵子图学术标签规范分配
    sub_labels = [
        ['(a)', '(b)', '(c)'],  # Row 0: Sedov
        ['(d)', '(e)', '(f)'],  # Row 1: Double Blast
        ['(g)', '(h)', '(i)']  # Row 2: Shu-Osher
    ]
    gamma = 1.4
    KXRCF_THRESHOLD = 1.0  # 完全对齐您指定的阈值参数
    nghost = 3

    # --- 锁死加载三组高分辨率参考解数据 ---
    try:
        ref_sedov = np.load('Sedov’sblastwaveproblem/Sedov’s blast  WaveProblem_WENO5_N4000_T0.0010.npz')
        ref_double = np.load('DoubleBlastWaveinteraction/DoubleBlastWaveInteractionProblem_WENO5_N4000_T0.04.npz',
                             allow_pickle=True)
        ref_shu = np.load('Shu_OsherProblem/Shu_OsherProblem_WENO5_N2000_T1.80.npz')
        print("✅ 成功加载所有经典算例的参考解数据\n")
    except FileNotFoundError as e:
        print(f"❌ 错误: 核心参考解数据缺失 ({e})")
        return

    # 创建标准 3x3 学术大图画布
    fig, axes = plt.subplots(3, 3, figsize=(20, 18))
    legend_handles = []

    print("=================== ⏳ 开始统计 WENO5-H-KXRCF 间断点 ⏳ ===================")

    # ==========================================
    # ROW 0: Sedov Problem (输入特征：熵 + 反射边界条件)
    # ==========================================
    print("\n📌 [算例 1: Sedov Blast Wave 问题]")
    for idx, Nx in enumerate(nx_list):
        ax = axes[0, idx]
        # 🟢 修正：完美对齐 KXRCF 求解器输出的真实数值解文件名
        kxrcf_file = f"Sedov’sblastwaveproblem/SedovProblem_WENO5KXRCF_Dynamic_N{Nx}_T0.0010.csv"
        x_kx, rho_kx, p_kx = load_euler_csv_data_generic(kxrcf_file)

        if x_kx is not None:
            dx = float(x_kx[1] - x_kx[0])
            entropy_physical = p_kx / np.maximum(rho_kx ** gamma, 1e-12)

            # 🟢 注入反射边界条件外推拓扑
            entropy_with_bc = apply_reflective_bc_scalar(entropy_physical, nghost=nghost)

            # 🟢 完美编入您定制的 KXRCF 重构与特征过滤机制
            is_troubled_physical = run_kxrcf_core_logic(entropy_with_bc, dx, Nx, KXRCF_THRESHOLD, nghost)

            # 🛠️ 坏点统计打印
            total_points = len(x_kx)
            num_troubled = np.sum(is_troubled_physical)
            percentage_troubled = (num_troubled / total_points) * 100
            print(
                f"   -> 网格 N = {Nx:3d} | KXRCF 探测数: {num_troubled:3d} / {total_points:3d} | 占比: {percentage_troubled:6.2f}%")

            line1, = ax.plot(ref_sedov['x'], ref_sedov['rho'], color='black', linewidth=2.5, zorder=1)
            line2, = ax.plot(x_kx, rho_kx, color='blue', linewidth=2.0, zorder=2)  # 换成KXRCF标准蓝色实线

            for i in range(len(x_kx)):
                if is_troubled_physical[i]:
                    ax.axvline(x=x_kx[i], color='fuchsia', linestyle='-', linewidth=0.9, alpha=0.8, zorder=3)

            if idx == 0 and len(legend_handles) == 0:
                legend_handles = [line1, line2]
        else:
            ax.text(0.5, 0.5, f'Data Missing\nN = {Nx}', ha='center', va='center', fontsize=16)

        ax.set_xlabel(f'X\n{sub_labels[0][idx]}Sedov blast (N = {Nx})', fontsize=30, labelpad=3)
        if idx == 0:
            ax.set_ylabel('Density', fontsize=30, labelpad=5)
            ax.set_yticks([0.0, 3.0, 6.0])
            ax.tick_params(axis='both', labelsize=28, direction='in', top=True, right=True, length=6, width=1.2)
        else:
            ax.set_yticks([])
            ax.tick_params(axis='x', labelsize=28, direction='in', top=True, right=True, length=6, width=1.2)
            ax.tick_params(axis='y', direction='in', left=True, right=True, length=6, width=1.2)
        ax.set_xlim(-2.0, 2.0)
        ax.set_xticks([-2.0, 0, 2.0])
        ax.set_ylim(0.0, 6.5)

    # ==========================================
    # ROW 1: Double Blast Wave Problem (输入特征：熵 + 反射边界条件)
    # ==========================================
    print("\n📌 [算例 2: Double Blast Wave 问题]")
    for idx, Nx in enumerate(nx_list):
        ax = axes[1, idx]
        # 🟢 修正：完美对齐 KXRCF 求解器输出的真实数值解文件名
        kxrcf_file = f"DoubleBlastWaveinteraction/DoubleBlastWave_WENO5KXRCF_Dynamic_N{Nx}_T0.038.csv"
        x_kx, rho_kx, p_kx = load_euler_csv_data_generic(kxrcf_file)

        if x_kx is not None:
            dx = float(x_kx[1] - x_kx[0])
            entropy_physical = p_kx / np.maximum(rho_kx ** gamma, 1e-12)

            # 🟢 注入反射边界条件外推拓扑
            entropy_with_bc = apply_reflective_bc_scalar(entropy_physical, nghost=nghost)

            # 🟢 完美编入您定制的 KXRCF 重构与特征过滤机制
            is_troubled_physical = run_kxrcf_core_logic(entropy_with_bc, dx, Nx, KXRCF_THRESHOLD, nghost)

            # 🛠️ 坏点统计打印
            total_points = len(x_kx)
            num_troubled = np.sum(is_troubled_physical)
            percentage_troubled = (num_troubled / total_points) * 100
            print(
                f"   -> 网格 N = {Nx:3d} | KXRCF 探测数: {num_troubled:3d} / {total_points:3d} | 占比: {percentage_troubled:6.2f}%")

            ax.plot(ref_double['x'], ref_double['rho'], color='black', linewidth=2.5, zorder=1)
            ax.plot(x_kx, rho_kx, color='blue', linewidth=2.0, zorder=2)

            for i in range(len(x_kx)):
                if is_troubled_physical[i]:
                    ax.axvline(x=x_kx[i], color='fuchsia', linestyle='-', linewidth=0.5, alpha=0.8, zorder=3)
        else:
            ax.text(0.5, 3.2, f'Data Missing\nN = {Nx}', ha='center', va='center', fontsize=16, color='red')

        ax.set_xlabel(f'X\n{sub_labels[1][idx]}Double blast (N = {Nx})', fontsize=30, labelpad=3)
        if idx == 0:
            ax.set_ylabel('Density', fontsize=30, labelpad=5)
            ax.set_yticks([0.0, 3.0, 6.0])
            ax.tick_params(axis='both', labelsize=28, direction='in', top=True, right=True, length=6, width=1.2, pad=12)
        else:
            ax.set_yticks([])
            ax.tick_params(axis='x', labelsize=28, direction='in', top=True, right=True, length=6, width=1.2, pad=12)
            ax.tick_params(axis='y', direction='in', left=True, right=True, length=6, width=1.2)
        ax.set_xlim(0.0, 1.0)
        ax.set_xticks([0.0, 0.5, 1.0])
        ax.set_ylim(0.0, 6.5)

    # ==========================================
    # ROW 2: Shu-Osher Problem (输入特征：熵 + 独立流入/流出边界条件)
    # ==========================================
    print("\n📌 [算例 3: Shu-Osher 问题]")
    for idx, Nx in enumerate(nx_list):
        ax = axes[2, idx]
        # 🟢 修正：完美对齐 KXRCF 求解器输出的真实数值解文件名
        kxrcf_file = f"Shu_OsherProblem/Shu_OsherProblem_WENO5KXRCF_N{Nx}_T1.80.csv"
        x_kx, rho_kx, p_kx = load_euler_csv_data_generic(kxrcf_file)

        if x_kx is not None:
            dx = float(x_kx[1] - x_kx[0])
            entropy_physical = p_kx / np.maximum(rho_kx ** gamma, 1e-12)

            # 🟢 严格注入 Shu-Osher 定制边界条件拓扑（左流入右流出）
            entropy_with_bc = apply_shu_osher_bc_scalar(entropy_physical, gamma=gamma, nghost=nghost)

            # 🟢 完美编入您定制的 KXRCF 重构与特征过滤机制
            is_troubled_physical = run_kxrcf_core_logic(entropy_with_bc, dx, Nx, KXRCF_THRESHOLD, nghost)

            # 🛠️ 坏点统计打印
            total_points = len(x_kx)
            num_troubled = np.sum(is_troubled_physical)
            percentage_troubled = (num_troubled / total_points) * 100
            print(
                f"   -> 网格 N = {Nx:3d} | KXRCF 探测数: {num_troubled:3d} / {total_points:3d} | 占比: {percentage_troubled:6.2f}%")

            ax.plot(ref_shu['x'], ref_shu['rho'], color='black', linewidth=2.5, zorder=1)
            ax.plot(x_kx, rho_kx, color='blue', linewidth=2.0, zorder=2)

            for i in range(len(x_kx)):
                if is_troubled_physical[i]:
                    ax.axvline(x=x_kx[i], color='fuchsia', linestyle='-', linewidth=0.8, alpha=0.8, zorder=3)
        else:
            ax.text(0.0, 2.5, f'Data Missing\nN = {Nx}', ha='center', va='center', fontsize=16, color='red')

        ax.set_xlabel(f'X\n{sub_labels[2][idx]}Shu-Osher (N = {Nx})', fontsize=30, labelpad=3)
        if idx == 0:
            ax.set_ylabel('Density', fontsize=30, labelpad=5)
            ax.set_yticks([1.0, 3.0, 5.0])
            ax.tick_params(axis='y', labelsize=28, direction='in', left=True, right=True, length=6, width=1.2, pad=8)
            ax.tick_params(axis='x', labelsize=28, direction='in', top=True, right=True, length=6, width=1.2, pad=14)
        else:
            ax.set_yticks([])
            ax.tick_params(axis='x', labelsize=28, direction='in', top=True, right=True, length=6, width=1.2, pad=14)
            ax.tick_params(axis='y', direction='in', left=True, right=True, length=6, width=1.2)
        ax.set_xlim(-5.0, 5.0)
        ax.set_xticks([-5.0, 0, 5.0])
        ax.set_ylim(0.5, 5.0)

    print("\n=============================================================================")

    # ==========================================
    # 顶层整体排版与全局图例对齐
    # ==========================================
    plt.tight_layout(rect=[0.14, 0, 1, 1])
    fig.legend(
        handles=legend_handles,
        labels=['Reference', 'KXRCF'],
        loc='center left',
        bbox_to_anchor=(0.005, 0.7),
        ncol=1,
        fontsize=20,
        handlelength=2.5,
        handletextpad=0.5,
        frameon=True,
        edgecolor='gray'
    )

    output_pdf = "1D_Euler_Another3_KXRCF.pdf"
    # plt.savefig(output_pdf, dpi=300)
    print(f"\n📊 融合您专有 KXRCF 数值解与指示器的 3x3 学术大图已导出至: {output_pdf}")
    plt.show()


if __name__ == "__main__":
    main()