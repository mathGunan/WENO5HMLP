import numpy as np

def apply_outflow_bc(U, nghost=3):
    n_vars, N = U.shape
    U_ext = np.zeros((n_vars, N + 2 * nghost))
    # 内部区
    U_ext[:, nghost:-nghost] = U

    # 左边界：零梯度
    U_ext[:, :nghost] = U[:, 0:1]  # 广播最左边的值

    # 右边界：零梯度
    U_ext[:, -nghost:] = U[:, -1:]  # 广播最右边的值

    return U_ext