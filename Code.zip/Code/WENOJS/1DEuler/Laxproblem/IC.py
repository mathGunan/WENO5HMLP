import numpy as np

#Lax problem，ok
def IC(x_center):
    n = len(x_center)
    U = np.zeros((3, n))
    gamma = 1.4

    # 左侧/右侧常数状态
    rho_L, u_L, p_L = 0.445, 0.698, 3.528
    rho_R, u_R, p_R = 0.500, 0.000, 0.571

    # 初始间断位置
    for i, x in enumerate(x_center):
        if x < 0.0:
            rho, u, p = rho_L, u_L, p_L
        else:
            rho, u, p = rho_R, u_R, p_R

        U[0, i] = rho
        U[1, i] = rho * u
        U[2, i] = p / (gamma - 1) + 0.5 * rho * u**2
    return U