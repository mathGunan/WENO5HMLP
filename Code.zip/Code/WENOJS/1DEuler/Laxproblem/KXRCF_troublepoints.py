import csv
import numpy as np
import matplotlib.pyplot as plt

# 严格引入您纯正的流出边界条件函数进行外推拓扑对齐
from BC import apply_outflow_bc

'''
Joint Post-process for Lax Problem: KXRCF Troubled-Point Detector (1x3 Canvas)
【多项式重构对齐】：完美仿照您的多项式系数 (u0, u1, u2) 界面跳跃计算机制，内部调用 apply_outflow_bc。
【物理状态量修正】：严格对齐您的规范，采用非线性标量熵 S = p / max(rho^gamma, 1e-12)，彻底拿掉对数计算。
【物理图层纯净】：Reference 黑色实线 + WENO5-KXRCF 蓝色空心圆点 + 间断检测荧光紫竖线。
【定义域/值域标尺】：空间定义域限定在 [-5.0, 5.0]，纵轴密度精准控制在 [0.2, 1.4]。
'''


def load_euler_csv_data(filename):
    """
    安全读取标准 CSV 数据，返回网格中心坐标 x、密度 rho 和压力 p
    """
    x_center = []
    rho_numerical = []
    p_numerical = []

    try:
        with open(filename, mode='r', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            for row in reader:
                x_center.append(float(row["x"]))

                # 提取密度场
                if "rho" in row:
                    rho_numerical.append(float(row["rho"]))

                # 提取压力场用于还原热力学熵进行判别
                if "p" in row:
                    p_numerical.append(float(row["p"]))
                else:
                    p_numerical.append(0.0)
    except FileNotFoundError:
        print(f"❌ 警告: 未找到文件 {filename}")
        return None, None, None

    return np.array(x_center), np.array(rho_numerical), np.array(p_numerical)


def detect_troubled_points_only_kxrcf(x_center, rho, p, gamma=1.4, threshold=1.0, nghost=3):
    """
    基于 KXRCF 熵物理量外推逻辑重构的问题点探测器（内部调用 apply_outflow_bc）
    """
    N = len(rho)
    dx = x_center[1] - x_center[0]

    # 🟢 【核心修正】：严格遵循您的规范，计算全流场的非线性标量熵 S = p / max(rho^gamma, 1e-12)
    entropy_physical = p / np.maximum(rho ** gamma, 1e-12)

    # 2. 将一维标量熵临时升维至二维 (1, N)，调用您纯正的流出边界条件
    entropy_2d = entropy_physical[np.newaxis, :]
    entropy_ext_2d = apply_outflow_bc(entropy_2d, nghost=nghost)
    entropy_ext = entropy_ext_2d[0, :]  # 外推完毕后，降回一维标量场用于后续计算

    # 3. 严格契合 N + 2 长度的求解器区域拓扑 (i=0 对应物理网格第0个界面的左侧，即物理第-1个网格)
    prob_length = N + 2
    is_troubled_full = np.zeros(prob_length, dtype=bool)

    # 4. 严格执行 KXRCF 多项式系数外推与绝对跳跃求最大值逻辑
    for i in range(prob_length):
        idx_ext = i + (nghost - 1)  # 智能索引映射转换

        # 提取非线性标量熵在当前网格周边的左、中、右二次多项式系数
        u0_l = (entropy_ext[idx_ext - 2] + 22 * entropy_ext[idx_ext - 1] + entropy_ext[idx_ext]) / 24.0
        u1_l = (entropy_ext[idx_ext] - entropy_ext[idx_ext - 2]) / 2.0
        u2_l = (entropy_ext[idx_ext - 2] - 2 * entropy_ext[idx_ext - 1] + entropy_ext[idx_ext]) / 2.0

        u0_c = (entropy_ext[idx_ext - 1] + 22 * entropy_ext[idx_ext] + entropy_ext[idx_ext + 1]) / 24.0
        u1_c = (entropy_ext[idx_ext + 1] - entropy_ext[idx_ext - 1]) / 2.0
        u2_c = (entropy_ext[idx_ext - 1] - 2 * entropy_ext[idx_ext] + entropy_ext[idx_ext + 1]) / 2.0

        u0_r = (entropy_ext[idx_ext] + 22 * entropy_ext[idx_ext + 1] + entropy_ext[idx_ext + 2]) / 24.0
        u1_r = (entropy_ext[idx_ext + 2] - entropy_ext[idx_ext]) / 2.0
        u2_r = (entropy_ext[idx_ext] - 2 * entropy_ext[idx_ext + 1] + entropy_ext[idx_ext + 2]) / 2.0

        # 计算外推至界面两侧边缘处的熵解
        edge_R_of_L = u0_l + 0.5 * u1_l + (1.0 / 6.0) * u2_l
        edge_L_of_C = u0_c - 0.5 * u1_c + (1.0 / 6.0) * u2_c

        edge_R_of_C = u0_c + 0.5 * u1_c + (1.0 / 6.0) * u2_c
        edge_L_of_R = u0_r - 0.5 * u1_r + (1.0 / 6.0) * u2_r

        # 提取交界面处绝对物理跳跃的最大值
        delta_left = np.abs(edge_L_of_C - edge_R_of_L)
        delta_right = np.abs(edge_L_of_R - edge_R_of_C)
        max_jump = np.max([delta_left, delta_right])

        # 严格文献定义分母：包含网格尺度、局部变量绝对值以及防零极小量
        denominator = (dx ** 2.5) * (np.abs(entropy_ext[idx_ext]) + 1e-10)
        kappa_val = max_jump / denominator

        # 当无量纲跳跃大于设定阈值时标记为间断问题点
        if kappa_val > threshold:
            is_troubled_full[i] = True

    # 5. 剥离两侧保护单元，精准截取物理核心网格内（1 到 N）的布尔序列
    is_troubled_physical = is_troubled_full[1:N + 1]

    return is_troubled_physical


def main():
    # 三种目标网格分辨率
    nx_list = [100, 200, 400]
    sub_labels = ['(a)', '(b)', '(c)']
    T_final = 1.30  # Lax 问题的最终终止时刻
    gamma = 1.4

    # 严格对齐您指示的 KXRCF 文献判别阈值
    KXRCF_THRESHOLD = 1.0

    # 从当前目录下加载标准一维 Lax 问题的 Riemann 精确参考解
    try:
        data_riemann = np.load('riemann_solution.npz')
        x_riemann = data_riemann['x']
        rho_riemann = data_riemann['rho']
        print("✅ 成功加载 Riemann 参考解数据 (riemann_solution.npz)")
    except FileNotFoundError:
        print("❌ 错误: 未能在当前目录找到参考解文件 'riemann_solution.npz'")
        return

    # 初始化 1x3 学术画布，控制高分辨率矢量输出
    fig, axes = plt.subplots(1, 3, figsize=(20, 7), dpi=300)

    legend_handles = []
    legend_labels = []

    # 循环控制绘制每一个子图
    for idx, Nx in enumerate(nx_list):
        ax = axes[idx]

        # 动态组装当前分辨率的数据文件名
        kxrcf_file = f"LaxProblem_WENO5KXRCF_N{Nx}_T{T_final:.2f}.csv"

        # 安全加载流场数据
        x_kx, rho_kx, p_kx = load_euler_csv_data(kxrcf_file)

        # 健壮性检查
        if x_kx is None:
            ax.text(0.0, 0.8, f'Data Missing\n{kxrcf_file}', ha='center', va='center', fontsize=14, color='red')
            continue

        # =========================================================================
        # 【故障点拓扑识别】：在最终时刻物理场上运行带有流出边界外推的 KXRCF 探测器
        # =========================================================================
        is_troubled = detect_troubled_points_only_kxrcf(
            x_center=x_kx, rho=rho_kx, p=p_kx, gamma=gamma, threshold=KXRCF_THRESHOLD, nghost=3
        )

        total_points = len(x_kx)
        troubled_count = np.sum(is_troubled)
        print(f"[分辨率 N = {Nx}] 基于非线性标量熵的 Lax 问题 KXRCF 探测完成！强间断点数量: {troubled_count}/{total_points}")

        # =========================================================================
        #   【纯净版学术绘图：仅包含 Reference 线 + KXRCF 数值点 + 荧光紫竖线】
        # =========================================================================
        # 1. 绘制高对比度黑色实线作为全局统一的精准 Riemann 精确参考解
        line1, = ax.plot(x_riemann, rho_riemann, color='black', linewidth=2.5, label='Reference')

        # 2. 绘制 KXRCF 数值解：蓝色实线
        line2, = ax.plot(x_kx, rho_kx, color='blue', linewidth=2.0, label='KXRCF')

        # 3. 核心物理标记：若被探测器抓出为 troubled point，则拉起高亮荧光紫竖线
        vline_handle = None
        for i in range(total_points):
            if is_troubled[i]:
                vline_handle = ax.axvline(x=x_kx[i], color='fuchsia', linestyle='-', linewidth=0.5, alpha=0.8)

        # 只在第一个子图中收集全局图例的句柄
        if idx == 0:
            legend_handles = [line1, line2]
            legend_labels = ['Reference', 'KXRCF']


        # 坐标轴标签美化（学术大字号，最简方式控制单个 \n 换行）
        ax.set_xlabel(f'X\n{sub_labels[idx]} N = {Nx}', fontsize=32, labelpad=3)

        if idx == 0:
            ax.set_ylabel('Density', fontsize=32, labelpad=5)  # 仅在最左侧图加 Y 轴标签

        # =========================================================================
        # 【轴系控制标尺】：完美契合一维 Lax 问题的物理空间定义域与纵轴密度范围
        # =========================================================================
        ax.set_xlim(-5.0, 5.0)
        ax.set_xticks([-5.0, 0.0, 5.0])

        if idx == 0:
            ax.set_ylim(0.2, 1.4)
            ax.set_yticks([0.4, 0.8, 1.2])
            ax.tick_params(axis='both', labelsize=24, direction='in', top=True, right=True, length=6, width=1.2)
        else:
            ax.set_ylim(0.2, 1.4)
            ax.set_yticks([])
            ax.tick_params(axis='x', labelsize=24, direction='in', top=True, right=True, length=6, width=1.2)
            ax.tick_params(axis='y', direction='in', left=True, right=True, length=6, width=1.2)

    # 极致学术紧凑性版面深度收缩
    plt.tight_layout(rect=[0.09, 0, 1, 1])

    # 全局外部大图例调节控制
    fig.legend(
        handles=legend_handles,
        labels=legend_labels,
        loc='center left',
        bbox_to_anchor=(0.001, 0.85),
        ncol=1,
        fontsize=15,
        markerscale=1.8,
        handlelength=2.0,
        handletextpad=0.5,
        frameon=True,
        edgecolor='gray'
    )

    # 保存为无损矢量 PDF
    output_pdf = "1D_Lax_KXRCF.pdf"
    plt.savefig(output_pdf, dpi=300)
    print(f"\n📊 完美的 1x3 Lax 问题 KXRCF 标量熵间断点对比图已成功保存至: {output_pdf}")
    plt.show()


if __name__ == "__main__":
    main()