import csv
import numpy as np
import matplotlib.pyplot as plt
import torch
import torch.nn as nn

# 完美对接您的专用函数模块，沿用全套已保存设置
from BC import *
from helperfunction import *

'''
Joint Post-process for Lax Problem: 1x3 子图联合绘制 (N = 100, 200, 400)
【物理图层纯净】：仅保留 Reference 实线（来自 riemann_solution.npz） + WENO5-H-MLP 数值散点 + 间断点竖线。
【核心逻辑反转】：模型输出 1 代表光滑（不画线），输出 <= P_threshold 时才判定为 Troubled Point 并绘制荧光紫竖线。
【坐标域控制】：完美契合 Lax 问题的时空尺度定义，范围限定在 [-5.0, 5.0] 之间。
'''


def load_euler_csv_data(filename):
    """
    安全读取标准 CSV 数据，返回网格中心坐标 x、密度 rho 和压力 p
    """
    x_center = []
    rho_numerical = []
    p_numerical = []

    try:
        with open(filename, mode='r', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            for row in reader:
                x_center.append(float(row["x"]))

                if "rho" in row:
                    rho_numerical.append(float(row["rho"]))

                if "p" in row:
                    p_numerical.append(float(row["p"]))
                else:
                    p_numerical.append(0.0)
    except FileNotFoundError:
        print(f"❌ 警告: 未找到文件 {filename}")
        return None, None, None

    return np.array(x_center), np.array(rho_numerical), np.array(p_numerical)


def main():
    # 三种目标网格分辨率
    nx_list = [100, 200, 400]
    sub_labels = ['(a)', '(b)', '(c)']
    T_final = 1.3000  # Lax 问题的最终终止时刻
    gamma = 1.4

    # 🟢 神经网络模型相关配置项（完美沿用您的所有设定）
    ckpt_path = "best_model.pth"
    P_threshold = 0.5  # 划分光滑与间断的临界阈值
    nghost = 3

    # 预先安全初始化并加载训练好的模型与设备选择流
    try:
        model, device = get_model(ckpt_path, device_str='auto')
        print(f"✅ 成功加载神经网络权重模型，当前计算设备：{device}")
    except FileNotFoundError:
        print(f"❌ 错误: 未能在路径找到模型文件 '{ckpt_path}'，请检查文件名与工作路径。")
        return

    # 🟢 【核心适配】：从当前工作目录下加载标准一维 Lax 问题的 Riemann 精确解
    try:
        data_riemann = np.load('riemann_solution.npz')
        x_riemann = data_riemann['x']
        rho_riemann = data_riemann['rho']
        print("✅ 成功加载 Riemann 参考解数据 (riemann_solution.npz)")
    except FileNotFoundError:
        print("❌ 错误: 未能在当前目录找到参考解文件 'riemann_solution.npz'")
        return

    fig, axes = plt.subplots(1, 3, figsize=(20, 7), dpi=300)

    legend_handles = []
    legend_labels = []

    # 循环控制绘制每一个子图
    for idx, Nx in enumerate(nx_list):
        ax = axes[idx]

        # 动态组装当前 Lax 问题分辨率对应的数值解数据文件名 (严格保持文件名格式化规范)
        mlp_file = f"LaxProblem_WENO5MLP_N{Nx}_T{T_final:.2f}.csv"

        # 安全加载底层流场数据
        x_mlp, rho_mlp, p_mlp = load_euler_csv_data(mlp_file)

        # 健壮性检查
        if x_mlp is None:
            ax.text(0.0, 0.5, f'Data Missing\nN = {Nx}', ha='center', va='center', fontsize=16)
            continue

        # =========================================================================
        # 【特征提取与推理】：在最终时刻 U 矩阵的基础上，构造单物理量输入（标量非线性物理熵）
        # =========================================================================
        dx = float(x_mlp[1] - x_mlp[0])

        # 严格根据规范，计算全流场的非线性标量熵 S = p / rho^gamma (加入 1e-12 截断项防止真空报错)
        entropy_physical = p_mlp / np.maximum(rho_mlp ** gamma, 1e-12)

        # 升维输入，调用您的流出边界外推机制完成拓扑对称外扩
        entropy_2d = entropy_physical[np.newaxis, :]
        entropy_ext_2d = apply_outflow_bc(entropy_2d, nghost=nghost)
        entropy_with_bc = entropy_ext_2d[0, :]  # 压缩降维获取带有 ghost 单元的全场熵

        # 喂给您的 MLP 探测器进行五点模板光滑指标计算及推理预测，返回 prob_1d 形状为 (N+2,)
        prob_1d = predict(entropy_with_bc, dx, model, device)

        # 🟢【硬核反转逻辑】：输出趋于 1 是光滑，因此预测概率 <= 阈值 P 时才是 Troubled Point 间断点
        is_troubled_full = prob_1d <= P_threshold

        # 剥离掉两侧对应的保护映射区间，精准匹配核心物理网格（从 1 到 N）上的布尔判定序列
        is_troubled_physical = is_troubled_full[1:Nx + 1]

        total_points = len(x_mlp)
        troubled_count = np.sum(is_troubled_physical)
        print(f"[分辨率 N = {Nx}] Lax 问题 WENO5-H-MLP 探测完成！间断点数量: {troubled_count}/{total_points}")

        # =========================================================================
        #    【纯净版学术绘图：仅包含 Reference 线 + WENO5-H-MLP 数值点 + 荧光紫竖线】
        # =========================================================================
        # 1. 绘制高对比度黑色实线作为全局统一的精准 Riemann 精确参考解
        line1, = ax.plot(x_riemann, rho_riemann, color='black', linewidth=2.5, label='Reference')

        # 2. 绘制 WENO5-H-MLP 数值解：红色实线
        line2, = ax.plot(x_mlp, rho_mlp, color='red', linewidth=2.0, label='WENO5-H-MLP')

        # 3. 核心物理标记：仅在判定为非光滑的强间断点处拉起高亮荧光紫竖线
        vline_handle = None
        for i in range(total_points):
            if is_troubled_physical[i]:
                vline_handle = ax.axvline(x=x_mlp[i], color='fuchsia', linestyle='-', linewidth=0.5, alpha=0.8)

        # 仅在最左侧第一个子图中抓取全局图例句柄，防止文字条目密集堆叠
        if idx == 0:
            legend_handles = [line1, line2]
            legend_labels = ['Reference', 'WENO5-H-MLP']


        # 坐标轴标签美化（最简方式控制单换行符，学术大字号）
        ax.set_xlabel(f'X\n{sub_labels[idx]} N = {Nx}', fontsize=32, labelpad=3)

        if idx == 0:
            ax.set_ylabel('Density', fontsize=32, labelpad=5)  # 仅在第一张图左侧绘制 Y 轴物理量标签

        # =========================================================================
        # 【轴系控制标尺】：完美契合一维 Lax 问题的定义域与纵轴密度范围
        # =========================================================================
        ax.set_xlim(-5.0, 5.0)
        ax.set_xticks([-5.0, 0.0, 5.0])

        if idx == 0:
            # 左侧轴展示大字号纵轴标尺（根据 Lax 密度的物理演化范围自适应，一般在 0.2 到 1.4 左右）
            ax.set_ylim(0.2, 1.4)
            ax.set_yticks([0.4, 0.8, 1.2])
            ax.tick_params(axis='both', labelsize=24, direction='in', top=True, right=True, length=6, width=1.2)
        else:
            # 隐藏右侧两子图纵向刻度标签，维持学术大图的横向整体连续性
            ax.set_ylim(0.2, 1.4)
            ax.set_yticks([])
            ax.tick_params(axis='x', labelsize=24, direction='in', top=True, right=True, length=6, width=1.2)
            ax.tick_params(axis='y', direction='in', left=True, right=True, length=6, width=1.2)

    # 极致学术紧凑性版面深度收缩
    plt.tight_layout(rect=[0.09, 0, 1, 1])

    # =========================================================================
    # 【全局外部大图例】：垂直堆叠均匀挂靠在整张 1x3 大图的最左侧外边缘
    # =========================================================================
    fig.legend(
        handles=legend_handles,
        labels=legend_labels,
        loc='center left',
        bbox_to_anchor=(0.001, 0.85),
        ncol=1,
        fontsize=15,
        markerscale=1.8,
        handlelength=2.0,
        handletextpad=0.5,
        frameon=True,
        edgecolor='gray'
    )

    # 保存为无损的矢量 PDF 文件，方便随时插入到 LaTeX 论文手稿中
    output_pdf = "1D_Lax_MLP.pdf"
    plt.savefig(output_pdf, dpi=300)
    print(f"\n📊 完美的 1x3 尺度不变 Lax 问题密度与神经网络间断检测对比图已保存至: {output_pdf}")
    plt.show()


if __name__ == "__main__":
    main()