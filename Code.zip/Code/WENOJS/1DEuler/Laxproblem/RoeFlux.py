from helperfunction import *

def compute_rhs_1d(U_ext, dx, gamma, nghost=3, epsilon=1e-6):
    """
    修正版本：特征空间 WENO5 有限差分格式
    """
    n_vars, N_ext = U_ext.shape
    N = N_ext - 2 * nghost

    # ========== 中心点上的基本物理量 ==========
    rho = U_ext[0, :]#密度
    u = U_ext[1, :] / rho#速度
    E = U_ext[2, :]#能量
    p = (gamma - 1.0) * (E - 0.5 * rho * u ** 2)#压力
    H = (E + p) / rho#总焓
    a = np.sqrt(np.maximum(gamma * p / rho, 1e-14))#声速计算

    # ========== 计算中心点上的物理通量 ==========
    F = np.zeros_like(U_ext)
    F[0, :] = rho * u
    F[1, :] = rho * u ** 2 + p
    F[2, :] = u * (E + p)

    # 初始化界面通量
    F_hat = np.zeros((3, N + 1))

    # ========== 对每个界面 i+1/2 进行处理，从最左边的端点一直到最右边的端点，一次处理一个端点的左右重构值 ==========
    for i_face in range(N + 1):  # i_face 对应界面索引，0，1，2，3...N+1
        i_center = i_face + nghost  # 对应的真实物理中心网格索引

        # --- 更鲁棒的 Roe 平均 ---
        iL, iR = i_center - 1, i_center  # 界面左右的两个网格

        rhoL, rhoR = rho[iL], rho[iR]
        uL, uR = u[iL], u[iR]
        HL, HR = H[iL], H[iR]

        # 避免除零
        if rhoL <= 0 or rhoR <= 0:
            # 退化到简单平均
            u_t = 0.5 * (uL + uR)
            H_t = 0.5 * (HL + HR)
            a_t = 0.5 * (a[iL] + a[iR])
        else:
            rtL, rtR = np.sqrt(rhoL), np.sqrt(rhoR)
            u_t = (rtL * uL + rtR * uR) / (rtL + rtR)
            H_t = (rtL * HL + rtR * HR) / (rtL + rtR)
            a_t = np.sqrt(max((gamma - 1.0) * (H_t - 0.5 * u_t ** 2), 1e-14))

        # --- 特征矩阵 ---
        R = np.array([
            [1.0, 1.0, 1.0],
            [u_t - a_t, u_t, u_t + a_t],
            [H_t - u_t * a_t, 0.5 * u_t ** 2, H_t + u_t * a_t]
        ])

        try:
            L = np.linalg.inv(R)
        except:
            # 特征矩阵奇异时的备选方案
            L = np.eye(3)
            R = np.eye(3)


        # --- 提取6点模板 [i-3, i-2, i-1, i, i+1, i+2] ---
        stencil = slice(i_center - 3, i_center + 3)  # 6个点！
        U_stencil = U_ext[:, stencil]  # (3, 6)
        F_stencil = F[:, stencil]  # (3, 6)

        # --- 投影到特征空间 ---
        W_stencil = L @ U_stencil  # (3, 6)
        G_stencil = L @ F_stencil  # (3, 6)

        # --- 特征速度 ---
        lam = np.array([u_t - a_t, u_t, u_t + a_t])
        alpha = np.max(np.abs(lam))  # 全局LF分裂参数

        # --- 特征空间通量分裂 ---
        G_plus = 0.5 * (G_stencil + alpha * W_stencil)#只要这部分的左重构值
        G_minus = 0.5 * (G_stencil - alpha * W_stencil)#只要这部分的右重构值

        # --- WENO5 重构 ---
        Gp_iL = np.zeros(3)  # 正通量在界面左侧的值
        Gm_iR = np.zeros(3)  # 负通量在界面右侧的值

        for k in range(3):
            # 正通量：左偏模板 [i-3, i-2, i-1, i, i+1, i+2]
            g = G_plus[k, :]  # 6个点: v0,v1,v2,v3,v4,v5
            v0, v1, v2, v3, v4, v5 = g

            # 三个子模板重构
            p1 = (2 * v0 - 7 * v1 + 11 * v2) / 6.0#左偏两个
            p2 = (-v1 + 5 * v2 + 2 * v3) / 6.0#左偏一个
            p3 = (2 * v2 + 5 * v3 - v4) / 6.0#左偏0个

            # 光滑指示器
            beta1 = (13 / 12) * (v0 - 2 * v1 + v2) ** 2 + (1 / 4) * (v0 - 4 * v1 + 3 * v2) ** 2
            beta2 = (13 / 12) * (v1 - 2 * v2 + v3) ** 2 + (1 / 4) * (v1 - v3) ** 2
            beta3 = (13 / 12) * (v2 - 2 * v3 + v4) ** 2 + (1 / 4) * (3 * v2 - 4 * v3 + v4) ** 2

            # 非线性权重
            alpha1 = 0.1 / (epsilon + beta1) ** 2
            alpha2 = 0.6 / (epsilon + beta2) ** 2
            alpha3 = 0.3 / (epsilon + beta3) ** 2
            w_sum = alpha1 + alpha2 + alpha3
            w1, w2, w3 = alpha1 / w_sum, alpha2 / w_sum, alpha3 / w_sum

            Gp_iL[k] = w1 * p1 + w2 * p2 + w3 * p3#G_plus的左重构值


            # 负通量：右偏模板 [i+2, i+1, i, i-1, i-2, i-3]
            g = G_minus[k, ::-1]  # 反转：v5,v4,v3,v2,v1,v0
            v0, v1, v2, v3, v4, v5 = g

            p1 = (2 * v0 - 7 * v1 + 11 * v2) / 6.0
            p2 = (-v1 + 5 * v2 + 2 * v3) / 6.0
            p3 = (2 * v2 + 5 * v3 - v4) / 6.0

            beta1 = (13 / 12) * (v0 - 2 * v1 + v2) ** 2 + (1 / 4) * (v0 - 4 * v1 + 3 * v2) ** 2
            beta2 = (13 / 12) * (v1 - 2 * v2 + v3) ** 2 + (1 / 4) * (v1 - v3) ** 2
            beta3 = (13 / 12) * (v2 - 2 * v3 + v4) ** 2 + (1 / 4) * (3 * v2 - 4 * v3 + v4) ** 2

            alpha1 = 0.1 / (epsilon + beta1) ** 2
            alpha2 = 0.6 / (epsilon + beta2) ** 2
            alpha3 = 0.3 / (epsilon + beta3) ** 2
            w_sum = alpha1 + alpha2 + alpha3
            w1, w2, w3 = alpha1 / w_sum, alpha2 / w_sum, alpha3 / w_sum

            Gm_iR[k] = w1 * p1 + w2 * p2 + w3 * p3#只要右重构值

        # --- 回投影到物理空间 ---
        F_hat[:, i_face] = R @ (Gp_iL + Gm_iR)

    # ========== 计算 RHS ==========
    rhs = -(F_hat[:, 1:] - F_hat[:, :-1]) / dx
    return rhs

def compute_rhs_1d_with_MLP(U_ext, dx, model, device, gamma, P=0.5, nghost=3, epsilon=1e-6):
    """
    一维 Euler 空间右端项 (RHS) 计算函数。
    【特征对齐修改】：将 MLP 探测器的输入由“3通道通量 F”彻底切换为文献标准的“单通道标量物理熵 S”，
    网络仅需输出一维判定概率 prob_1d，统一控制特征空间 3 个分量的混合重构行为。
    """
    n_vars, N_ext = U_ext.shape
    N = N_ext - 2 * nghost

    # ========== 中心点物理量 ==========
    rho = U_ext[0, :]
    u = U_ext[1, :] / rho
    E = U_ext[2, :]
    p = (gamma - 1.0) * (E - 0.5 * rho * u**2)
    H = (E + p) / rho
    a = np.sqrt(np.maximum(gamma * p / rho, 1e-14))

    # ========== 中心点物理通量 ==========
    F = np.zeros_like(U_ext)
    F[0, :] = rho * u
    F[1, :] = rho * u**2 + p
    F[2, :] = u * (E + p)

    # ========== 【核心修改】：构造单物理量输入（标量物理熵） ==========
    # 严格根据规范，计算全流场的非线性标量熵 S = p / rho^gamma
    entropy = p / np.maximum(rho**gamma, 1e-12)

    # 喂给 MLP 探测器（假设你的 predict 函数内部已修改为接收单通道的标量场 entropy）
    # 返回的 prob_1d 的 shape 应为 (N+2,)
    prob_1d = predict(entropy, dx, model, device)
    prob_1d = (prob_1d > P).astype(np.float32)  # 后处理二值化阈值判定

    # ========== 初始化界面通量 ==========
    F_hat = np.zeros((3, N+1))

    # ========== 对每个物理界面 i+1/2 处理，共 N+1 个 ==========
    for i_face in range(N + 1):
        i_center = i_face + nghost
        iL, iR = i_center - 1, i_center  # 界面左、右两侧的中心点索引

        rhoL, rhoR = rho[iL], rho[iR]
        uL, uR = u[iL], u[iR]
        HL, HR = H[iL], H[iR]

        # Roe 平均
        if rhoL <= 0 or rhoR <= 0:
            u_t = 0.5 * (uL + uR)
            H_t = 0.5 * (HL + HR)
            a_t = 0.5 * (a[iL] + a[iR])
        else:
            rtL, rtR = np.sqrt(rhoL), np.sqrt(rhoR)
            u_t = (rtL * uL + rtR * uR) / (rtL + rtR)
            H_t = (rtL * HL + rtR * HR) / (rtL + rtR)
            a_t = np.sqrt(max((gamma - 1) * (H_t - 0.5 * u_t ** 2), 1e-14))

        # 特征矩阵构造与求逆
        R = np.array([
            [1.0, 1.0, 1.0],
            [u_t - a_t, u_t, u_t + a_t],
            [H_t - u_t * a_t, 0.5 * u_t ** 2, H_t + u_t * a_t]
        ])
        try:
            L_mat = np.linalg.inv(R)
        except:
            R = np.eye(3)
            L_mat = np.eye(3)

        # 提取 6 点模板
        stencil = slice(i_center - 3, i_center + 3)
        U_stencil = U_ext[:, stencil]
        F_stencil = F[:, stencil]

        # 投影到特征空间
        W_stencil = L_mat @ U_stencil
        G_stencil = L_mat @ F_stencil

        # 特征速度及 Lax-Friedrichs 通量分裂
        lam = np.array([u_t - a_t, u_t, u_t + a_t])
        alpha_val = np.max(np.abs(lam))

        G_plus = 0.5 * (G_stencil + alpha_val * W_stencil)
        G_minus = 0.5 * (G_stencil - alpha_val * W_stencil)

        # 混合重构临时容器
        Gp_iL = np.zeros(3)
        Gm_iR = np.zeros(3)

        # 遍历 3 个控制方程通道进行重构
        for k in range(3):

            # --- 左重构：【核心修改点】直接读取单通道一维判定结果 ---
            if prob_1d[i_face]:  # 线性高阶
                g = G_plus[k, :]
                Gp_iL[k] = (2 * g[0] - 13 * g[1] + 47 * g[2] + 27 * g[3] - 3 * g[4]) / 60.0
            else:  # WENO5
                g = G_plus[k, :]
                v0, v1, v2, v3, v4, v5 = g
                p1 = (2 * v0 - 7 * v1 + 11 * v2) / 6
                p2 = (-v1 + 5 * v2 + 2 * v3) / 6
                p3 = (2 * v2 + 5 * v3 - v4) / 6
                beta1 = (13 / 12) * (v0 - 2 * v1 + v2) ** 2 + (1 / 4) * (v0 - 4 * v1 + 3 * v2) ** 2
                beta2 = (13 / 12) * (v1 - 2 * v2 + v3) ** 2 + (1 / 4) * (v1 - v3) ** 2
                beta3 = (13 / 12) * (v2 - 2 * v3 + v4) ** 2 + (1 / 4) * (3 * v2 - 4 * v3 + v4) ** 2
                alpha1 = 0.1 / (epsilon + beta1) ** 2
                alpha2 = 0.6 / (epsilon + beta2) ** 2
                alpha3 = 0.3 / (epsilon + beta3) ** 2
                wsum = alpha1 + alpha2 + alpha3
                w1, w2, w3 = alpha1 / wsum, alpha2 / wsum, alpha3 / wsum
                Gp_iL[k] = w1 * p1 + w2 * p2 + w3 * p3

            # --- 右重构：【核心修改点】直接读取单通道一维判定结果 ---
            if prob_1d[i_face + 1]:  # 线性高阶
                g = G_minus[k, :]
                Gm_iR[k] = (-3 * g[1] + 27 * g[2] + 47 * g[3] - 13 * g[4] + 2 * g[5]) / 60.0
            else:  # WENO5
                g = G_minus[k, :]
                v0, v1, v2, v3, v4, v5 = g
                p1 = (-1 * v1 + 5 * v2 + 2 * v3) / 6
                p2 = (2 * v2 + 5 * v3 - v4) / 6
                p3 = (11 * v3 - 7 * v4 + 2 * v5) / 6
                beta1 = (13 / 12) * (v1 - 2 * v2 + v3) ** 2 + (1 / 4) * (v1 - 4 * v2 + 3 * v3) ** 2
                beta2 = (13 / 12) * (v2 - 2 * v3 + v4) ** 2 + (1 / 4) * (v2 - v4) ** 2
                beta3 = (13 / 12) * (v3 - 2 * v4 + v5) ** 2 + (1 / 4) * (3 * v3 - 4 * v4 + v5) ** 2
                alpha1 = 0.3 / (epsilon + beta1) ** 2
                alpha2 = 0.6 / (epsilon + beta2) ** 2
                alpha3 = 0.1 / (epsilon + beta3) ** 2
                wsum = alpha1 + alpha2 + alpha3
                w1, w2, w3 = alpha1 / wsum, alpha2 / wsum, alpha3 / wsum
                Gm_iR[k] = w1 * p1 + w2 * p2 + w3 * p3

        # 回投影到物理空间
        F_hat[:, i_face] = R @ (Gp_iL + Gm_iR)

    # ========== 计算 RHS ==========
    rhs = -(F_hat[:, 1:] - F_hat[:, :-1]) / dx
    return rhs



def compute_rhs_1d_with_KXRCF(U_ext, dx, gamma, threshold=1.0, nghost=3, epsilon=1e-6):
    """
    一维 Euler 空间右端项 (RHS) 计算函数。
    【严格文献物理对齐】：锁死 threshold=1.0，完全遵循 Li & Qiu (2010) 规范。
    基于唯一的物理标量熵统一判定，彻底废除多余的 3 行重复矩阵，且不添加任何非文献平滑项。
    """
    n_vars, N_ext = U_ext.shape
    N = N_ext - 2 * nghost

    # ========== 中心点物理量 ==========
    rho = U_ext[0, :]
    u = U_ext[1, :] / rho
    E = U_ext[2, :]
    p = (gamma - 1.0) * (E - 0.5 * rho * u ** 2)
    H = (E + p) / rho
    a = np.sqrt(np.maximum(gamma * p / rho, 1e-14))

    # ========== 中心点物理通量 ==========
    F = np.zeros_like(U_ext)
    F[0, :] = rho * u  # 分量 0: 质量通量
    F[1, :] = rho * u ** 2 + p  # 分量 1: 动量通量
    F[2, :] = u * (E + p)  # 分量 2: 能量通量

    # ========== 【文献物理对齐】：计算全流场统一的标量物理熵 ==========
    entropy = p / np.maximum(rho ** gamma, 1e-12)

    # 直接使用一维数组统一控制三个守恒通道
    prob_length = N + 2
    prob_1d = np.zeros(prob_length, dtype=np.float32)

    for i in range(prob_length):
        idx_ext = i + (nghost - 1)  # 智能索引映射转换

        # 提取标量熵在当前网格周边的左、中、右二次多项式系数
        u0_l = (entropy[idx_ext - 2] + 22 * entropy[idx_ext - 1] + entropy[idx_ext]) / 24.0
        u1_l = (entropy[idx_ext] - entropy[idx_ext - 2]) / 2.0
        u2_l = (entropy[idx_ext - 2] - 2 * entropy[idx_ext - 1] + entropy[idx_ext]) / 2.0

        u0_c = (entropy[idx_ext - 1] + 22 * entropy[idx_ext] + entropy[idx_ext + 1]) / 24.0
        u1_c = (entropy[idx_ext + 1] - entropy[idx_ext - 1]) / 2.0
        u2_c = (entropy[idx_ext - 1] - 2 * entropy[idx_ext] + entropy[idx_ext + 1]) / 2.0

        u0_r = (entropy[idx_ext] + 22 * entropy[idx_ext + 1] + entropy[idx_ext + 2]) / 24.0
        u1_r = (entropy[idx_ext + 2] - entropy[idx_ext]) / 2.0
        u2_r = (entropy[idx_ext] - 2 * entropy[idx_ext + 1] + entropy[idx_ext + 2]) / 2.0

        # 计算外推至界面两侧边缘处的熵解
        edge_R_of_L = u0_l + 0.5 * u1_l + (1.0 / 6.0) * u2_l
        edge_L_of_C = u0_c - 0.5 * u1_c + (1.0 / 6.0) * u2_c

        edge_R_of_C = u0_c + 0.5 * u1_c + (1.0 / 6.0) * u2_c
        edge_L_of_R = u0_r - 0.5 * u1_r + (1.0 / 6.0) * u2_r

        # 提取交界面处绝对物理跳跃的最大值
        delta_left = np.abs(edge_L_of_C - edge_R_of_L)
        delta_right = np.abs(edge_L_of_R - edge_R_of_C)
        max_jump = np.max([delta_left, delta_right])

        # 严格文献定义分母：仅包含网格尺度、局部变量绝对值以及防零极小量
        denominator = (dx ** 2.5) * (np.abs(entropy[idx_ext]) + 1e-10)
        kappa_val = max_jump / denominator

        # 直接写入一维判定序列 (1.0 代表光滑区使用线性高阶，0.0 代表强间断使用 WENO5)
        prob_1d[i] = 1.0 if kappa_val <= threshold else 0.0

    # ========== 初始化界面数值通量 ==========
    F_hat = np.zeros((3, N + 1))

    # ========== 对每个物理界面 i+1/2 处理 ==========
    for i_face in range(N + 1):
        i_center = i_face + nghost
        iL, iR = i_center - 1, i_center

        rhoL, rhoR = rho[iL], rho[iR]
        uL, uR = u[iL], u[iR]
        HL, HR = H[iL], H[iR]

        if rhoL <= 0 or rhoR <= 0:
            u_t, H_t, a_t = 0.5 * (uL + uR), 0.5 * (HL + HR), 0.5 * (a[iL] + a[iR])
        else:
            rtL, rtR = np.sqrt(rhoL), np.sqrt(rhoR)
            u_t = (rtL * uL + rtR * uR) / (rtL + rtR)
            H_t = (rtL * HL + rtR * HR) / (rtL + rtR)
            a_t = np.sqrt(max((gamma - 1) * (H_t - 0.5 * u_t ** 2), 1e-14))

        R = np.array([
            [1.0, 1.0, 1.0],
            [u_t - a_t, u_t, u_t + a_t],
            [H_t - u_t * a_t, 0.5 * u_t ** 2, H_t + u_t * a_t]
        ])
        try:
            L_mat = np.linalg.inv(R)
        except:
            R, L_mat = np.eye(3), np.eye(3)

        stencil = slice(i_center - 3, i_center + 3)
        W_stencil = L_mat @ U_ext[:, stencil]
        G_stencil = L_mat @ F[:, stencil]

        lam = np.array([u_t - a_t, u_t, u_t + a_t])
        alpha_val = np.max(np.abs(lam))

        G_plus = 0.5 * (G_stencil + alpha_val * W_stencil)
        G_minus = 0.5 * (G_stencil - alpha_val * W_stencil)

        Gp_iL = np.zeros(3)
        Gm_iR = np.zeros(3)

        # 遍历 3 个控制方程通道进行重构
        for k in range(3):
            # --- 正通量左重构：直接读取统一的一维判定 ---
            if prob_1d[i_face]:  # 线性高阶
                g = G_plus[k, :]
                Gp_iL[k] = (2 * g[0] - 13 * g[1] + 47 * g[2] + 27 * g[3] - 3 * g[4]) / 60.0
            else:  # WENO5
                g = G_plus[k, :]
                v0, v1, v2, v3, v4, v5 = g
                p1 = (2 * v0 - 7 * v1 + 11 * v2) / 6
                p2 = (-v1 + 5 * v2 + 2 * v3) / 6
                p3 = (2 * v2 + 5 * v3 - v4) / 6
                beta1 = (13 / 12) * (v0 - 2 * v1 + v2) ** 2 + (1 / 4) * (v0 - 4 * v1 + 3 * v2) ** 2
                beta2 = (13 / 12) * (v1 - 2 * v2 + v3) ** 2 + (1 / 4) * (v1 - v3) ** 2
                beta3 = (13 / 12) * (v2 - 2 * v3 + v4) ** 2 + (1 / 4) * (3 * v2 - 4 * v3 + v4) ** 2
                alpha1 = 0.1 / (epsilon + beta1) ** 2
                alpha2 = 0.6 / (epsilon + beta2) ** 2
                alpha3 = 0.3 / (epsilon + beta3) ** 2
                wsum = alpha1 + alpha2 + alpha3
                w1, w2, w3 = alpha1 / wsum, alpha2 / wsum, alpha3 / wsum
                Gp_iL[k] = w1 * p1 + w2 * p2 + w3 * p3

            # --- 负通量右重构：直接读取统一的一维判定 ---
            if prob_1d[i_face + 1]:  # 线性高阶
                g = G_minus[k, :]
                Gm_iR[k] = (-3 * g[1] + 27 * g[2] + 47 * g[3] - 13 * g[4] + 2 * g[5]) / 60.0
            else:  # WENO5
                g = G_minus[k, :]
                v0, v1, v2, v3, v4, v5 = g
                p1 = (-1 * v1 + 5 * v2 + 2 * v3) / 6
                p2 = (2 * v2 + 5 * v3 - v4) / 6
                p3 = (11 * v3 - 7 * v4 + 2 * v5) / 6
                beta1 = (13 / 12) * (v1 - 2 * v2 + v3) ** 2 + (1 / 4) * (v1 - 4 * v2 + 3 * v3) ** 2
                beta2 = (13 / 12) * (v2 - 2 * v3 + v4) ** 2 + (1 / 4) * (v2 - v4) ** 2
                beta3 = (13 / 12) * (v3 - 2 * v4 + v5) ** 2 + (1 / 4) * (3 * v3 - 4 * v4 + v5) ** 2
                alpha1 = 0.3 / (epsilon + beta1) ** 2
                alpha2 = 0.6 / (epsilon + beta2) ** 2
                alpha3 = 0.1 / (epsilon + beta3) ** 2
                wsum = alpha1 + alpha2 + alpha3
                w1, w2, w3 = alpha1 / wsum, alpha2 / wsum, alpha3 / wsum
                Gm_iR[k] = w1 * p1 + w2 * p2 + w3 * p3

        F_hat[:, i_face] = R @ (Gp_iL + Gm_iR)

    return -(F_hat[:, 1:] - F_hat[:, :-1]) / dx




