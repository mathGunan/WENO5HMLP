import csv
import numpy as np
import matplotlib.pyplot as plt
import torch
import torch.nn as nn
from BC import *
from helperfunction import *

'''
Joint Post-process for Sedov Problem: MLP Troubled-Point Detector (1x3 Canvas)
【边界条件硬核对齐】：彻底舍弃流出边界，改用与求解器底层 100% 同构的标量镜像反射外推逻辑。
【文件名严格对齐】：采用小写 blastwave 的独特命名格式加载。
md【硬核反转逻辑】：预测概率 <= 阈值 P 时判定为 Troubled Point 间断点并绘制荧光紫竖线。
'''


def load_euler_csv_data(filename):
    """
    安全读取标准 CSV 数据，返回网格中心坐标 x、密度 rho 和压力 p
    """
    x_center = []
    rho_numerical = []
    p_numerical = []

    try:
        with open(filename, mode='r', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            for row in reader:
                x_center.append(float(row["x"]))
                if "rho" in row:
                    rho_numerical.append(float(row["rho"]))
                elif "Exact_solution_T" in row:
                    rho_numerical.append(float(row["Exact_solution_T"]))

                if "p" in row:
                    p_numerical.append(float(row["p"]))
                else:
                    p_numerical.append(0.0)
    except FileNotFoundError:
        print(f"❌ 警告: 未找到文件 {filename}")
        return None, None, None

    return np.array(x_center), np.array(rho_numerical), np.array(p_numerical)


def apply_reflective_bc_scalar(entropy_1d, nghost=3):
    """
    针对标量（非线性物理熵）的高精度反射边界条件。
    遵循您提供的物理规范：标量物理量在左右边界均表现为严格的镜像对称映射。
    """
    N = len(entropy_1d)
    ext_length = N + 2 * nghost
    entropy_ext = np.zeros(ext_length)

    # 填充物理内部区
    entropy_ext[nghost:-nghost] = entropy_1d

    # 左边界对称反射
    entropy_ext[:nghost] = entropy_1d[nghost - 1::-1]

    # 右边界对称反射
    entropy_ext[-nghost:] = entropy_1d[-1:-nghost - 1:-1]

    return entropy_ext


def main():
    nx_list = [100, 200, 400]
    sub_labels = ['(a)', '(b)', '(c)']
    T_final = 0.0010
    gamma = 1.4

    P_threshold = 0.5
    nghost = 3
    ckpt_path = "best_model.pth"

    try:
        model, device = get_model(ckpt_path, device_str='auto')
        print(f"✅ 成功加载神经网络权重模型，设备：{device}")
    except FileNotFoundError:
        print(f"❌ 错误: 未能在路径找到模型文件 '{ckpt_path}'")
        return

    try:
        data_riemann = np.load('Sedov’s blast  WaveProblem_WENO5_N4000_T0.0010.npz')
        x_riemann = data_riemann['x']
        rho_riemann = data_riemann['rho']
        print("✅ 成功加载 参考解数据")
    except FileNotFoundError:
        print("❌ 错误: 未能在当前目录找到参考解文件")
        return

    fig, axes = plt.subplots(1, 3, figsize=(20, 7))
    legend_handles = []
    legend_labels = []

    for idx, Nx in enumerate(nx_list):
        ax = axes[idx]
        mlp_file = f"Sedov_blastwaveProblem_WENO5MLP_N{Nx}_T{T_final:.4f}.csv"

        x_mlp, rho_mlp, p_mlp = load_euler_csv_data(mlp_file)
        if x_mlp is None:
            ax.text(0.5, 0.5, f'Data Missing\nN = {Nx}', ha='center', va='center', fontsize=16)
            continue

        dx = float(x_mlp[1] - x_mlp[0])
        entropy_physical = p_mlp / np.maximum(rho_mlp ** gamma, 1e-12)

        # 🟢 完美调用重构的反射边界机制，保证神经网络输入的特征面和求解器完全一致
        entropy_with_bc = apply_reflective_bc_scalar(entropy_physical, nghost=nghost)

        prob_1d = predict(entropy_with_bc, dx, model, device)
        is_troubled_full = prob_1d <= P_threshold
        is_troubled_physical = is_troubled_full[1:Nx + 1]

        total_points = len(x_mlp)
        print(f"[MLP N = {Nx}] 反射边界下捕捉的间断点数量: {np.sum(is_troubled_physical)}/{total_points}")

        # 1. 绘制高对比度黑色精确解参考实线
        line1, = ax.plot(x_riemann, rho_riemann, color='black', linewidth=2.5, label='Reference')

        # 2. 数值解采用红色连续实线绘制
        line2, = ax.plot(x_mlp, rho_mlp, color='red', linewidth=2.0, label='WENO5-H-MLP')

        # 3. 绘制高亮荧光紫竖线标记 (linewidth=0.9)
        for i in range(total_points):
            if is_troubled_physical[i]:
                ax.axvline(x=x_mlp[i], color='fuchsia', linestyle='-', linewidth=0.9, alpha=0.8)

        if idx == 0:
            legend_handles = [line1, line2]
            legend_labels = ['Reference', 'WENO5-H-MLP']

        ax.set_xlabel(f'X\n{sub_labels[idx]} N = {Nx}', fontsize=32, labelpad=3)
        if idx == 0:
            ax.set_ylabel('Density', fontsize=32, labelpad=5)

        ax.set_xlim(-2.0, 2.0)
        ax.set_xticks([-2.0, 0, 2.0])

        if idx == 0:
            ax.set_ylim(0.0, 6.5)
            ax.set_yticks([0.0, 3.0, 6.0])
            ax.tick_params(axis='both', labelsize=24, direction='in', top=True, right=True, length=6, width=1.2)
        else:
            ax.set_ylim(0.0, 6.5)
            ax.set_yticks([])
            ax.tick_params(axis='x', labelsize=24, direction='in', top=True, right=True, length=6, width=1.2)
            ax.tick_params(axis='y', direction='in', left=True, right=True, length=6, width=1.2)

    plt.tight_layout(rect=[0.09, 0, 1, 1])
    fig.legend(handles=legend_handles, labels=legend_labels, loc='center left', bbox_to_anchor=(0.001, 0.85),
               ncol=1, fontsize=15, markerscale=1.8, handlelength=2.0, handletextpad=0.5, frameon=True,
               edgecolor='gray')

    plt.savefig("1D_Sedov_MLP.pdf", dpi=300)
    print("📊 完美融合反射边界的 Sedov-MLP 间断点矢量图已成功保存。")
    plt.show()


if __name__ == "__main__":
    main()