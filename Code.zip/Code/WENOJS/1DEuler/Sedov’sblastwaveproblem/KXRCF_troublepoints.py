import csv
import numpy as np
import matplotlib.pyplot as plt

'''
Joint Post-process for Sedov Problem: KXRCF Troubled-Point Detector (1x3 Canvas)
【边界条件硬核对齐】：全盘废除流入/流出边界，引入与求解器完全对齐的标量反射边界外推逻辑。
【文件名严格对齐】：采用真实的带有 Dynamic 的 Sedov 命名结构。
【美术与轴系全盘锁死】：严格沿用 ax.set_xticks([-5.0, 0, 5.0])、linewidth=0.9 竖线及 0.05 留白控制。
'''


def load_euler_csv_data(filename):
    """
    安全读取标准 CSV 数据，返回网格中心坐标 x、密度 rho 和压力 p
    """
    x_center = []
    rho_numerical = []
    p_numerical = []

    try:
        with open(filename, mode='r', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            for row in reader:
                x_center.append(float(row["x"]))
                if "rho" in row:
                    rho_numerical.append(float(row["rho"]))
                elif "Exact_solution_T" in row:
                    rho_numerical.append(float(row["Exact_solution_T"]))

                if "p" in row:
                    p_numerical.append(float(row["p"]))
                else:
                    p_numerical.append(0.0)
    except FileNotFoundError:
        print(f"❌ 警告: 未找到文件 {filename}")
        return None, None, None

    return np.array(x_center), np.array(rho_numerical), np.array(p_numerical)


def apply_reflective_bc_scalar(entropy_1d, nghost=3):
    """
    针对标量（非线性物理熵）的高精度反射边界条件。
    遵循您提供的物理规范：标量物理量在左右边界均表现为严格的镜像对称映射。
    """
    N = len(entropy_1d)
    ext_length = N + 2 * nghost
    entropy_ext = np.zeros(ext_length)

    # 填充物理内部区
    entropy_ext[nghost:-nghost] = entropy_1d

    # 左边界对称反射 (对应原代码中的 U_ext[0, :nghost] = U[0, nghost-1::-1])
    entropy_ext[:nghost] = entropy_1d[nghost - 1::-1]

    # 右边界对称反射 (对应原代码中的 U_ext[0, -nghost:] = U[0, -1:-nghost-1:-1])
    entropy_ext[-nghost:] = entropy_1d[-1:-nghost - 1:-1]

    return entropy_ext


def detect_troubled_points_only_kxrcf(x_center, rho, p, gamma=1.4, threshold=1.0, nghost=3):
    """
    基于反射边界条件重构的 KXRCF 问题点探测器
    """
    N = len(rho)
    dx = x_center[1] - x_center[0]

    # 严格采用非线性标量熵，引入 1e-12 截断保护
    entropy_physical = p / np.maximum(rho ** gamma, 1e-12)

    # 🟢 完美调用与您求解器底漆对齐的反射边界条件外推机制
    entropy_ext = apply_reflective_bc_scalar(entropy_physical, nghost=nghost)

    prob_length = N + 2
    is_troubled_full = np.zeros(prob_length, dtype=bool)

    for i in range(prob_length):
        idx_ext = i + (nghost - 1)

        u0_l = (entropy_ext[idx_ext - 2] + 22 * entropy_ext[idx_ext - 1] + entropy_ext[idx_ext]) / 24.0
        u1_l = (entropy_ext[idx_ext] - entropy_ext[idx_ext - 2]) / 2.0
        u2_l = (entropy_ext[idx_ext - 2] - 2 * entropy_ext[idx_ext - 1] + entropy_ext[idx_ext]) / 2.0

        u0_c = (entropy_ext[idx_ext - 1] + 22 * entropy_ext[idx_ext] + entropy_ext[idx_ext + 1]) / 24.0
        u1_c = (entropy_ext[idx_ext + 1] - entropy_ext[idx_ext - 1]) / 2.0
        u2_c = (entropy_ext[idx_ext - 1] - 2 * entropy_ext[idx_ext] + entropy_ext[idx_ext + 1]) / 2.0

        u0_r = (entropy_ext[idx_ext] + 22 * entropy_ext[idx_ext + 1] + entropy_ext[idx_ext + 2]) / 24.0
        u1_r = (entropy_ext[idx_ext + 2] - entropy_ext[idx_ext]) / 2.0
        u2_r = (entropy_ext[idx_ext] - 2 * entropy_ext[idx_ext + 1] + entropy_ext[idx_ext + 2]) / 2.0

        edge_R_of_L = u0_l + 0.5 * u1_l + (1.0 / 6.0) * u2_l
        edge_L_of_C = u0_c - 0.5 * u1_c + (1.0 / 6.0) * u2_c

        edge_R_of_C = u0_c + 0.5 * u1_c + (1.0 / 6.0) * u2_c
        edge_L_of_R = u0_r - 0.5 * u1_r + (1.0 / 6.0) * u2_r

        delta_left = np.abs(edge_L_of_C - edge_R_of_L)
        delta_right = np.abs(edge_L_of_R - edge_R_of_C)
        max_jump = np.max([delta_left, delta_right])

        denominator = (dx ** 2.5) * (np.abs(entropy_ext[idx_ext]) + 1e-10)
        kappa_val = max_jump / denominator

        if kappa_val > threshold:
            is_troubled_full[i] = True

    return is_troubled_full[1:N + 1]


def main():
    nx_list = [100, 200, 400]
    sub_labels = ['(a)', '(b)', '(c)']
    T_final = 0.0010
    gamma = 1.4
    KXRCF_THRESHOLD = 1.0

    try:
        data_riemann = np.load('Sedov’s blast  WaveProblem_WENO5_N4000_T0.0010.npz')
        x_riemann = data_riemann['x']
        rho_riemann = data_riemann['rho']
        print("✅ 成功加载 参考解数据")
    except FileNotFoundError:
        print("❌ 错误: 未能在当前目录找到参考解文件")
        return

    fig, axes = plt.subplots(1, 3, figsize=(20, 7))
    legend_handles = []
    legend_labels = []

    for idx, Nx in enumerate(nx_list):
        ax = axes[idx]
        kxrcf_file = f"SedovProblem_WENO5KXRCF_Dynamic_N{Nx}_T{T_final:.4f}.csv"

        x_kx, rho_kx, p_kx = load_euler_csv_data(kxrcf_file)
        if x_kx is None:
            ax.text(0.5, 0.5, f'Data Missing\nN = {Nx}', ha='center', va='center', fontsize=16)
            continue

        is_troubled = detect_troubled_points_only_kxrcf(x_kx, rho_kx, p_kx, gamma, KXRCF_THRESHOLD, nghost=3)

        total_points = len(x_kx)
        print(f"[KXRCF N = {Nx}] 反射边界下捕捉的间断点数量: {np.sum(is_troubled)}/{total_points}")

        # 1. 绘制高对比度黑色精确解参考实线
        line1, = ax.plot(x_riemann, rho_riemann, color='black', linewidth=2.5, label='Reference')

        # 2. 数值解采用蓝色实线绘制
        line2, = ax.plot(x_kx, rho_kx, color='blue', linewidth=2.0, label='KXRCF')

        # 3. 绘制荧光紫竖线标记 (linewidth=0.9)
        for i in range(total_points):
            if is_troubled[i]:
                ax.axvline(x=x_kx[i], color='fuchsia', linestyle='-', linewidth=0.8, alpha=0.8)

        if idx == 0:
            legend_handles = [line1, line2]
            legend_labels = ['Reference', 'KXRCF']

        ax.set_xlabel(f'X\n{sub_labels[idx]} N = {Nx}', fontsize=32, labelpad=3)
        if idx == 0:
            ax.set_ylabel('Density', fontsize=32, labelpad=5)

        ax.set_xlim(-2.0, 2.0)
        ax.set_xticks([-2.0, 0, 2.0])

        if idx == 0:
            ax.set_ylim(0.0, 6.5)
            ax.set_yticks([0.0, 3.0, 6.0])
            ax.tick_params(axis='both', labelsize=24, direction='in', top=True, right=True, length=6, width=1.2)
        else:
            ax.set_ylim(0.0, 6.5)
            ax.set_yticks([])
            ax.tick_params(axis='x', labelsize=24, direction='in', top=True, right=True, length=6, width=1.2)
            ax.tick_params(axis='y', direction='in', left=True, right=True, length=6, width=1.2)

    plt.tight_layout(rect=[0.05, 0, 1, 1])
    fig.legend(handles=legend_handles, labels=legend_labels, loc='center left', bbox_to_anchor=(0.001, 0.85),
               ncol=1, fontsize=15, markerscale=1.8, handlelength=2.0, handletextpad=0.5, frameon=True,
               edgecolor='gray')

    plt.savefig("1D_Sedov_KXRCF.pdf", dpi=300)
    print("📊 完美融合反射边界的 Sedov-KXRCF 间断点矢量图已成功保存。")
    plt.show()


if __name__ == "__main__":
    main()