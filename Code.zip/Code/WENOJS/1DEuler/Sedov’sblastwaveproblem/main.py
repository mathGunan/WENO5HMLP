import csv
import time
import numpy as np
import matplotlib.pyplot as plt  # 引入学术绘图库
from RK3 import *
from IC import *
from helperfunction import *

gamma = 1.4


def compute_single_run(N, T_final=0.001, CFL=0.5, gamma=1.4):
    """
    单次一维 Sedov 爆炸波仿真运行函数（含完整推进计时）
    """
    x = np.linspace(-2, 2, N + 1)  # 网格端点
    dx = float(x[1] - x[0])  # 空间步长
    x_center = 0.5 * (x[1:] + x[:-1])  # 网格中心
    U_center = IC(x_center)  # 初始守恒量
    t = 0.0
    iteration = 0
    dt = compute_dt(U_center, dx, CFL, gamma)

    # 【开始计时】：在时间推进循环前记录起始时间
    start_time = time.time()

    # 时间推进循环
    while t < T_final:
        if t + dt > T_final:
            dt = T_final - t
        U_center = SolverWENO5RK3(U_center, dx, dt, gamma)
        t += dt
        iteration += 1
        dt = compute_dt(U_center, dx, CFL, gamma)

        if iteration % 50 == 0:
            progress = t / T_final * 100
            print(f"迭代 {iteration:4d} | 进度 {progress:5.1f}% | t = {t:.4f}/{T_final} | dt = {dt:.4e}")

    # 【结束计时】：计算整个数值推进过程的净消耗时间
    end_time = time.time()
    cpu_time = end_time - start_time
    print(f"⏱️ 纯 WENO5 数值推进完成！总迭代步数: {iteration} 步 | 总 CPU 计算时间 = {cpu_time:.3f} 秒")

    rho_num, u_num, p_num = convert_to_primitive(U_center, gamma)

    return x_center, rho_num, u_num, p_num, cpu_time


def main():
    print("=== 开始 1D WENO5 Sedov’s blast wave Problem ===")
    T_final = 0.001
    N = 200
    CFL = 0.5

    # 获取最终时刻的密度、速度、压力以及总 CPU 耗时
    x_center, rho_num, u_num, p_num, cpu_time = compute_single_run(N, T_final, CFL)

    # =========================================================
    # 【数据保存】：将流场解与总 CPU 时间规范集成导出至唯一的标准 .csv 文件
    # =========================================================
    csv_filename = f"Sedov_blastWaveProblem_WENO5_N{N}_T{T_final:.4f}.csv"

    with open(csv_filename, mode='w', newline='', encoding='utf-8') as f:
        writer = csv.writer(f)
        # 写入物理量及耗时对应的清晰学术表头
        writer.writerow(["x", "rho", "u", "p", "CPU_time_seconds"])

        # 逐网格点将一维分布数据固化写入 CSV 中
        for i in range(N):
            # 仅在第一行 (i == 0) 写入实际的 CPU 耗时，其余行留空
            cpu_val = f"{cpu_time:.6f}" if i == 0 else ""

            writer.writerow([
                f"{x_center[i]:.8e}",
                f"{rho_num[i]:.8e}",
                f"{u_num[i]:.8e}",
                f"{p_num[i]:.8e}",
                cpu_val
            ])

    print(f"\n✅ 最终时刻解与计算耗时已成功保存至 {csv_filename}")

    # =========================================================
    #  【可视化绘图】：【学术级单一密度函数快速可视化绘图展示】
    # =========================================================
    print("📊 正在绘制一维密度流场剖面图...")
    plt.figure(figsize=(8, 6))

    # 采用经典 CFD 论文风格：蓝色实线 + 空心圆点
    plt.plot(x_center, rho_num, 'o-', color='blue', markerfacecolor='none',
             markersize=4, linewidth=1.5, label=f'Pure WENO5 (N={N})')

    plt.xlim(-2, 2)
    plt.title("Sedov Blast Wave Problem - Density Profile (Pure WENO5)", fontsize=14, fontweight='bold', pad=15)
    plt.xlabel("x", fontsize=12)
    plt.ylabel(r"$\rho$", fontsize=12)
    plt.grid(True, linestyle=':', alpha=0.6)
    plt.legend(loc='best')
    plt.tight_layout()
    plt.show()


if __name__ == "__main__":
    main()