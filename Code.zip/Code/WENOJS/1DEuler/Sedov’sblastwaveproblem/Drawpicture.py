import csv
import numpy as np
import matplotlib.pyplot as plt

'''
Joint Post-process for Sedov Blast Wave Problem: 1x3 子图联合绘制 (N = 100, 200, 400)
【严格对齐文件名】：针对 Pure WENO5、WENO5-H-MLP、WENO5KXRCF 的文件名拼写和结构差异进行了硬核数据路由适配。
【全盘对齐美术设置】：严格沿用 ax.set_xticks([-5.0, 0, 5.0])、ax.set_yticks([0.2, 0.6, 1.0]) 以及紧凑留白 0.05。
【图层纯净规范】：Reference 黑色实线 + 三种方案数值实线，外部大图例彻底拿掉任何间断点(竖线)条目。
'''


def load_euler_csv_data(filename):
    """
    安全读取标准 CSV 数据，返回网格中心坐标 x 和密度 rho
    """
    x_center = []
    rho_numerical = []

    try:
        with open(filename, mode='r', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            for row in reader:
                x_center.append(float(row["x"]))
                if "rho" in row:
                    rho_numerical.append(float(row["rho"]))
                elif "Exact_solution_T" in row:
                    rho_numerical.append(float(row["Exact_solution_T"]))
    except FileNotFoundError:
        print(f"❌ 警告: 未找到文件 {filename}")
        return None, None

    return np.array(x_center), np.array(rho_numerical)


def main():
    nx_list = [100, 200, 400]
    sub_labels = ['(a)', '(b)', '(c)']
    T_final = 0.0010  # 严格匹配四位小数规范

    # 加载高分辨率参考解数据
    try:
        data_riemann = np.load('Sedov’s blast  WaveProblem_WENO5_N4000_T0.0010.npz')
        x_riemann = data_riemann['x']
        rho_riemann = data_riemann['rho']
        print("✅ 成功加载 Sedov 爆炸波高分辨率参考解数据 (N=4000)")
    except FileNotFoundError:
        print("❌ 错误: 未能在当前目录找到参考解文件 'Sedov’s blast  WaveProblem_WENO5_N4000_T0.0010.npz'")
        return

    # 初始化 1x3 学术画布
    fig, axes = plt.subplots(1, 3, figsize=(20, 7))
    legend_handles = []
    legend_labels = []

    for idx, Nx in enumerate(nx_list):
        ax = axes[idx]

        # =========================================================================
        # 【数据路由重构】：严格匹配您提供的真实文件名格式差异
        # =========================================================================
        weno5_file = f"Sedov_blastWaveProblem_WENO5_N{Nx}_T{T_final:.4f}.csv"
        mlp_file = f"Sedov_blastwaveProblem_WENO5MLP_N{Nx}_T{T_final:.4f}.csv"
        kxrcf_file = f"SedovProblem_WENO5KXRCF_Dynamic_N{Nx}_T{T_final:.4f}.csv"

        # 安全加载底层物理流场数据
        x_weno, rho_weno = load_euler_csv_data(weno5_file)
        x_mlp, rho_mlp = load_euler_csv_data(mlp_file)
        x_kx, rho_kx = load_euler_csv_data(kxrcf_file)

        # 健壮性检查
        if x_weno is None or x_mlp is None or x_kx is None:
            ax.text(0.0, 0.5, f'Data Missing\nN = {Nx}', ha='center', va='center', fontsize=16, color='red')
            continue

        # 1. 绘制高对比度黑色精确解参考实线
        line1, = ax.plot(x_riemann, rho_riemann, color='black', linewidth=2.5, label='Reference')

        # 2. 绘制纯 WENO5 数值解：纯绿色空心上三角点 (彻底拿掉连线，s=40)
        scat1 = ax.scatter(x_weno, rho_weno, marker='^', edgecolors='forestgreen', facecolors='none', s=40, label='WENO5')

        # 3. 绘制 KXRCF 数值解：纯蓝色空心圆点 (彻底拿掉连线，s=40)
        scat2 = ax.scatter(x_kx, rho_kx, marker='o', edgecolors='blue', facecolors='none', s=40, label='KXRCF')

        # 4. 绘制 WENO5-H-MLP 数值解：纯红色空心正方形 (彻底拿掉连线，s=40)
        scat3 = ax.scatter(x_mlp, rho_mlp, marker='s', edgecolors='red', facecolors='none', s=40, label='WENO5-H-MLP')


        # 严格对齐您的最新图例逻辑：仅在最左侧第一个子图中抓取核心物理流场标签
        if idx == 0:
            legend_handles = [line1, scat1, scat2, scat3]
            legend_labels = ['Reference', 'WENO5', 'KXRCF', 'WENO5-H-MLP']

        # 坐标轴标签美化
        ax.set_xlabel(f'X\n{sub_labels[idx]} N = {Nx}', fontsize=32, labelpad=3)
        if idx == 0:
            ax.set_ylabel('Density', fontsize=32, labelpad=5)

        # =========================================================================
        # 【物理轴系控制标尺】：完美锁死您指定的全部最新刻度及朝内属性

        ax.set_xticks([-2.0, 0, 2.0])

        if idx == 0:
            ax.set_yticks([0.0,3.0,6.0])
            ax.tick_params(axis='both', labelsize=24, direction='in', top=True, right=True, length=6, width=1.2)
        else:
            ax.set_yticks([])
            ax.tick_params(axis='x', labelsize=24, direction='in', top=True, right=True, length=6, width=1.2)
            ax.tick_params(axis='y', direction='in', left=True, right=True, length=6, width=1.2)

    # 严格同步：精密留白收缩至 0.05
    plt.tight_layout(rect=[0.09, 0, 1, 1])

    # 外部大图例挂靠控制
    fig.legend(handles=legend_handles, labels=legend_labels, loc='center left', bbox_to_anchor=(0.001, 0.85),
               ncol=1, fontsize=15, markerscale=1.8, handlelength=2.0, handletextpad=0.5, frameon=True,
               edgecolor='gray')



    output_pdf = "1D_Sedov_Compare.pdf"
    plt.savefig(output_pdf, dpi=300)
    print(f"📊 Sedov 爆炸波问题多方案密度对比图已成功保存至: {output_pdf}")
    plt.show()


if __name__ == "__main__":
    main()