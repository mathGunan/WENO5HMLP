from RK3 import *
from IC import *
from helperfunction import *
import time

gamma = 1.4

def compute_single_run(N, T_final=0.001, CFL=0.5,gamma = 1.4):
    x = np.linspace(-2,2, N + 1)     # 网格端点
    dx = float(x[1] - x[0])                 #空间步长
    x_center = 0.5 * (x[1:] + x[:-1])     # 网格中心
    U_center = IC(x_center)               # 初始守恒量
    t = 0.0
    iteration = 0
    dt=compute_dt(U_center, dx, CFL, gamma)
    # 时间推进
    start_time = time.time()
    while t < T_final:
        if t + dt > T_final:
            dt = T_final - t
        U_center = SolverWENO5RK3(U_center,dx, dt, gamma)
        t += dt
        iteration += 1
        dt = compute_dt(U_center, dx, CFL, gamma)

        if iteration % 50 == 0:
            progress = t / T_final * 100
            print(f"迭代 {iteration:4d} | 进度 {progress:5.1f}% | t = {t:.4f}/{T_final} | dt = {dt:.4e}")

    end_time = time.time()
    print("cpu时间为：",end_time - start_time)

    rho_num, u_num, p_num = convert_to_primitive(U_center, gamma)

    return x_center, rho_num


def main():
    print("=== 开始 1D WENO5 Sedov’s blast wave Problem  ===")
    T_final = 0.001
    N=4000
    CFL = 0.5

    x_center, rho_num = compute_single_run(N, T_final, CFL)

    filename = f"Sedov’s blast  WaveProblem_WENO5_N{N}_T{T_final:.4f}.npz"
    np.savez(
        filename,
        x=x_center,
        rho=rho_num,
    )
    print(f"✅ 结果已保存至 {filename}")


if __name__ == "__main__":
    main()





