import numpy as np

def IC(x_center):
    """
    Sedov's blast wave problem 初始条件（计算域 [-2, 2]）
    参数:
        x_center: 网格中心坐标数组，范围 [-2, 2]
    返回:
        U: 守恒变量数组 (3, N)
    """
    n = len(x_center)
    U = np.zeros((3, n))
    gamma = 1.4

    # 基本初始状态（处处相同）
    rho = 1.0  # 密度
    u = 0.0  # 速度
    E = 1e-12  # 能量（极低）

    # 计算网格间距
    dx = x_center[1] - x_center[0]   # 总长度4.0

    # 找到中心点 (x=0)
    center_idx = np.argmin(np.abs(x_center - 0.0))

    for i in range(n):
        if i == center_idx:
            # 中心网格：注入巨大能量（论文中的值）
            E_center = 3200000.0 / dx
            U[0, i] = rho
            U[1, i] = rho * u
            U[2, i] = E_center
        else:
            # 其他网格：极低能量状态
            U[0, i] = rho
            U[1, i] = rho * u
            U[2, i] = E

    return U

if __name__ == '__main__':
    x = np.linspace(-5, 5, 400 + 1)
    x_center = 0.5 * (x[1:] + x[:-1])
    print(np.argmin(np.abs(x_center - 0.0)))