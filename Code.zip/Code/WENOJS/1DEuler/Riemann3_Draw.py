import csv
import numpy as np
import matplotlib.pyplot as plt


def load_euler_csv_data(filename):
    """
    安全读取 Euler 方程仿真输出或精确解的标准 CSV 数据，返回网格中心和密度 rho
    """
    x_center = []
    rho_numerical = []
    try:
        with open(filename, mode='r', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            for row in reader:
                x_center.append(float(row["x"]))
                if "rho" in row:
                    rho_numerical.append(float(row["rho"]))
                elif "Exact_solution_T" in row:
                    rho_numerical.append(float(row["Exact_solution_T"]))
    except FileNotFoundError:
        print(f"❌ 警告: 未找到文件 {filename}")
        return None, None
    return np.array(x_center), np.array(rho_numerical)


def main():
    nx_list = [100, 200, 400]
    # 3x3 子图的学术标签 (a) 到 (i) 完美递增
    sub_labels = [
        ['(a)', '(b)', '(c)'],  # Row 1: SLMC
        ['(d)', '(e)', '(f)'],  # Row 2: Lax
        ['(g)', '(h)', '(i)']   # Row 3: Sod
    ]

    # 创建 3x3 画布
    fig, axes = plt.subplots(3, 3, figsize=(20, 18))

    legend_handles = []
    legend_labels = []

    # =========================================================================
    # ROW 1: SLMC Problem
    # =========================================================================
    T_slmc = 2.0000
    for idx, Nx in enumerate(nx_list):
        ax = axes[0, idx]
        exact_file = f"Slowlymovingcontactdiscontinuity/Exact_Density_Solution_N{Nx}.csv"
        weno5_file = f"Slowlymovingcontactdiscontinuity/SMCDProblem_WENO5_N{Nx}_T{T_slmc:.4f}.csv"
        kxrcf_file = f"Slowlymovingcontactdiscontinuity/SMCDProblem_WENO5KXRCF_N{Nx}_T{T_slmc:.4f}.csv"
        mlp_file = f"Slowlymovingcontactdiscontinuity/SMCDProblem_WENO5MLP_N{Nx}_T{T_slmc:.4f}.csv"

        x_exact, rho_exact = load_euler_csv_data(exact_file)
        x_weno, rho_weno = load_euler_csv_data(weno5_file)
        x_kx, rho_kx = load_euler_csv_data(kxrcf_file)
        x_mlp, rho_mlp = load_euler_csv_data(mlp_file)

        if x_exact is not None and x_weno is not None and x_kx is not None and x_mlp is not None:
            line1, = ax.plot(x_exact, rho_exact, color='black', linewidth=2.5, label='Reference')
            scat1 = ax.scatter(x_weno, rho_weno, marker='^', edgecolors='forestgreen', facecolors='none', s=40,
                               label='WENO5')
            scat2 = ax.scatter(x_kx, rho_kx, marker='o', edgecolors='blue', facecolors='none', s=40, label='KXRCF')
            scat3 = ax.scatter(x_mlp, rho_mlp, marker='s', edgecolors='red', facecolors='none', s=40,
                               label='WENO5-H-MLP')

            if not legend_handles:
                legend_handles = [line1, scat1, scat2, scat3]
                legend_labels = ['Reference', 'WENO5', 'KXRCF', 'WENO5-H-MLP']

        # 刻度与标签控制 (针对不同问题，保留每行的 X 轴数字)
        ax.set_xlim(0.0, 1.0)
        ax.set_xticks([0.0, 0.5, 1.0])
        ax.set_ylim(0.9, 1.5)

        ax.set_xlabel(f'X\n{sub_labels[0][idx]} SLMC (N = {Nx})', fontsize=30, labelpad=5)
        if idx == 0:
            ax.set_ylabel('Density', fontsize=30, labelpad=5)
            ax.set_yticks([1.0, 1.2, 1.4])
            ax.tick_params(axis='both', labelsize=28, direction='in', top=True, right=True, length=6, width=1.2)
        else:
            ax.set_yticks([])
            ax.tick_params(axis='both', labelsize=28, direction='in', top=True, right=True, left=True, length=6, width=1.2)
            ax.tick_params(axis='y', labelleft=False)

    # =========================================================================
    # ROW 2: LAX Problem
    # =========================================================================
    T_lax = 1.30
    try:
        data_lax = np.load('Laxproblem/riemann_solution.npz')
        x_lax_ref = data_lax['x']
        rho_lax_ref = data_lax['rho']
    except FileNotFoundError:
        print("❌ 错误: 未找到 Lax 参考解 'riemann_solution.npz'")
        x_lax_ref, rho_lax_ref = None, None

    for idx, Nx in enumerate(nx_list):
        ax = axes[1, idx]
        weno5_file = f"Laxproblem/LaxProblem_WENO5_N{Nx}_T{T_lax:.2f}.csv"
        kxrcf_file = f"Laxproblem/LaxProblem_WENO5KXRCF_N{Nx}_T{T_lax:.2f}.csv"
        mlp_file = f"Laxproblem/LaxProblem_WENO5MLP_N{Nx}_T{T_lax:.2f}.csv"

        x_weno, rho_weno = load_euler_csv_data(weno5_file)
        x_kx, rho_kx = load_euler_csv_data(kxrcf_file)
        x_mlp, rho_mlp = load_euler_csv_data(mlp_file)

        if x_lax_ref is not None and x_weno is not None and x_kx is not None and x_mlp is not None:
            ax.plot(x_lax_ref, rho_lax_ref, color='black', linewidth=2.5)
            ax.scatter(x_weno, rho_weno, marker='^', edgecolors='forestgreen', facecolors='none', s=40)
            ax.scatter(x_kx, rho_kx, marker='o', edgecolors='blue', facecolors='none', s=40)
            ax.scatter(x_mlp, rho_mlp, marker='s', edgecolors='red', facecolors='none', s=40)

        # 刻度与标签控制 (针对不同问题，保留每行的 X 轴数字)
        ax.set_xlim(-5.0, 5.0)
        ax.set_xticks([-5.0, 0.0, 5.0])
        ax.set_ylim(0.2, 1.4)

        # 已经修改这里，用 sub_labels[1][idx] 映射 (d), (e), (f)
        ax.set_xlabel(f'X\n{sub_labels[1][idx]} Lax (N = {Nx})', fontsize=30, labelpad=5)
        if idx == 0:
            ax.set_ylabel('Density', fontsize=30, labelpad=5)
            ax.set_yticks([0.4, 0.8, 1.2])
            ax.tick_params(axis='both', labelsize=28, direction='in', top=True, right=True, length=6, width=1.2)
        else:
            ax.set_yticks([])
            ax.tick_params(axis='both', labelsize=28, direction='in', top=True, right=True, left=True, length=6, width=1.2)
            ax.tick_params(axis='y', labelleft=False)

    # =========================================================================
    # ROW 3: SOD Problem
    # =========================================================================
    T_sod = 2.00
    try:
        data_sod = np.load('Sodproblem/riemann_solution.npz')
        x_sod_ref = data_sod['x']
        rho_sod_ref = data_sod['rho']
    except FileNotFoundError:
        print("❌ 错误: 未找到 Sod 参考解 'riemann_solution.npz'")
        x_sod_ref, rho_sod_ref = None, None

    for idx, Nx in enumerate(nx_list):
        ax = axes[2, idx]
        weno5_file = f"Sodproblem/SodProblem_WENO5_N{Nx}_T{T_sod:.2f}.csv"
        kxrcf_file = f"Sodproblem/SodProblem_WENO5KXRCF_N{Nx}_T{T_sod:.2f}.csv"
        mlp_file = f"Sodproblem/SodProblem_WENO5MLP_N{Nx}_T{T_sod:.2f}.csv"

        x_weno, rho_weno = load_euler_csv_data(weno5_file)
        x_kx, rho_kx = load_euler_csv_data(kxrcf_file)
        x_mlp, rho_mlp = load_euler_csv_data(mlp_file)

        if x_sod_ref is not None and x_weno is not None and x_kx is not None and x_mlp is not None:
            ax.plot(x_sod_ref, rho_sod_ref, color='black', linewidth=2.5)
            ax.scatter(x_weno, rho_weno, marker='^', edgecolors='forestgreen', facecolors='none', s=40)
            ax.scatter(x_kx, rho_kx, marker='o', edgecolors='blue', facecolors='none', s=40)
            ax.scatter(x_mlp, rho_mlp, marker='s', edgecolors='red', facecolors='none', s=40)

        # Sod 标尺适配 (保留 X 轴数字)
        ax.set_xlim(-5.0, 5.0)
        ax.set_xticks([-5.0, 0.0, 5.0])
        ax.set_ylim(0.0, 1.1)

        # 这里使用 sub_labels[2][idx] 映射保持连续输出 (g), (h), (i)
        ax.set_xlabel(f'X\n{sub_labels[2][idx]} Sod (N = {Nx})', fontsize=30, labelpad=5)
        if idx == 0:
            ax.set_ylabel('Density', fontsize=30, labelpad=5)
            ax.set_yticks([0.2, 0.6, 1.0])
            ax.tick_params(axis='both', labelsize=28, direction='in', top=True, right=True, length=6, width=1.2)
        else:
            ax.set_yticks([])
            ax.tick_params(axis='both', labelsize=28, direction='in', top=True, right=True, left=True, length=6,
                           width=1.2)
            ax.tick_params(axis='y', labelleft=False)

    # =========================================================================
    # 全局排版美化与外侧通用图例 (已挪至极左侧、垂直纵向排列)
    # =========================================================================
    # 为左侧垂直图例留出充足位置，避免与第一列 Y 轴标签重叠 (rect 起始点由 0.08 调整为 0.14)
    plt.tight_layout(rect=[0.14, 0, 1, 1])

    # 垂直死死卡在整张大图的最左侧外边缘
    fig.legend(
        handles=legend_handles,
        labels=legend_labels,
        loc='center left',
        bbox_to_anchor=(0.005, 0.7),  # 垂直居中于画布极左边缘
        ncol=1,  # 1 列纵向垂直堆叠
        fontsize=20,
        markerscale=2.0,
        handlelength=2.5,
        handletextpad=0.5,
        frameon=True,
        edgecolor='gray'
    )

    output_pdf = "1D_Euler_Riemann3_compare.pdf"
    plt.savefig(output_pdf, dpi=300)
    print(f"\n📊 完美的 3x3 欧拉方程多问题复合密度对比图已成功。保存至: {output_pdf}")
    plt.show()


if __name__ == "__main__":
    main()