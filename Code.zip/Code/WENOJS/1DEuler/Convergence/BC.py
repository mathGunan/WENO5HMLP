import numpy as np
'''实现周期性边界条件'''
def apply_periodic_bc(U, ng=3):
    """
    对 1D 守恒变量 U 添加周期性边界条件。

    参数:
        U : ndarray, shape (m, N)
            m 为守恒变量个数（如 ρ, ρu, E），N 为单元数。
        ng : int
            ghost cell 的数量（默认 3，适合 WENO5）

    返回:
        U_ext : ndarray, shape (m, N + 2*ng)
            含 ghost cell 的扩展数组。
    """
    m, N = U.shape
    U_ext = np.zeros((m, N + 2 * ng))

    # 中间部分
    U_ext[:, ng:ng + N] = U

    # 左右 ghost cells 由周期性条件决定
    U_ext[:, :ng] = U[:, -ng:]
    U_ext[:, -ng:] = U[:, :ng]

    return U_ext


if __name__ == "__main__":
    # 模拟 5 个格点，3 个守恒分量
    N = 5
    U = np.arange(N * 3).reshape(N, 3)
    print("原始 U (N=5):\n", U.shape)

    U_ext = apply_periodic_bc(U)
    print("\n形状变化:", U.shape, "->", U_ext.shape)