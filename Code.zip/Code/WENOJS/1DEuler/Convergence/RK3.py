import numpy as np
import torch
from RoeFlux import *
from BC import *

def SolverWENO5RK3(u_phys, dx, dt, gamma, nghost=3):
    """
    一维 Euler 方程纯有限差分 WENO5 + RK3 时间推进求解器（基准对照组）。
    【优化对齐】：内部呼叫全通道一体化向量化切片右端项，确保耗时测试的高精度公平性。
    """
    # 扩展 ghost cells
    u_ext = apply_periodic_bc(u_phys, ng=nghost)

    def rhs(U_ext):
        # 呼叫新版全通道一体化纯 WENO5 空间残差算子
        return compute_rhs_1d(U_ext, dx, gamma, nghost)

    # ---- RK3 Stage 1 ----
    k1 = rhs(u_ext)
    u1 = u_phys + dt * k1

    # ---- RK3 Stage 2 ----
    u_ext1 = apply_periodic_bc(u1, ng=nghost)
    k2 = rhs(u_ext1)
    u2 = 0.75 * u_phys + 0.25 * (u1 + dt * k2)

    # ---- RK3 Stage 3 ----
    u_ext2 = apply_periodic_bc(u2, ng=nghost)
    k3 = rhs(u_ext2)
    u_phys_next = (1.0 / 3.0) * u_phys + (2.0 / 3.0) * (u2 + dt * k3)

    return u_phys_next


def SolverWenoMLPRK3(u_phys, dx, dt, gamma, model, device, P=0.5, nghost=3):
    """
    使用 WENO5 + MLP 神经网络探测器的一维 Euler 方程组三阶 Runge-Kutta 时间推进求解器。
    【收敛阶优化】：基于单通道标量物理熵计算一维静态掩码 prob_1d，并在三个子步内部共享透传。
    """
    u_ext = apply_periodic_bc(u_phys, ng=nghost)

    # ========== 【核心修改】：从当前步首扩展守恒量中计算标量物理熵 S ==========
    rho = u_ext[0, :]
    u = u_ext[1, :] / np.maximum(rho, 1e-10)
    E = u_ext[2, :]
    p = np.maximum((gamma - 1.0) * (E - 0.5 * rho * u**2), 1e-10)
    entropy = p / np.maximum(rho ** gamma, 1e-12)

    # 调用修改后的一维单通道预测接口，直接获取一维掩码序列 (N+2,)
    prob_1d = predict(entropy, dx, model, device)
    if P is not None:
        prob_1d = (prob_1d > P).astype(np.float32)

    # 封装内部空间残差闭包，牢牢锁定一维 prob_1d
    def rhs(U_ext):
        return compute_rhs_1d_with_MLP(U_ext, dx, prob_1d, gamma, nghost)

    # ---------- RK3 Stage 1 ----------
    k1 = rhs(u_ext)
    u1 = u_phys + dt * k1

    # ---------- RK3 Stage 2 ----------
    u_ext1 = apply_periodic_bc(u1, ng=nghost)
    k2 = rhs(u_ext1)
    u2 = 0.75 * u_phys + 0.25 * (u1 + dt * k2)

    # ---------- RK3 Stage 3 ----------
    u_ext2 = apply_periodic_bc(u2, ng=nghost)
    k3 = rhs(u_ext2)
    u_phys_next = (1.0 / 3.0) * u_phys + (2.0 / 3.0) * (u2 + dt * k3)

    return u_phys_next


def SolverWenoKXRCFRK3(u_phys, dx, dt, gamma, threshold=1.0, nghost=3):
    """
    使用 WENO5 + KXRCF 传统物理指示器的一维 Euler 方程组三阶 Runge-Kutta 时间推进求解器。
    【收敛阶优化】：彻底废除多通道通量探测，严格基于物理熵生成一维 prob_1d，实现与 MLP 求解器的架构镜像对称。
    """

    def detect_KXRCF_prob_1d(entropy_ext, dx, threshold=1.0, nghost=3):
        """
        输入全流场外推后的标量物理熵序列，计算并生成一维间断指示数组。
        返回一维 (N+2,) 数组 (1.0 代表光滑/线性高阶，0.0 代表间断/WENO5)。
        """
        N_ext = entropy_ext.shape[0]
        N = N_ext - 2 * nghost
        prob_length = N + 2

        prob_1d = np.zeros(prob_length, dtype=np.float32)

        # ========== 空间物理交界面周边网格中心点循环 ==========
        for i in range(prob_length):
            idx_ext = i + (nghost - 1)  # 智能索引映射转换

            # 提取周边 3 个网格中心点的二次多项式边缘外推系数
            u0_l = (entropy_ext[idx_ext - 2] + 22.0 * entropy_ext[idx_ext - 1] + entropy_ext[idx_ext]) / 24.0
            u1_l = (entropy_ext[idx_ext] - entropy_ext[idx_ext - 2]) / 2.0
            u2_l = (entropy_ext[idx_ext - 2] - 2.0 * entropy_ext[idx_ext - 1] + entropy_ext[idx_ext]) / 2.0

            u0_c = (entropy_ext[idx_ext - 1] + 22.0 * entropy_ext[idx_ext] + entropy_ext[idx_ext + 1]) / 24.0
            u1_c = (entropy_ext[idx_ext + 1] - entropy_ext[idx_ext - 1]) / 2.0
            u2_c = (entropy_ext[idx_ext - 1] - 2.0 * entropy_ext[idx_ext] + entropy_ext[idx_ext + 1]) / 2.0

            u0_r = (entropy_ext[idx_ext] + 22.0 * entropy_ext[idx_ext + 1] + entropy_ext[idx_ext + 2]) / 24.0
            u1_r = (entropy_ext[idx_ext + 2] - entropy_ext[idx_ext]) / 2.0
            u2_r = (entropy_ext[idx_ext] - 2.0 * entropy_ext[idx_ext + 1] + entropy_ext[idx_ext + 2]) / 2.0

            # 界面外推值
            edge_R_of_L = u0_l + 0.5 * u1_l + (1.0 / 6.0) * u2_l
            edge_L_of_C = u0_c - 0.5 * u1_c + (1.0 / 6.0) * u2_c
            edge_R_of_C = u0_c + 0.5 * u1_c + (1.0 / 6.0) * u2_c
            edge_L_of_R = u0_r - 0.5 * u1_r + (1.0 / 6.0) * u2_r

            # 计算交界面处的绝对跳跃最大值
            delta_left = np.abs(edge_L_of_C - edge_R_of_L)
            delta_right = np.abs(edge_L_of_R - edge_R_of_C)
            max_jump = np.max([delta_left, delta_right])

            # 依据 Li & Qiu (2010) 学术规范无量纲化
            denominator = (dx ** 2.5) * (np.abs(entropy_ext[idx_ext]) + 1e-10)
            kappa_val = max_jump / denominator

            # 光滑判定阈值二值化
            prob_1d[i] = 1.0 if kappa_val <= threshold else 0.0

        return prob_1d

    # 扩展 ghost cells
    u_ext = apply_periodic_bc(u_phys, ng=nghost)

    # ========== 【核心修改】：从首步扩展守恒量中提取标量物理熵 S ==========
    rho = u_ext[0, :]
    u = u_ext[1, :] / np.maximum(rho, 1e-10)
    E = u_ext[2, :]
    p = np.maximum((gamma - 1.0) * (E - 0.5 * rho * u**2), 1e-10)
    entropy = p / np.maximum(rho ** gamma, 1e-12)

    # 呼叫专属标量探测算子，生成一维 prob_1d 静态掩码
    prob_1d = detect_KXRCF_prob_1d(entropy, dx, threshold=threshold, nghost=nghost)

    # 封装内部空间残差闭包，透传一维 KXRCF 掩码
    def rhs(U_ext):
        return compute_rhs_1d_with_KXRCF(U_ext, dx, prob_1d, gamma, nghost)

    # ---------- RK3 Stage 1 ----------
    k1 = rhs(u_ext)
    u1 = u_phys + dt * k1

    # ---------- RK3 Stage 2 ----------
    u_ext1 = apply_periodic_bc(u1, ng=nghost)
    k2 = rhs(u_ext1)
    u2 = 0.75 * u_phys + 0.25 * (u1 + dt * k2)

    # ---------- RK3 Stage 3 ----------
    u_ext2 = apply_periodic_bc(u2, ng=nghost)
    k3 = rhs(u_ext2)
    u_phys_next = (1.0 / 3.0) * u_phys + (2.0 / 3.0) * (u2 + dt * k3)

    return u_phys_next