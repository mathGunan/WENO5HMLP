import numpy as np
import torch
import torch.nn as nn

class Weno5FDMMLP(torch.nn.Module):

    def __init__(self):
        super().__init__()
        self.model = nn.Sequential(
                nn.Linear(4, 64), nn.Tanh(),
                nn.Linear(64, 32), nn.LeakyReLU(0.01),
                nn.Linear(32, 16), nn.LeakyReLU(0.01),
                nn.Linear(16, 1), nn.Sigmoid()  # 输出概率
            )

    def forward(self, x):
        return self.model(x)