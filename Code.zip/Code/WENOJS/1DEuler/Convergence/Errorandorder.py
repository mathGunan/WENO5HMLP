import numpy as np
from scipy.optimize import curve_fit


'''L1 误差估计'''
def L1_error(u_num, u_ex):
    return np.mean(np.abs(u_num - u_ex))

'''L2误差估计'''
def L2_error(u_num, u_ex):
    return np.sqrt(np.mean((u_num - u_ex)**2))

'''L∞范数误差估计'''
def Linf_error(u_num, u_ex):
    return np.max(np.abs(u_num - u_ex))

'''收敛阶or精度计算'''

#收敛阶计算
def convergence_order(errors, grid_sizes):
    orders = []
    for i in range(1, len(errors)):
        order = np.log(errors[i] / errors[i-1]) / np.log(grid_sizes[i] / grid_sizes[i-1])
        orders.append(order)
    return orders






