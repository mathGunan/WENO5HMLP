import numpy as np
#输出的是张量，并且是守恒量，而不是底层变量
def IC(x_center):
    '''初始化正弦波扰动条件'''
    n = len(x_center)
    U = np.zeros((3, n))

    # 给定的初始条件
    rho = 1.0 + 0.2 * np.sin(x_center)
    u = np.ones(n)
    p = np.ones(n)

    # 转换为守恒变量
    gamma = 1.4  # 比热比
    U[0, :] = rho  # 质量密度
    U[1, :] = rho * u  # 动量
    U[2, :] = p / (gamma - 1) + 0.5 * rho * u ** 2  # 总能量

    return U