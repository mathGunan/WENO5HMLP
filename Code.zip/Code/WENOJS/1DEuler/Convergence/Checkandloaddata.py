import numpy as np

# 加载文件
data = np.load("WENO5MLP_1D_Convergence.npz")
# 或者单独访问某个数组
print(f"\n网格数 N: {data['N']}")
print(f"L1误差: {data['errors_L1']}")
print(f"L1收敛阶: {data['orders_L1']}")
print(f"L2误差: {data['errors_L2']}")
print(f"L2收敛阶: {data['orders_L2']}")
print(f"Linf误差: {data['errors_Linf']}")
print(f"Linf收敛阶: {data['orders_Linf']}")
print(f"计算时间: {data['cpu_times']}")