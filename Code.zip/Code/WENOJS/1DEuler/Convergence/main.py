import csv
import time
import numpy as np
from Errorandorder import *
from RK3 import *
from IC import *
from helperfunction import *

gamma = 1.4


def compute_single_run(N, T_final=2.0):
    """
    执行一次 1D 纯 WENO5 收敛性测试
    参数:
        N: 网格数
        T_final: 最终时间
    返回:
        (N, E1, E2, Einf, cpu_time, dx)
    """
    L = 2 * np.pi
    x = np.linspace(0, L, N + 1)  # 网格端点
    dx = x[1] - x[0]
    x_center = 0.5 * (x[1:] + x[:-1])  # 网格中心

    # 初始守恒量
    U_center = IC(x_center)

    # =========================================================
    # 【高阶修正】：计算一维 Euler 方程在周期边界 L 下的光滑精确解
    # 假设对流速度为 1.0，利用 % L 算子将平移后的坐标严格映射回 [0, 2*pi]
    # =========================================================
    x_exact = (x_center - 1.0 * T_final) % L
    Exact_U_atT = IC(x_exact)
    rho_exact, u_exact, p_exact = convert_to_primitive(Exact_U_atT, gamma)

    # 时间步长设置 (dt 严格正比于 dx**(5/3)，确保时间项精度不掩盖空间五阶精度)
    dt = dx ** (5 / 3)
    t = 0.0
    iteration = 0
    start_time = time.time()

    # 时间推进循环
    while t < T_final:
        if t + dt > T_final:
            dt = T_final - t

        # 呼叫已经过全通道一体化切片升级的纯 WENO5 求解器
        U_center = SolverWENO5RK3(U_center, dx, dt, gamma)

        t += dt
        iteration += 1

        if iteration % 200 == 0:
            print(f"N={N}: 进度 {t / T_final * 100:.1f}%")

    cpu_time = time.time() - start_time
    rho_num, u_num, p_num = convert_to_primitive(U_center, gamma)

    # 误差计算 (直接呼叫你原有的 Errorandorder 模块)
    E1 = L1_error(rho_num, rho_exact)
    E2 = L2_error(rho_num, rho_exact)
    Einf = Linf_error(rho_num, rho_exact)

    print(f"N={N}: 完成 ({iteration} 步), CPU时间 = {cpu_time:.3f}s, L1={E1:.3e}")
    return (N, E1, E2, Einf, cpu_time, dx)


def main():
    """
    主程序: 循环不同网格数, 计算纯 WENO5 的误差与收敛阶并保存为 CSV
    """
    print("=== 开始 1D 纯 WENO5 收敛性测试 ===")

    test_N = [20, 40, 80, 160, 320,640]
    T_final = 2.0
    results = []

    # 遍历多网格加密序列
    for N in test_N:
        res = compute_single_run(N, T_final)
        results.append(res)

    # 提取多网格仿真数据
    errors_L1 = [r[1] for r in results]
    errors_L2 = [r[2] for r in results]
    errors_inf = [r[3] for r in results]
    cpu_times = [r[4] for r in results]
    dxs = [r[5] for r in results]

    # 调用你本地的算法计算纯 WENO5 的数值收敛阶
    order_l1 = convergence_order(errors_L1, dxs)
    order_l2 = convergence_order(errors_L2, dxs)
    order_inf = convergence_order(errors_inf, dxs)

    print("\n=== 收敛性结果 (格式: 纯 WENO5, 变量: 密度ρ) ===")
    print("-" * 80)
    print(f"{'N':<6s}  {'dx':<12s}  {'L1 Error':<13s}  {'L2 Error':<13s}  {'Linf Error':<13s}")
    print("-" * 80)
    for i, N in enumerate(test_N):
        print(f"{N:4d}  {dxs[i]:.4e}  {errors_L1[i]:.4e}  {errors_L2[i]:.4e}  {errors_inf[i]:.4e}")
    print("-" * 80)

    print(f"L1 阶数: {order_l1}")
    print(f"L2 阶数: {order_l2}")
    print(f"Linf 阶数: {order_inf}")

    # =========================================================
    # 【核心改变】：将测试结果严格写入标准化学术 CSV 表格
    # =========================================================
    csv_filename = "WENO5_1D_Convergence.csv"

    with open(csv_filename, mode='w', newline='', encoding='utf-8') as f:
        writer = csv.writer(f)
        # 写入表头 (包含网格分辨率、网格间距、三种常规算数误差、收敛阶以及计算开销)
        writer.writerow(
            ["N", "dx", "L1_Error", "L1_Order", "L2_Error", "L2_Order", "Linf_Error", "Linf_Order", "CPU_Time_s"])

        # 逐行固化加密数据
        for i, N in enumerate(test_N):
            # 第一行由于没有更粗网格，其 Order 填为 '-' 或 None
            l1_ord = order_l1[i - 1] if i > 0 else "-"
            l2_ord = order_l2[i - 1] if i > 0 else "-"
            inf_ord = order_inf[i - 1] if i > 0 else "-"

            writer.writerow([
                N,
                f"{dxs[i]:.6e}",
                f"{errors_L1[i]:.6e}", l1_ord,
                f"{errors_L2[i]:.6e}", l2_ord,
                f"{errors_inf[i]:.6e}", inf_ord,
                f"{cpu_times[i]:.4f}"
            ])

    print(f"\n✅ 纯 WENO5 精度测试数据已成功固化保存至 CSV: {csv_filename}")


if __name__ == "__main__":
    main()