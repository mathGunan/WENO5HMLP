from helperfunction import *


def compute_rhs_1d(U_ext, dx, gamma, nghost=3, epsilon=1e-6):
    """
    传统纯有限差分 WENO5 空间 RHS 计算函数（重构升级版）。
    【修改机制】：去除任何外部判定 prob_1d，直接在底层无条件执行纯正的非线性 WENO5 权值重构。
    【对齐优势】：结构、分流和切片映射与上述混合格式保持 100% 相同，确保精度和耗时测试的严谨公平。
    """
    n_vars, N_ext = U_ext.shape
    N = N_ext - 2 * nghost

    # ========== 1. 从守恒量计算中心点物理通量 F ==========
    rho = U_ext[0, :]
    u = U_ext[1, :] / np.maximum(rho, 1e-10)
    E = U_ext[2, :]
    p = np.maximum((gamma - 1.0) * (E - 0.5 * rho * u ** 2), 1e-10)
    a = np.sqrt(gamma * p / np.maximum(rho, 1e-10))

    F_ext = np.zeros_like(U_ext)
    F_ext[0, :] = rho * u
    F_ext[1, :] = rho * u ** 2 + p
    F_ext[2, :] = u * (E + p)

    # ========== 2. 全局 Lax-Friedrichs 通量分裂 ==========
    alpha = np.max(np.abs(u) + a)
    F_plus = 0.5 * (F_ext + alpha * U_ext)
    F_minus = 0.5 * (F_ext - alpha * U_ext)

    # ========== 3. 初始化物理交界面数值通量 ==========
    F_hat = np.zeros((3, N + 1))

    # ========== 4. 纯 WENO5 全通道重构循环 ==========
    for i_face in range(N + 1):
        i_center = i_face + nghost

        # --- (A) 纯 WENO5 正通量左重构 ---
        g_plus = F_plus[:, i_center - 3: i_center + 2]
        v0, v1, v2, v3, v4 = g_plus[:, 0], g_plus[:, 1], g_plus[:, 2], g_plus[:, 3], g_plus[:, 4]
        p1_plus = (2.0 * v0 - 7.0 * v1 + 11.0 * v2) / 6.0
        p2_plus = (-v1 + 5.0 * v2 + 2.0 * v3) / 6.0
        p3_plus = (2.0 * v2 + 5.0 * v3 - v4) / 6.0
        beta1_plus = (13.0 / 12.0) * (v0 - 2.0 * v1 + v2) ** 2 + 0.25 * (v0 - 4.0 * v1 + 3.0 * v2) ** 2
        beta2_plus = (13.0 / 12.0) * (v1 - 2.0 * v2 + v3) ** 2 + 0.25 * (v1 - v3) ** 2
        beta3_plus = (13.0 / 12.0) * (v2 - 2.0 * v3 + v4) ** 2 + 0.25 * (3.0 * v2 - 4.0 * v3 + v4) ** 2
        alpha1_plus = 0.1 / (epsilon + beta1_plus) ** 2
        alpha2_plus = 0.6 / (epsilon + beta2_plus) ** 2
        alpha3_plus = 0.3 / (epsilon + beta3_plus) ** 2
        wsum_plus = alpha1_plus + alpha2_plus + alpha3_plus
        F_plus_L = (alpha1_plus * p1_plus + alpha2_plus * p2_plus + alpha3_plus * p3_plus) / wsum_plus

        # --- (B) 纯 WENO5 负通量右重构 ---
        g_minus = F_minus[:, i_center - 2: i_center + 3]
        v0, v1, v2, v3, v4 = g_minus[:, 0], g_minus[:, 1], g_minus[:, 2], g_minus[:, 3], g_minus[:, 4]
        p1_minus = (-v0 + 5.0 * v1 + 2.0 * v2) / 6.0
        p2_minus = (2.0 * v1 + 5.0 * v2 - v3) / 6.0
        p3_minus = (11.0 * v2 - 7.0 * v3 + 2.0 * v4) / 6.0
        beta1_minus = (13.0 / 12.0) * (v0 - 2.0 * v1 + v2) ** 2 + 0.25 * (v0 - 4.0 * v1 + 3.0 * v2) ** 2
        beta2_minus = (13.0 / 12.0) * (v1 - 2.0 * v2 + v3) ** 2 + 0.25 * (v1 - v3) ** 2
        beta3_minus = (13.0 / 12.0) * (v2 - 2.0 * v3 + v4) ** 2 + 0.25 * (3.0 * v2 - 4.0 * v3 + v4) ** 2
        alpha1_minus = 0.3 / (epsilon + beta1_minus) ** 2
        alpha2_minus = 0.6 / (epsilon + beta2_minus) ** 2
        alpha3_minus = 0.1 / (epsilon + beta3_minus) ** 2
        wsum_minus = alpha1_minus + alpha2_minus + alpha3_minus
        F_minus_R = (alpha1_minus * p1_minus + alpha2_minus * p2_minus + alpha3_minus * p3_minus) / wsum_minus

        # 组合当前物理界面的数值通量
        F_hat[:, i_face] = F_plus_L + F_minus_R

    # ========== 5. 计算空间右端项残差 ==========
    rhs = -(F_hat[:, 1:] - F_hat[:, :-1]) / dx
    return rhs


def compute_rhs_1d_with_MLP(U_ext, dx, prob_1d, gamma, nghost=3, epsilon=1e-6):
    """
    针对精度/收敛阶测试优化的一维空间 RHS 计算函数（MLP 神经网络探测器版本）。
    【优化核心】：采用一体化交界面循环与 NumPy 全通道切片，严格依据一维单通道 prob_1d 切换策略。
    """
    n_vars, N_ext = U_ext.shape
    N = N_ext - 2 * nghost

    # ========== 1. 从守恒量计算中心点物理通量 F ==========
    rho = U_ext[0, :]
    u = U_ext[1, :] / np.maximum(rho, 1e-10)
    E = U_ext[2, :]
    p = np.maximum((gamma - 1.0) * (E - 0.5 * rho * u ** 2), 1e-10)
    a = np.sqrt(gamma * p / np.maximum(rho, 1e-10))

    F_ext = np.zeros_like(U_ext)
    F_ext[0, :] = rho * u
    F_ext[1, :] = rho * u ** 2 + p
    F_ext[2, :] = u * (E + p)

    # ========== 2. 全局 Lax-Friedrichs 通量分裂 ==========
    alpha = np.max(np.abs(u) + a)
    F_plus = 0.5 * (F_ext + alpha * U_ext)  # 正通量 (向右传播)
    F_minus = 0.5 * (F_ext - alpha * U_ext)  # 负通量 (向左传播)

    # ========== 3. 初始化物理交界面数值通量 (共 N+1 个交界面) ==========
    F_hat = np.zeros((3, N + 1))

    # ========== 4. 核心交界面循环：混合重构 3 个守恒通道 ==========
    for i_face in range(N + 1):
        i_center = i_face + nghost  # 映射到带有 ghost cell 的网格中心点索引

        # ----------------------------------------------------
        #  (A) 正通量 F+ 的左重构 (F_plus_L) -> 偏置上风模板
        # ----------------------------------------------------
        if prob_1d[i_face]:  # 线性高阶五阶重构分支 (精度测试时光滑区触发)
            g = F_plus[:, i_center - 3: i_center + 2]
            F_plus_L = (2.0 * g[:, 0] - 13.0 * g[:, 1] + 47.0 * g[:, 2] + 27.0 * g[:, 3] - 3.0 * g[:, 4]) / 60.0
        else:  # 降级回标准差分 WENO5 重构分支
            g = F_plus[:, i_center - 3: i_center + 2]
            v0, v1, v2, v3, v4 = g[:, 0], g[:, 1], g[:, 2], g[:, 3], g[:, 4]
            p1 = (2.0 * v0 - 7.0 * v1 + 11.0 * v2) / 6.0
            p2 = (-v1 + 5.0 * v2 + 2.0 * v3) / 6.0
            p3 = (2.0 * v2 + 5.0 * v3 - v4) / 6.0
            beta1 = (13.0 / 12.0) * (v0 - 2.0 * v1 + v2) ** 2 + 0.25 * (v0 - 4.0 * v1 + 3.0 * v2) ** 2
            beta2 = (13.0 / 12.0) * (v1 - 2.0 * v2 + v3) ** 2 + 0.25 * (v1 - v3) ** 2
            beta3 = (13.0 / 12.0) * (v2 - 2.0 * v3 + v4) ** 2 + 0.25 * (3.0 * v2 - 4.0 * v3 + v4) ** 2
            alpha1 = 0.1 / (epsilon + beta1) ** 2
            alpha2 = 0.6 / (epsilon + beta2) ** 2
            alpha3 = 0.3 / (epsilon + beta3) ** 2
            wsum = alpha1 + alpha2 + alpha3
            F_plus_L = (alpha1 * p1 + alpha2 * p2 + alpha3 * p3) / wsum

        # ----------------------------------------------------
        #  (B) 负通量 F- 的右重构 (F_minus_R) -> 镜像偏置上风模板
        # ----------------------------------------------------
        if prob_1d[i_face + 1]:  # 线性高阶五阶重构分支
            g = F_minus[:, i_center - 2: i_center + 3]
            F_minus_R = (-3.0 * g[:, 0] + 27.0 * g[:, 1] + 47.0 * g[:, 2] - 13.0 * g[:, 3] + 2.0 * g[:, 4]) / 60.0
        else:  # 降级回标准差分 WENO5 重构分支
            g = F_minus[:, i_center - 2: i_center + 3]
            v0, v1, v2, v3, v4 = g[:, 0], g[:, 1], g[:, 2], g[:, 3], g[:, 4]
            p1 = (-v0 + 5.0 * v1 + 2.0 * v2) / 6.0
            p2 = (2.0 * v1 + 5.0 * v2 - v3) / 6.0
            p3 = (11.0 * v2 - 7.0 * v3 + 2.0 * v4) / 6.0
            beta1 = (13.0 / 12.0) * (v0 - 2.0 * v1 + v2) ** 2 + 0.25 * (v0 - 4.0 * v1 + 3.0 * v2) ** 2
            beta2 = (13.0 / 12.0) * (v1 - 2.0 * v2 + v3) ** 2 + 0.25 * (v1 - v3) ** 2
            beta3 = (13.0 / 12.0) * (v2 - 2.0 * v3 + v4) ** 2 + 0.25 * (3.0 * v2 - 4.0 * v3 + v4) ** 2
            alpha1 = 0.3 / (epsilon + beta1) ** 2
            alpha2 = 0.6 / (epsilon + beta2) ** 2
            alpha3 = 0.1 / (epsilon + beta3) ** 2
            wsum = alpha1 + alpha2 + alpha3
            F_minus_R = (alpha1 * p1 + alpha2 * p2 + alpha3 * p3) / wsum

        # 在界面上完美组合数值通量
        F_hat[:, i_face] = F_plus_L + F_minus_R

    # ========== 5. 计算空间右端项残差 ==========
    rhs = -(F_hat[:, 1:] - F_hat[:, :-1]) / dx
    return rhs


def compute_rhs_1d_with_KXRCF(U_ext, dx, prob_1d, gamma, nghost=3, epsilon=1e-6):
    """
    针对精度/收敛阶测试优化的一维空间 RHS 计算函数（MLP 神经网络探测器版本）。
    【优化核心】：采用一体化交界面循环与 NumPy 全通道切片，严格依据一维单通道 prob_1d 切换策略。
    """
    n_vars, N_ext = U_ext.shape
    N = N_ext - 2 * nghost

    # ========== 1. 从守恒量计算中心点物理通量 F ==========
    rho = U_ext[0, :]
    u = U_ext[1, :] / np.maximum(rho, 1e-10)
    E = U_ext[2, :]
    p = np.maximum((gamma - 1.0) * (E - 0.5 * rho * u ** 2), 1e-10)
    a = np.sqrt(gamma * p / np.maximum(rho, 1e-10))

    F_ext = np.zeros_like(U_ext)
    F_ext[0, :] = rho * u
    F_ext[1, :] = rho * u ** 2 + p
    F_ext[2, :] = u * (E + p)

    # ========== 2. 全局 Lax-Friedrichs 通量分裂 ==========
    alpha = np.max(np.abs(u) + a)
    F_plus = 0.5 * (F_ext + alpha * U_ext)  # 正通量 (向右传播)
    F_minus = 0.5 * (F_ext - alpha * U_ext)  # 负通量 (向左传播)

    # ========== 3. 初始化物理交界面数值通量 (共 N+1 个交界面) ==========
    F_hat = np.zeros((3, N + 1))

    # ========== 4. 核心交界面循环：混合重构 3 个守恒通道 ==========
    for i_face in range(N + 1):
        i_center = i_face + nghost  # 映射到带有 ghost cell 的网格中心点索引

        # ----------------------------------------------------
        #  (A) 正通量 F+ 的左重构 (F_plus_L) -> 偏置上风模板
        # ----------------------------------------------------
        if prob_1d[i_face]:  # 线性高阶五阶重构分支 (精度测试时光滑区触发)
            g = F_plus[:, i_center - 3: i_center + 2]
            F_plus_L = (2.0 * g[:, 0] - 13.0 * g[:, 1] + 47.0 * g[:, 2] + 27.0 * g[:, 3] - 3.0 * g[:, 4]) / 60.0
        else:  # 降级回标准差分 WENO5 重构分支
            g = F_plus[:, i_center - 3: i_center + 2]
            v0, v1, v2, v3, v4 = g[:, 0], g[:, 1], g[:, 2], g[:, 3], g[:, 4]
            p1 = (2.0 * v0 - 7.0 * v1 + 11.0 * v2) / 6.0
            p2 = (-v1 + 5.0 * v2 + 2.0 * v3) / 6.0
            p3 = (2.0 * v2 + 5.0 * v3 - v4) / 6.0
            beta1 = (13.0 / 12.0) * (v0 - 2.0 * v1 + v2) ** 2 + 0.25 * (v0 - 4.0 * v1 + 3.0 * v2) ** 2
            beta2 = (13.0 / 12.0) * (v1 - 2.0 * v2 + v3) ** 2 + 0.25 * (v1 - v3) ** 2
            beta3 = (13.0 / 12.0) * (v2 - 2.0 * v3 + v4) ** 2 + 0.25 * (3.0 * v2 - 4.0 * v3 + v4) ** 2
            alpha1 = 0.1 / (epsilon + beta1) ** 2
            alpha2 = 0.6 / (epsilon + beta2) ** 2
            alpha3 = 0.3 / (epsilon + beta3) ** 2
            wsum = alpha1 + alpha2 + alpha3
            F_plus_L = (alpha1 * p1 + alpha2 * p2 + alpha3 * p3) / wsum

        # ----------------------------------------------------
        #  (B) 负通量 F- 的右重构 (F_minus_R) -> 镜像偏置上风模板
        # ----------------------------------------------------
        if prob_1d[i_face + 1]:  # 线性高阶五阶重构分支
            g = F_minus[:, i_center - 2: i_center + 3]
            F_minus_R = (-3.0 * g[:, 0] + 27.0 * g[:, 1] + 47.0 * g[:, 2] - 13.0 * g[:, 3] + 2.0 * g[:, 4]) / 60.0
        else:  # 降级回标准差分 WENO5 重构分支
            g = F_minus[:, i_center - 2: i_center + 3]
            v0, v1, v2, v3, v4 = g[:, 0], g[:, 1], g[:, 2], g[:, 3], g[:, 4]
            p1 = (-v0 + 5.0 * v1 + 2.0 * v2) / 6.0
            p2 = (2.0 * v1 + 5.0 * v2 - v3) / 6.0
            p3 = (11.0 * v2 - 7.0 * v3 + 2.0 * v4) / 6.0
            beta1 = (13.0 / 12.0) * (v0 - 2.0 * v1 + v2) ** 2 + 0.25 * (v0 - 4.0 * v1 + 3.0 * v2) ** 2
            beta2 = (13.0 / 12.0) * (v1 - 2.0 * v2 + v3) ** 2 + 0.25 * (v1 - v3) ** 2
            beta3 = (13.0 / 12.0) * (v2 - 2.0 * v3 + v4) ** 2 + 0.25 * (3.0 * v2 - 4.0 * v3 + v4) ** 2
            alpha1 = 0.3 / (epsilon + beta1) ** 2
            alpha2 = 0.6 / (epsilon + beta2) ** 2
            alpha3 = 0.1 / (epsilon + beta3) ** 2
            wsum = alpha1 + alpha2 + alpha3
            F_minus_R = (alpha1 * p1 + alpha2 * p2 + alpha3 * p3) / wsum

        # 在界面上完美组合数值通量
        F_hat[:, i_face] = F_plus_L + F_minus_R

    # ========== 5. 计算空间右端项残差 ==========
    rhs = -(F_hat[:, 1:] - F_hat[:, :-1]) / dx
    return rhs