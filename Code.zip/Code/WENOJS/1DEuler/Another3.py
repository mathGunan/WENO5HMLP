import csv
import numpy as np
import matplotlib.pyplot as plt


def load_euler_csv_data(filename):
    """
    安全读取标准 CSV 数据，返回网格中心坐标 x 和密度 rho
    """
    x_center = []
    rho_numerical = []
    try:
        with open(filename, mode='r', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            for row in reader:
                # 兼容不同的列名格式
                if "x_center" in row:
                    x_center.append(float(row["x_center"]))
                elif "x" in row:
                    x_center.append(float(row["x"]))

                if "rho_primitive" in row:
                    rho_numerical.append(float(row["rho_primitive"]))
                elif "rho" in row:
                    rho_numerical.append(float(row["rho"]))
                elif "Exact_solution_T" in row:
                    rho_numerical.append(float(row["Exact_solution_T"]))
    except FileNotFoundError:
        print(f"❌ 警告: 未找到文件 {filename}")
        return None, None
    return np.array(x_center), np.array(rho_numerical)


def main():
    nx_list = [100, 200, 400]
    # 3x3 子图的学术标签 (a) 到 (i)
    sub_labels = [
        ['(a)', '(b)', '(c)'],  # Row 1: Sedov
        ['(d)', '(e)', '(f)'],  # Row 2: Double Blast
        ['(g)', '(h)', '(i)']  # Row 3: Shu-Osher
    ]

    # 创建 3x3 超高清晰度学术画布
    fig, axes = plt.subplots(3, 3, figsize=(20, 18))

    legend_handles = []
    legend_labels = []

    # =========================================================================
    # ROW 1: Sedov Blast Wave Problem
    # =========================================================================
    T_sedov = 0.0010
    try:
        data_sedov = np.load('Sedov’sblastwaveproblem/Sedov’s blast  WaveProblem_WENO5_N4000_T0.0010.npz')
        x_sedov_ref = data_sedov['x']
        rho_sedov_ref = data_sedov['rho']
        print("✅ 成功加载 Sedov 爆炸波高分辨率参考解 (N=4000)")
    except FileNotFoundError:
        print("❌ 错误: 未找到参考解文件 'Sedov’s blast  WaveProblem_WENO5_N4000_T0.0010.npz'")
        x_sedov_ref, rho_sedov_ref = None, None

    for idx, Nx in enumerate(nx_list):
        ax = axes[0, idx]
        weno5_file = f"Sedov’sblastwaveproblem/Sedov_blastWaveProblem_WENO5_N{Nx}_T{T_sedov:.4f}.csv"
        mlp_file = f"Sedov’sblastwaveproblem/Sedov_blastwaveProblem_WENO5MLP_N{Nx}_T{T_sedov:.4f}.csv"
        kxrcf_file = f"Sedov’sblastwaveproblem/SedovProblem_WENO5KXRCF_Dynamic_N{Nx}_T{T_sedov:.4f}.csv"

        x_weno, rho_weno = load_euler_csv_data(weno5_file)
        x_mlp, rho_mlp = load_euler_csv_data(mlp_file)
        x_kx, rho_kx = load_euler_csv_data(kxrcf_file)

        if x_sedov_ref is not None and x_weno is not None and x_mlp is not None and x_kx is not None:
            line1, = ax.plot(x_sedov_ref, rho_sedov_ref, color='black', linewidth=2.5, label='Reference')
            scat1 = ax.scatter(x_weno, rho_weno, marker='^', edgecolors='forestgreen', facecolors='none', s=40,
                               label='WENO5')
            scat2 = ax.scatter(x_kx, rho_kx, marker='o', edgecolors='blue', facecolors='none', s=40, label='KXRCF')
            scat3 = ax.scatter(x_mlp, rho_mlp, marker='s', edgecolors='red', facecolors='none', s=40,
                               label='WENO5-H-MLP')

            if not legend_handles:
                legend_handles = [line1, scat1, scat2, scat3]
                legend_labels = ['Reference', 'WENO5', 'KXRCF', 'WENO5-H-MLP']

        # 轴线与区间规范
        ax.set_xlim(-2.0, 2.0)
        ax.set_xticks([-2.0, 0.0, 2.0])
        ax.set_ylim(0.0, 6.5)

        ax.set_xlabel(f'X\n{sub_labels[0][idx]} Sedov blast(N = {Nx})', fontsize=30, labelpad=5)
        if idx == 0:
            ax.set_ylabel('Density', fontsize=30, labelpad=5)
            ax.set_yticks([0.0, 3.0, 6.0])
            ax.tick_params(axis='both', labelsize=28, direction='in', top=True, right=True, length=6, width=1.2, pad=12)
        else:
            ax.set_yticks([])
            ax.tick_params(axis='both', labelsize=28, direction='in', top=True, right=True, left=True, length=6,
                           width=1.2, pad=12)
            ax.tick_params(axis='y', labelleft=False)

    # =========================================================================
    # ROW 2: Double Blast Wave Problem
    # =========================================================================
    T_double = 0.038
    try:
        data_double = np.load('DoubleBlastWaveinteraction/DoubleBlastWaveInteractionProblem_WENO5_N4000_T0.04.npz', allow_pickle=True)
        x_double_ref = data_double['x']
        rho_double_ref = data_double['rho']
        print("✅ 成功加载 Double Blast Wave 强间断参考解 (N=4000)")
    except FileNotFoundError:
        print("❌ 错误: 未找到参考解文件 'DoubleBlastWaveInteractionProblem_WENO5_N4000_T0.04.npz'")
        x_double_ref, rho_double_ref = None, None

    for idx, Nx in enumerate(nx_list):
        ax = axes[1, idx]
        weno5_file = f"DoubleBlastWaveinteraction/DoubleBlastWave_PureWENO5_N{Nx}_T{T_double:.3f}.csv"
        kxrcf_file = f"DoubleBlastWaveinteraction/DoubleBlastWave_WENO5KXRCF_Dynamic_N{Nx}_T{T_double:.3f}.csv"
        mlp_file = f"DoubleBlastWaveinteraction/DoubleBlastWave_WENO5MLP_Dynamic_N{Nx}_T{T_double:.3f}.csv"

        x_weno, rho_weno = load_euler_csv_data(weno5_file)
        x_kx, rho_kx = load_euler_csv_data(kxrcf_file)
        x_mlp, rho_mlp = load_euler_csv_data(mlp_file)

        if x_double_ref is not None and x_weno is not None and x_kx is not None and x_mlp is not None:
            ax.plot(x_double_ref, rho_double_ref, color='black', linewidth=2.5)
            ax.scatter(x_weno, rho_weno, marker='^', edgecolors='forestgreen', facecolors='none', s=40)
            ax.scatter(x_kx, rho_kx, marker='o', edgecolors='blue', facecolors='none', s=40)
            ax.scatter(x_mlp, rho_mlp, marker='s', edgecolors='red', facecolors='none', s=40)

        # 轴线与区间规范
        ax.set_xlim(0.0, 1.0)
        ax.set_xticks([0.0, 0.5, 1.0])
        ax.set_ylim(0.0, 6.5)

        ax.set_xlabel(f'X\n{sub_labels[1][idx]} Double blast(N = {Nx})', fontsize=30, labelpad=5)
        if idx == 0:
            ax.set_ylabel('Density', fontsize=30, labelpad=5)
            ax.set_yticks([0.0, 3.0, 6.0])
            ax.tick_params(axis='both', labelsize=28, direction='in', top=True, right=True, length=6, width=1.2, pad=12)
        else:
            ax.set_yticks([])
            ax.tick_params(axis='both', labelsize=28, direction='in', top=True, right=True, left=True, length=6,
                           width=1.2, pad=12)
            ax.tick_params(axis='y', labelleft=False)

    # =========================================================================
    # ROW 3: Shu-Osher Problem
    # =========================================================================
    T_shu = 1.80
    try:
        data_shu = np.load('Shu_OsherProblem/Shu_OsherProblem_WENO5_N2000_T1.80.npz')
        x_shu_ref = data_shu['x']
        rho_shu_ref = data_shu['rho']
        print("✅ 成功加载 Shu-Osher 高分辨率参考解 (N=2000)")
    except FileNotFoundError:
        print("❌ 错误: 未找到参考解文件 'Shu_OsherProblem_WENO5_N2000_T1.80.npz'")
        x_shu_ref, rho_shu_ref = None, None

    for idx, Nx in enumerate(nx_list):
        ax = axes[2, idx]
        weno5_file = f"Shu_OsherProblem/Shu_OsherProblem_WENO5_N{Nx}_T{T_shu:.2f}.csv"
        kxrcf_file = f"Shu_OsherProblem/Shu_OsherProblem_WENO5KXRCF_N{Nx}_T{T_shu:.2f}.csv"
        mlp_file = f"Shu_OsherProblem/Shu_OsherProblem_WENO5MLP_N{Nx}_T{T_shu:.2f}.csv"

        x_weno, rho_weno = load_euler_csv_data(weno5_file)
        x_kx, rho_kx = load_euler_csv_data(kxrcf_file)
        x_mlp, rho_mlp = load_euler_csv_data(mlp_file)

        if x_shu_ref is not None and x_weno is not None and x_kx is not None and x_mlp is not None:
            ax.plot(x_shu_ref, rho_shu_ref, color='black', linewidth=2.5)
            ax.scatter(x_weno, rho_weno, marker='^', edgecolors='forestgreen', facecolors='none', s=40)
            ax.scatter(x_kx, rho_kx, marker='o', edgecolors='blue', facecolors='none', s=40)
            ax.scatter(x_mlp, rho_mlp, marker='s', edgecolors='red', facecolors='none', s=40)

        # 轴线与区间规范
        ax.set_xlim(-5.0, 5.0)
        ax.set_xticks([-5.0, 0.0, 5.0])
        ax.set_ylim(0.5, 5.0)

        ax.set_xlabel(f'X\n{sub_labels[2][idx]} Shu-Osher(N = {Nx})', fontsize=30, labelpad=5)
        if idx == 0:
            ax.set_ylabel('Density', fontsize=30, labelpad=5)
            ax.set_yticks([1.0, 3.0, 5.0])
            ax.tick_params(axis='both', labelsize=28, direction='in', top=True, right=True, length=6, width=1.2, pad=14)
        else:
            ax.set_yticks([])
            ax.tick_params(axis='both', labelsize=28, direction='in', top=True, right=True, left=True, length=6,
                           width=1.2, pad=14)
            ax.tick_params(axis='y', labelleft=False)

    # =========================================================================
    # 全局排版优化与极左侧纵向挂靠图例
    # =========================================================================
    # 严格锁死 rect=[0.14, 0, 1, 1] 给左侧纵向垂直图例留足空间，防止重叠
    plt.tight_layout(rect=[0.14, 0, 1, 1])

    fig.legend(
        handles=legend_handles,
        labels=legend_labels,
        loc='center left',
        bbox_to_anchor=(0.005, 0.7),  # 居中垂直卡在大图最左侧外边缘
        ncol=1,  # 1列纵向垂直堆叠
        fontsize=20,
        markerscale=2.0,  # 提高图例中空心符号辨识度
        handlelength=2.5,
        handletextpad=0.5,
        frameon=True,
        edgecolor='gray'
    )

    output_pdf = "1D_Euler_Another3_compare.pdf"
    plt.savefig(output_pdf, dpi=300)
    print(f"\n📊 完美整合的 3x3 欧拉方程复杂强间断问题密度对比图已成功保存至: {output_pdf}")
    plt.show()


if __name__ == "__main__":
    main()