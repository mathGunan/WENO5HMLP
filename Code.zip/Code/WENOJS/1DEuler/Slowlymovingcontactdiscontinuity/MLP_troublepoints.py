import csv
import numpy as np
import matplotlib.pyplot as plt
import torch
import torch.nn as nn

# 完美对接您的专用函数模块
from BC import *
from helperfunction import *

'''
Joint Post-process (MLP-based Detector): 1x3 子图联合绘制 (N = 100, 200, 400)
【物理图层纯净】：仅保留 Reference 实线 + WENO5-H-MLP 数值散点 + 间断点竖线。
【核心逻辑反转】：模型输出 1 代表光滑（不画线），输出 <= P_threshold 时才判定为 Troubled Point 并绘制荧光紫竖线。
'''

def load_euler_csv_data(filename):
    """
    安全读取标准 CSV 数据，返回网格中心坐标 x、密度 rho 和压力 p
    """
    x_center = []
    rho_numerical = []
    p_numerical = []

    try:
        with open(filename, mode='r', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            for row in reader:
                x_center.append(float(row["x"]))

                # 兼容数值解密度表头与精确解密度表头
                if "rho" in row:
                    rho_numerical.append(float(row["rho"]))
                elif "Exact_solution_T" in row:
                    rho_numerical.append(float(row["Exact_solution_T"]))

                # 提取压力场用于还原热力学标量熵
                if "p" in row:
                    p_numerical.append(float(row["p"]))
                else:
                    p_numerical.append(0.0)
    except FileNotFoundError:
        print(f"❌ 警告: 未找到文件 {filename}")
        return None, None, None

    return np.array(x_center), np.array(rho_numerical), np.array(p_numerical)


def main():
    # 三种目标网格分辨率
    nx_list = [100, 200, 400]
    sub_labels = ['(a)', '(b)', '(c)']
    T_final = 2.0000
    gamma = 1.4

    # 🟢 神经网络模型相关配置项
    ckpt_path = "best_model.pth"
    P_threshold = 0.5            # 划分光滑与间断的临界阈值
    nghost = 3

    # 预先安全初始化并加载训练好的模型与设备选择流
    try:
        model, device = get_model(ckpt_path, device_str='auto')
        print(f"✅ 成功加载神经网络权重模型，当前计算设备：{device}")
    except FileNotFoundError:
        print(f"❌ 错误: 未能在路径找到模型文件 '{ckpt_path}'，请检查文件名与工作路径。")
        return

    fig, axes = plt.subplots(1, 3, figsize=(20, 7), dpi=300)

    legend_handles = []
    legend_labels = []

    # 循环控制绘制每一个子图
    for idx, Nx in enumerate(nx_list):
        ax = axes[idx]

        # 动态组装当前子图对应分辨率的数据文件名
        exact_file = f"Exact_Density_Solution_N{Nx}.csv"
        mlp_file = f"SMCDProblem_WENO5MLP_N{Nx}_T{T_final:.4f}.csv"

        # 安全加载底层流场数据
        x_exact, rho_exact, _ = load_euler_csv_data(exact_file)
        x_mlp, rho_mlp, p_mlp = load_euler_csv_data(mlp_file)

        # 健壮性检查
        if x_exact is None or x_mlp is None:
            ax.text(0.5, 0.5, f'Data Missing\nN = {Nx}', ha='center', va='center', fontsize=16)
            continue

        # =========================================================================
        # 【核心修改】：在最终时刻 U 矩阵的基础上，构造单物理量输入（标量非线性物理熵）
        # =========================================================================
        dx = float(x_mlp[1] - x_mlp[0])

        # 严格根据规范，计算全流场的非线性标量熵 S = p / rho^gamma (加入 1e-12 截断项防止真空报错)
        entropy_physical = p_mlp / np.maximum(rho_mlp ** gamma, 1e-12)

        # 升维输入，调用您的流出边界外推机制完成拓扑对称外扩
        entropy_2d = entropy_physical[np.newaxis, :]
        entropy_ext_2d = apply_outflow_bc(entropy_2d, nghost=nghost)
        entropy_with_bc = entropy_ext_2d[0, :]  # 压缩降维获取带有 ghost 单元的全场熵

        # 喂给您的 MLP 探测器进行推理预测，返回 prob_1d 形状为 (N+2,)
        prob_1d = predict(entropy_with_bc, dx, model, device)

        # 🟢【硬核反转逻辑】：输出趋于 1 是光滑，因此预测概率 <= 阈值 P 时才是 Troubled Point 间断点
        is_troubled_full = prob_1d <= P_threshold

        # 剥离掉两侧对应的保护映射区间，精准匹配核心物理网格（从 1 到 N）上的布尔判定序列
        is_troubled_physical = is_troubled_full[1:Nx + 1]

        total_points = len(x_mlp)
        troubled_count = np.sum(is_troubled_physical)
        print(f"[分辨率 N = {Nx}] WENO5-H-MLP 故障探测器运行完毕！判定问题点数量: {troubled_count}/{total_points}")

        # =========================================================================
        #    【纯净版学术绘图：仅包含 Reference 线 + WENO5-H-MLP 数值点 + 荧光紫竖线】
        # =========================================================================
        # 1. 绘制高对比度黑色实线作为精准参考解析解 (Reference)
        line1, = ax.plot(x_exact, rho_exact, color='black', linewidth=2.5, label='Reference')

        # 2. 绘制 WENO5-H-MLP 数值解：红色实线
        line2, = ax.plot(x_mlp, rho_mlp, color='red', linewidth=2.0, label='WENO5-H-MLP')

        # 3. 核心物理标记：仅在判定为非光滑的强间断点处拉起高亮荧光紫竖线
        vline_handle = None
        for i in range(total_points):
            if is_troubled_physical[i]:
                vline_handle = ax.axvline(x=x_mlp[i], color='fuchsia', linestyle='-', linewidth=1.0)

        # 仅在最左侧第一个子图中抓取全局图例句柄，防止文字条目密集堆叠
        if idx == 0:
            legend_handles = [line1, line2]
            legend_labels = ['Reference', 'WENO5-H-MLP']

        # 坐标轴标签美化
        ax.set_xlabel(f'X\n{sub_labels[idx]} N = {Nx}', fontsize=32, labelpad=3)

        if idx == 0:
            ax.set_ylabel('Density', fontsize=32, labelpad=5)

        # =========================================================================
        # 【轴系控制标尺】：完美契合一维 SMCD 慢运动接触间断问题的定义域
        # =========================================================================
        ax.set_xlim(0.0, 1.0)
        ax.set_xticks([0.0, 0.5, 1.0])

        if idx == 0:
            ax.set_ylim(0.9, 1.5)
            ax.set_yticks([1.0, 1.2, 1.4])
            ax.tick_params(axis='both', labelsize=24, direction='in', top=True, right=True, length=6, width=1.2)
        else:
            ax.set_ylim(0.9, 1.5)
            ax.set_yticks([])
            ax.tick_params(axis='x', labelsize=24, direction='in', top=True, right=True, length=6, width=1.2)
            ax.tick_params(axis='y', direction='in', left=True, right=True, length=6, width=1.2)

    # 极致学术紧凑性版面深度收缩
    plt.tight_layout(rect=[0.09, 0, 1, 1])

    # =========================================================================
    # 【全局外部大图例】：垂直堆叠卡在整张 1x3 大图的最左侧外边缘
    # =========================================================================
    fig.legend(
        handles=legend_handles,
        labels=legend_labels,
        loc='center left',
        bbox_to_anchor=(0.001, 0.85),
        ncol=1,
        fontsize=15,
        markerscale=1.8,
        handlelength=2.0,
        handletextpad=0.5,
        frameon=True,
        edgecolor='gray'
    )
    output_pdf = "1D_SLMC_MLP.pdf"
    plt.savefig(output_pdf, dpi=300)
    print(f"\n📊 完美的 1x3 流出边界下 KXRCF 密度与间断点图表已成功保存至: {output_pdf}")
    plt.show()


if __name__ == "__main__":
    main()