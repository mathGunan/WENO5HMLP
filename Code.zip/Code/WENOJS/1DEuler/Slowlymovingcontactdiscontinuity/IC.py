import numpy as np


def IC(x_center):
    '''缓慢移动接触间断的初始条件（向量化版本）'''
    n = len(x_center)
    U = np.zeros((3, n))
    gamma = 1.4

    # 创建掩码
    left_mask = x_center < 0.5
    right_mask = ~left_mask

    # 密度
    U[0, left_mask] = 1.4
    U[0, right_mask] = 1.0

    # 速度 (均为0.1)
    u = np.full(n, 0.1)

    # 动量
    U[1, left_mask] = 1.4 * 0.1
    U[1, right_mask] = 1.0 * 0.1

    # 总能量 (压力均为1.0)
    p = 1.0
    U[2, left_mask] = p / (gamma - 1) + 0.5 * 1.4 * 0.1 ** 2
    U[2, right_mask] = p / (gamma - 1) + 0.5 * 1.0 * 0.1 ** 2

    return U