import csv
import numpy as np
import matplotlib.pyplot as plt
from BC import *

'''
Joint Post-process: 1x3 子图联合绘制 (N = 100, 200, 400)
【边界完全对齐】：内部采用您原汁原味的流出边界条件函数 (apply_outflow_bc) 进行拓扑外推
横向对比 1D Euler SMCD 问题在不同分辨率下的密度剖面，并用荧光紫竖线精准锁死 KXRCF 挑出的问题点。
'''


def load_euler_csv_data(filename):
    """
    安全读取标准 CSV 数据，返回网格中心坐标 x、密度 rho 和压力 p
    """
    x_center = []
    rho_numerical = []
    p_numerical = []

    try:
        with open(filename, mode='r', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            for row in reader:
                x_center.append(float(row["x"]))

                # 兼容数值解密度表头与精确解密度表头
                if "rho" in row:
                    rho_numerical.append(float(row["rho"]))
                elif "Exact_solution_T" in row:
                    rho_numerical.append(float(row["Exact_solution_T"]))

                # 提取压力场用于还原热力学熵进行判别（若不存在压力列则默认补零）
                if "p" in row:
                    p_numerical.append(float(row["p"]))
                else:
                    p_numerical.append(0.0)
    except FileNotFoundError:
        print(f"❌ 警告: 未找到文件 {filename}")
        return None, None, None

    return np.array(x_center), np.array(rho_numerical), np.array(p_numerical)


def detect_troubled_points_only_kxrcf(x_center, rho, p, gamma=1.4, threshold=1.0, nghost=3):
    """
    基于 KXRCF 熵物理量外推逻辑重构的问题点探测器，内部完美调用 apply_outflow_bc
    """
    N = len(rho)
    dx = x_center[1] - x_center[0]

    # 🟢 【仅修改此处】：单纯将对数熵替换为非线性标量熵 S = p / max(rho^gamma, 1e-12)
    entropy_physical = p / np.maximum(rho ** gamma, 1e-12)

    # 2. 🟢 核心适配插槽：将一维标量熵临时升维至二维 (1, N)，调用您纯正的流出边界条件
    entropy_2d = entropy_physical[np.newaxis, :]
    entropy_ext_2d = apply_outflow_bc(entropy_2d, nghost=nghost)
    entropy_ext = entropy_ext_2d[0, :]  # 外推完毕后，降回一维标量场用于后续计算

    # 3. 严格契合 N + 2 长度的求解器区域拓扑 (i=0 对应物理网格第0个界面的左侧，即物理第-1个网格)
    prob_length = N + 2
    is_troubled_full = np.zeros(prob_length, dtype=bool)

    # 4. 严格执行您原汁原味的 KXRCF 多项式系数外推与绝对跳跃求最大值逻辑
    for i in range(prob_length):
        idx_ext = i + (nghost - 1)  # 智能索引映射转换

        # 提取标量熵在当前网格周边的左、中、右二次多项式系数
        u0_l = (entropy_ext[idx_ext - 2] + 22 * entropy_ext[idx_ext - 1] + entropy_ext[idx_ext]) / 24.0
        u1_l = (entropy_ext[idx_ext] - entropy_ext[idx_ext - 2]) / 2.0
        u2_l = (entropy_ext[idx_ext - 2] - 2 * entropy_ext[idx_ext - 1] + entropy_ext[idx_ext]) / 2.0

        u0_c = (entropy_ext[idx_ext - 1] + 22 * entropy_ext[idx_ext] + entropy_ext[idx_ext + 1]) / 24.0
        u1_c = (entropy_ext[idx_ext + 1] - entropy_ext[idx_ext - 1]) / 2.0
        u2_c = (entropy_ext[idx_ext - 1] - 2 * entropy_ext[idx_ext] + entropy_ext[idx_ext + 1]) / 2.0

        u0_r = (entropy_ext[idx_ext] + 22 * entropy_ext[idx_ext + 1] + entropy_ext[idx_ext + 2]) / 24.0
        u1_r = (entropy_ext[idx_ext + 2] - entropy_ext[idx_ext]) / 2.0
        u2_r = (entropy_ext[idx_ext] - 2 * entropy_ext[idx_ext + 1] + entropy_ext[idx_ext + 2]) / 2.0

        # 计算外推至界面两侧边缘处的熵解
        edge_R_of_L = u0_l + 0.5 * u1_l + (1.0 / 6.0) * u2_l
        edge_L_of_C = u0_c - 0.5 * u1_c + (1.0 / 6.0) * u2_c

        edge_R_of_C = u0_c + 0.5 * u1_c + (1.0 / 6.0) * u2_c
        edge_L_of_R = u0_r - 0.5 * u1_r + (1.0 / 6.0) * u2_r

        # 提取交界面处绝对物理跳跃的最大值
        delta_left = np.abs(edge_L_of_C - edge_R_of_L)
        delta_right = np.abs(edge_L_of_R - edge_R_of_C)
        max_jump = np.max([delta_left, delta_right])

        # 严格文献定义分母：包含网格尺度、局部变量绝对值以及防零极小量
        denominator = (dx ** 2.5) * (np.abs(entropy_ext[idx_ext]) + 1e-10)
        kappa_val = max_jump / denominator

        # 当且仅当无量纲跳跃 kappa_val > 1.0 时标记为有问题的强间断点
        if kappa_val > threshold:
            is_troubled_full[i] = True

    # 5. 剥离两侧保护单元，精准截取物理核心网格内（1 到 N）的布尔序列
    is_troubled_physical = is_troubled_full[1:N + 1]

    return is_troubled_physical


def main():
    # 三种目标网格分辨率
    nx_list = [100, 200, 400]
    sub_labels = ['(a)', '(b)', '(c)']
    T_final = 2.0000
    gamma = 1.4

    # 严格对齐您指示的 KXRCF 文献判别阈值
    KXRCF_THRESHOLD = 1.0

    fig, axes = plt.subplots(1, 3, figsize=(20, 7))

    legend_handles = []
    legend_labels = []

    # 循环控制绘制每一个子图
    for idx, Nx in enumerate(nx_list):
        ax = axes[idx]

        # 动态组装当前分辨率的数据文件名
        exact_file = f"Exact_Density_Solution_N{Nx}.csv"
        kxrcf_file = f"SMCDProblem_WENO5KXRCF_N{Nx}_T{T_final:.4f}.csv"

        # 安全加载流场数据
        x_exact, rho_exact, _ = load_euler_csv_data(exact_file)
        x_kx, rho_kx, p_kx = load_euler_csv_data(kxrcf_file)

        # 健壮性检查
        if x_exact is None or x_kx is None:
            ax.text(0.5, 0.5, f'Data Missing\nN = {Nx}', ha='center', va='center', fontsize=16)
            continue

        # =========================================================================
        # 【故障点拓扑识别】：在最终时刻物理场上运行带有流出边界外推的 KXRCF 探测器
        # =========================================================================
        is_troubled = detect_troubled_points_only_kxrcf(
            x_center=x_kx, rho=rho_kx, p=p_kx, gamma=gamma, threshold=KXRCF_THRESHOLD, nghost=3
        )

        total_points = len(x_kx)
        troubled_count = np.sum(is_troubled)
        print(f"[分辨率 N = {Nx}] 基于流出边界的 KXRCF 探测完成！强间断点数量: {troubled_count}/{total_points}")

        # =========================================================================
        #   【精简版学术绘图：仅包含 Reference 线 + KXRCF 数值点 + 荧光紫竖线】
        # =========================================================================
        # 1. 绘制高对比度黑色实线作为精准参考解析解 (Reference)
        line1, = ax.plot(x_exact, rho_exact, color='black', linewidth=2.5, label='Reference')

        # 2. 绘制 KXRCF 数值解：蓝色实线
        line2, = ax.plot(x_kx, rho_kx, color='blue', linewidth=2.0, label='KXRCF')

        # 3. 核心物理标记：若被探测器抓出为 troubled point，则拉起高亮荧光紫竖线
        vline_handle = None
        for i in range(total_points):
            if is_troubled[i]:
                vline_handle = ax.axvline(x=x_kx[i], color='fuchsia', linestyle='-', linewidth=0.5, alpha=0.8)

        # 只在第一个子图中收集全局图例的句柄
        if idx == 0:
            legend_handles = [line1, line2]
            legend_labels = ['Reference', 'KXRCF']


        # 坐标轴标签美化
        ax.set_xlabel(f'X\n{sub_labels[idx]} N = {Nx}', fontsize=32, labelpad=3)

        if idx == 0:
            ax.set_ylabel('Density', fontsize=32, labelpad=5)

        # =========================================================================
        # 【轴系控制标尺】：契合一维 SMCD 问题的时空域定义
        # =========================================================================
        ax.set_xlim(0.0, 1.0)
        ax.set_xticks([0.0, 0.5, 1.0])

        if idx == 0:
            ax.set_ylim(0.9, 1.5)
            ax.set_yticks([1.0, 1.2, 1.4])
            ax.tick_params(axis='both', labelsize=24, direction='in', top=True, right=True, length=6, width=1.2)
        else:
            ax.set_ylim(0.9, 1.5)
            ax.set_yticks([])
            ax.tick_params(axis='x', labelsize=24, direction='in', top=True, right=True, length=6, width=1.2)
            ax.tick_params(axis='y', direction='in', left=True, right=True, length=6, width=1.2)

    # 极致学术紧凑性版面深度收缩
    plt.tight_layout(rect=[0.09, 0, 1, 1])

    # 全局外部大图例
    fig.legend(
        handles=legend_handles,
        labels=legend_labels,
        loc='center left',
        bbox_to_anchor=(0.001, 0.85),
        ncol=1,
        fontsize=15,
        markerscale=1.8,
        handlelength=2.0,
        handletextpad=0.5,
        frameon=True,
        edgecolor='gray'
    )

    output_pdf = "1D_SLMC_KXRCF.pdf"
    plt.savefig(output_pdf, dpi=300)
    print(f"\n📊 完美的 1x3 流出边界下 KXRCF 密度与间断点图表已成功保存至: {output_pdf}")
    plt.show()


if __name__ == "__main__":
    main()