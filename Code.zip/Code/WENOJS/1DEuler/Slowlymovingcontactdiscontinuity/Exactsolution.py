import csv  # 引入标准 CSV 字典流支持
import numpy as np


def exact_solution_density(x_center, t_final=2.0):
    """
    向量化版本的精确密度解（保持您原汁原味的物理逻辑不动）
    """
    # 初始间断位置和移动速度
    x_interface_initial = 0.5
    u_contact = 0.1

    # 计算t_final时刻的间断位置
    x_interface_final = x_interface_initial + u_contact * t_final

    # 使用向量化操作
    rho_exact = np.where(x_center < x_interface_final, 1.4, 1.0)

    return rho_exact


if __name__ == '__main__':
    # 设定网格点数（根据您的多分辨率需求，分别运行生成 N = 100, 200, 400 的文件）
    for N in [100, 200, 400]:
        x_vals = np.linspace(0, 1, N + 1)
        dx = float(x_vals[1] - x_vals[0])  # 空间步长
        x_center = 0.5 * (x_vals[1:] + x_vals[:-1])  # 网格中心点坐标

        # 计算最终时刻（T=2.0）的精确解数组
        rho_exact = exact_solution_density(x_center, t_final=2.0)

        # =========================================================================
        # 【数据保存插槽】：严格将网格变量列名命名为 "x" 并导出为标准 CSV 文件
        # =========================================================================
        csv_filename = f"Exact_Density_Solution_N{N}.csv"

        print(f"正在将包含网格坐标的精确解流场写入标准表格: {csv_filename} ...")

        # 使用标准字典流 DictWriter 写入
        with open(csv_filename, mode='w', encoding='utf-8', newline='') as f:
            # 🟢 核心修改：定义后处理脚本能够无缝检索的英文字段表头，网格点坐标严格叫 "x"
            fieldnames = ["x", "Exact_solution_T"]
            writer = csv.DictWriter(f, fieldnames=fieldnames)

            # 写入标准标题行
            writer.writeheader()

            # 逐网格点将空间坐标与真实解精准按列写入
            for i in range(N):
                writer.writerow({
                    "x": float(x_center[i]),  # 🟢 严格对齐您的最新要求
                    "Exact_solution_T": float(rho_exact[i])
                })

        print(f"✅ [save] {csv_filename} 已写入！包含网格变量 'x'，方便后续绘图直接无缝加载。\n")