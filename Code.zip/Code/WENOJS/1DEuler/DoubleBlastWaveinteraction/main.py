import time
import numpy as np
import pandas as pd  # 引入 pandas 用于高阶数据表操作与 CSV 导出
import matplotlib.pyplot as plt  # 引入学术绘图库

# 保持使用你原本提供的模块结构导入
from RK3 import *
from IC import *
from helperfunction import *

gamma = 1.4


def compute_single_run(N, T_final=0.038, CFL=0.5, gamma=1.4):
    """
    一维 Euler 方程组双爆炸波问题数值计算核心推进函数（标准纯 WENO5 格式）。
    """
    x = np.linspace(0, 1, N + 1)  # 网格端点
    dx = float(x[1] - x[0])  # 空间步长
    x_center = 0.5 * (x[1:] + x[:-1])  # 网格中心
    U_center = IC(x_center)  # 初始守恒量
    t = 0.0
    iteration = 0
    dt = compute_dt(U_center, dx, CFL, gamma)

    # 【开始计时】：在时间推进循环前记录起始时间
    start_time = time.time()

    # 时间推进循环
    while t < T_final:
        if t + dt > T_final:
            dt = T_final - t

        # 调用标准纯 WENO5 求解器推进时间步
        U_center = SolverWENO5RK3(U_center, dx, dt, gamma)
        t += dt
        iteration += 1
        dt = compute_dt(U_center, dx, CFL, gamma)

        if iteration % 50 == 0:
            progress = t / T_final * 100
            print(f"迭代 {iteration:4d} | 进度 {progress:5.1f}% | t = {t:.4f}/{T_final} | dt = {dt:.4e}")

    # 【结束计时】：计算纯 WENO5 推进过程的净消耗时间
    end_time = time.time()
    cpu_time = end_time - start_time
    print(f"⏱️ 纯 WENO5 数值推进完成！总迭代步数: {iteration} 步 | 总 CPU 计算时间 = {cpu_time:.3f} 秒")

    # 转换为原始物理量
    rho_num, u_num, p_num = convert_to_primitive(U_center, gamma)

    # 返回网格中心、原始物理量、最后时刻完整的 U_center 守恒量以及计算总时间 cpu_time
    return x_center, rho_num, u_num, p_num, U_center, cpu_time


def main():
    print("=== 开始 1D 纯 WENO5 DoubleBlastWaveInteraction problem ===")
    T_final = 0.038
    N = 200
    CFL = 0.5

    # 执行核心仿真逻辑，接收返回的所有核心物理量、U_final 数组以及时间
    x_center, rho_num, u_num, p_num, U_final, cpu_time = compute_single_run(N, T_final, CFL, gamma)

    # =========================================================
    #  【数据保存】：构建 DataFrame 并将其导出为标准的 .csv 文件（严格参考 KXRCF 结构）
    # =========================================================
    data_dict = {
        'x_center': x_center,
        'rho_conserved': U_final[0, :],  # 守恒量1：密度 rho
        'rhou_conserved': U_final[1, :],  # 守恒量2：动量 rho * u
        'E_conserved': U_final[2, :],  # 守恒量3：总能量 E
        'rho_primitive': rho_num,  # 原始物理量：密度
        'u_primitive': u_num,  # 原始物理量：速度
        'p_primitive': p_num,  # 原始物理量：压力
        'CPU_time_seconds': cpu_time  # 将总计算耗时固化记录在此列中
    }

    df = pd.DataFrame(data_dict)
    filename = f"DoubleBlastWave_PureWENO5_N{N}_T{T_final:.3f}.csv"

    # index=False 表示不保存 DataFrame 自带的整型行索引
    df.to_csv(filename, index=False, encoding='utf-8')
    print(f"✅ 结果（含完整守恒量与计算时间）已成功保存至唯一 CSV 文件: {filename}")

    # =========================================================
    #  【可视化绘图】：【学术级单一密度函数快速可视化绘图展示】
    # =========================================================
    print("📊 正在绘制一维密度流场剖面图...")
    plt.figure(figsize=(8, 6))

    # 采用与 KXRCF / MLP 完全统一的经典 CFD 论文风格：蓝色实线 + 空心圆点
    plt.plot(x_center, rho_num, 'o-', color='blue', markerfacecolor='none',
             markersize=4, linewidth=1.5, label=f'Pure WENO5 (N={N})')

    plt.xlabel('x')
    plt.ylabel('rho')
    plt.xlim([0.0, 1.0])
    plt.title(f'Double Blast Wave Interaction - Pure WENO5 (t = {T_final})')
    plt.grid(True, linestyle=':', alpha=0.6)
    plt.legend(loc='best', frameon=False)
    plt.tight_layout()

    # 同步弹出交互式视窗进行实时观察
    plt.show()


if __name__ == "__main__":
    main()