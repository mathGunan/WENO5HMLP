import csv
import numpy as np
import matplotlib.pyplot as plt

'''
Post-process for Double Blast Wave Problem: 1x3 子图联合散点绘制 (WENO5-KXRCF 传统指标版)
【特征判定归一】：完全剥离神经网络！直接对 KXRCF 方案的原始流场计算无量纲熵并调用内嵌的 KXRCF 指示器重构算法。
【数据样式绝对对齐】：
  - Reference 保持黑色高对比度连续实线；
  - WENO5-KXRCF 采用纯蓝色空心圆点 (o, blue, s=40)，无任何数值连线，内部透明。
【间断标记图层】：仅在 kappa_val > KXRCF_THRESHOLD 的物理网格处拉起高亮荧光紫竖线 (linewidth=0.8)。
【全盘锁死学术轴系】：空间区间 [0.0, 1.0]，主刻度 [0.0, 0.5, 1.0]；纵轴密度 [0.0, 6.5]，主刻度 [0.0, 3.0, 6.0]。
'''


def load_euler_csv_data(filename):
    """安全读取双爆炸波仿真输出的标准 CSV 数据，返回网格中心 x_center、原始密度 rho 和压力 p"""
    x_center, rho_numerical, p_numerical = [], [], []
    try:
        with open(filename, mode='r', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            for row in reader:
                if "x_center" in row: x_center.append(float(row["x_center"]))
                elif "x" in row: x_center.append(float(row["x"]))

                if "rho_primitive" in row: rho_numerical.append(float(row["rho_primitive"]))
                elif "rho" in row: rho_numerical.append(float(row["rho"]))

                if "p_primitive" in row: p_numerical.append(float(row["p_primitive"]))
                elif "p" in row: p_numerical.append(float(row["p"]))
                else: p_numerical.append(0.0)
    except FileNotFoundError:
        print(f"❌ 警告: 未找到文件 {filename}")
        return None, None, None
    return np.array(x_center), np.array(rho_numerical), np.array(p_numerical)


def apply_reflective_bc_scalar(entropy_1d, nghost=3):
    """针对标量非线性物理熵的刚性反射墙边界条件 (镜像映射)"""
    N = len(entropy_1d)
    entropy_ext = np.zeros(N + 2 * nghost)
    entropy_ext[nghost:-nghost] = entropy_1d
    entropy_ext[:nghost] = entropy_1d[nghost - 1::-1]
    entropy_ext[-nghost:] = entropy_1d[-1:-nghost - 1:-1]
    return entropy_ext


def detect_troubled_points_only_kxrcf(x_center, rho, p, gamma=1.4, threshold=1.0, nghost=3):
    """基于双爆炸波物理反射边界条件重构的 KXRCF 问题点探测器算法"""
    N = len(rho)
    dx = x_center[1] - x_center[0]

    # 严格采用非线性标量熵，引入 1e-12 截断保护防止低压/真空报错
    entropy_physical = p / np.maximum(rho ** gamma, 1e-12)

    # 完美调用刚性两端固体反射墙边界外推机制
    entropy_ext = apply_reflective_bc_scalar(entropy_physical, nghost=nghost)

    prob_length = N + 2
    is_troubled_full = np.zeros(prob_length, dtype=bool)

    for i in range(prob_length):
        idx_ext = i + (nghost - 1)

        # 经典多项式重构计算
        u0_l = (entropy_ext[idx_ext - 2] + 22 * entropy_ext[idx_ext - 1] + entropy_ext[idx_ext]) / 24.0
        u1_l = (entropy_ext[idx_ext] - entropy_ext[idx_ext - 2]) / 2.0
        u2_l = (entropy_ext[idx_ext - 2] - 2 * entropy_ext[idx_ext - 1] + entropy_ext[idx_ext]) / 2.0

        u0_c = (entropy_ext[idx_ext - 1] + 22 * entropy_ext[idx_ext] + entropy_ext[idx_ext + 1]) / 24.0
        u1_c = (entropy_ext[idx_ext + 1] - entropy_ext[idx_ext - 1]) / 2.0
        u2_c = (entropy_ext[idx_ext - 1] - 2 * entropy_ext[idx_ext] + entropy_ext[idx_ext + 1]) / 2.0

        u0_r = (entropy_ext[idx_ext] + 22 * entropy_ext[idx_ext + 1] + entropy_ext[idx_ext + 2]) / 24.0
        u1_r = (entropy_ext[idx_ext + 2] - entropy_ext[idx_ext]) / 2.0
        u2_r = (entropy_ext[idx_ext] - 2 * entropy_ext[idx_ext + 1] + entropy_ext[idx_ext + 2]) / 2.0

        edge_R_of_L = u0_l + 0.5 * u1_l + (1.0 / 6.0) * u2_l
        edge_L_of_C = u0_c - 0.5 * u1_c + (1.0 / 6.0) * u2_c

        edge_R_of_C = u0_c + 0.5 * u1_c + (1.0 / 6.0) * u2_c
        edge_L_of_R = u0_r - 0.5 * u1_r + (1.0 / 6.0) * u2_r

        delta_left = np.abs(edge_L_of_C - edge_R_of_L)
        delta_right = np.abs(edge_L_of_R - edge_R_of_C)
        max_jump = np.max([delta_left, delta_right])

        # 结合网格尺度缩放的无量纲控制指标计算
        denominator = (dx ** 2.5) * (np.abs(entropy_ext[idx_ext]) + 1e-10)
        kappa_val = max_jump / denominator

        if kappa_val > threshold:
            is_troubled_full[i] = True

    # 精准切回核心内部物理网格单元
    return is_troubled_full[1:N + 1]


def main():
    nx_list = [100, 200, 400]
    sub_labels = ['(a)', '(b)', '(c)']
    T_final = 0.038
    gamma = 1.4
    KXRCF_THRESHOLD = 1.0  # 调整至适合双爆炸波剧烈相互作用的经典传统阈值

    try:
        data_riemann = np.load('DoubleBlastWaveInteractionProblem_WENO5_N4000_T0.04.npz', allow_pickle=True)
        x_riemann = data_riemann['x']
        rho_riemann = data_riemann['rho']
        print("✅ 成功加载 Double Blast Wave 强间断参考解数据")
    except FileNotFoundError:
        print("❌ 错误: 未能在当前目录找到参考解文件 'DoubleBlastWaveInteractionProblem_WENO5_N4000_T0.04.npz'")
        return

    fig, axes = plt.subplots(1, 3, figsize=(20, 7))
    legend_handles, legend_labels = [], []

    for idx, Nx in enumerate(nx_list):
        ax = axes[idx]
        kxrcf_file = f"DoubleBlastWave_WENO5KXRCF_Dynamic_N{Nx}_T{T_final:.3f}.csv"

        x_kx, rho_kx, p_kx = load_euler_csv_data(kxrcf_file)
        if x_kx is None:
            ax.text(0.5, 3.2, f'Data Missing\nN = {Nx}', ha='center', va='center', fontsize=16, color='red')
            continue

        # 调用内嵌的 KXRCF 指示器计算坏点
        is_troubled = detect_troubled_points_only_kxrcf(x_kx, rho_kx, p_kx, gamma, KXRCF_THRESHOLD, nghost=3)

        total_points = len(x_kx)
        print(f"[KXRCF分辨率 N = {Nx}] KXRCF探测器捕捉到的间断坏点数量: {np.sum(is_troubled)}/{total_points}")

        # 1. 精确参考解：保持高对比度黑色连续实线
        line1, = ax.plot(x_riemann, rho_riemann, color='black', linewidth=2.5, zorder=1, label='Reference')

        # 2. 数值解采用蓝色实线绘制
        line2, = ax.plot(x_kx, rho_kx, color='blue', linewidth=2.0, label='KXRCF')

        # 3. 核心物理标记：在判定为间断的位置拉起高亮荧光紫竖线
        for i in range(total_points):
            if is_troubled[i]:
                ax.axvline(x=x_kx[i], color='fuchsia', linestyle='-', linewidth=0.8, alpha=0.8, zorder=3)

        if idx == 0:
            legend_handles = [line1, line2]
            legend_labels = ['Reference', 'KXRCF']

        ax.set_xlabel(f'X\n{sub_labels[idx]} N = {Nx}', fontsize=32, labelpad=3)
        if idx == 0: ax.set_ylabel('Density', fontsize=32, labelpad=5)

        # 轴系物理范围硬核控制
        ax.set_xlim(0.0, 1.0)
        ax.set_xticks([0.0, 0.5, 1.0])
        ax.set_ylim(0.0, 6.5)
        if idx == 0:
            ax.set_ylim(0.0, 6.5)
            ax.set_yticks([0.0, 3.0, 6.0])
            # 🟢 通过加入 pad=12 整体拉开刻度数字与坐标轴的间距，彻底消除原点重叠
            ax.tick_params(axis='both', labelsize=24, direction='in', top=True, right=True, length=6, width=1.2, pad=12)
        else:
            ax.set_ylim(0.0, 6.5)
            ax.set_yticks([])
            # 🟢 为了让 1x3 大图的三个子图底部 X 轴标签保持完美视觉水平对齐，中、右子图的 pad 也要同步调到 12
            ax.tick_params(axis='x', labelsize=24, direction='in', top=True, right=True, length=6, width=1.2, pad=12)
            ax.tick_params(axis='y', direction='in', left=True, right=True, length=6, width=1.2)

    plt.tight_layout(rect=[0.09, 0, 1, 1])
    fig.legend(handles=legend_handles, labels=legend_labels, loc='center left', bbox_to_anchor=(0.001, 0.85),
               ncol=1, fontsize=15, markerscale=1.2, handlelength=2.0, handletextpad=0.5, frameon=True, edgecolor='gray')

    output_pdf = "1D_DoubleBlastWave_KXRCF.pdf"
    plt.savefig(output_pdf, dpi=300)
    print(f"📊 KXRCF 传统物理检测器对比图已成功保存至: {output_pdf}")
    plt.show()


if __name__ == "__main__":
    main()