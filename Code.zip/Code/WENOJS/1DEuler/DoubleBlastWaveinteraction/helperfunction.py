from model import *
#守恒量转换为底层变量.即把质量（密度），动量和能量转换为密度，速度和压力
def convert_to_primitive(U, gamma):
    """将守恒变量转换为原始变量"""
    rho = U[0, :]
    # 防止除零错误
    rho_safe = np.where(rho <= 0, 1e-14, rho)
    u_vel = U[1, :] / rho_safe
    E = U[2, :]
    p = (gamma - 1) * (E - 0.5 * rho * u_vel**2)
    # 防止负压
    p = np.maximum(p, 1e-14)
    return rho, u_vel, p


def predict(entropy_with_bc, dx, model, device):
    """
    接口级别预测 trouble 点概率（针对每个网格点计算特征，输入切换为单通道标量物理熵）

    参数:
        entropy_with_bc: ndarray, shape (N_ext,)
                         已包含 ghost cell 的全流场标量物理熵 S
        dx             : 网格间距
        model          : 已训练的 MLP 模型
        device         : torch.device
    返回:
        prob_output    : ndarray, shape (N+2,)
                         一维判定概率，代表各个网格位置是否为 troubled-point
    """
    N_ext = entropy_with_bc.shape[0]
    N = N_ext - 6  # 实际物理单元数 (假设外围依旧保留 3 层 ghost cells, 即 2*nghost)

    # 构造特征输入矩阵，大小为 (N+2, 4)
    input_arrays = np.zeros((N + 2, 4), dtype=np.float32)

    # 遍历空间位置（保持你原本完美的索引范围映射）
    for i in range(2, N + 4):
        stencil = entropy_with_bc[i - 2:i + 3]  # 基于物理熵的五点 stencil

        # 计算 WENO 经典光滑指标
        beta0 = (13 * (stencil[2] - 2 * stencil[3] + stencil[4]) ** 2 + 3 * (
                3 * stencil[2] - 4 * stencil[3] + stencil[4]) ** 2) / 12
        beta1 = (13 * (stencil[1] - 2 * stencil[2] + stencil[3]) ** 2 + 3 * (stencil[1] - stencil[3]) ** 2) / 12
        beta2 = (13 * (stencil[0] - 2 * stencil[1] + stencil[2]) ** 2 + 3 * (
                stencil[0] - 4 * stencil[1] + 3 * stencil[2]) ** 2) / 12

        betaA = min(beta0, beta1, beta2)
        betaM = (beta0 + beta1 + beta2) / 3
        Tau5 = abs(beta0 - beta2)

        # 写入该位置的特征向量
        input_arrays[i - 2] = [betaA, betaM, Tau5, dx]

    # 模型统一前向预测
    input_tensor = torch.from_numpy(input_arrays).to(device)
    with torch.no_grad():
        # 模型输出后通过 flatten 压缩为一维形状 (N+2,)
        prob_output = model(input_tensor).cpu().numpy().flatten()

    return prob_output






# get_model 函数
def get_model(ckpt_path, device_str='auto'):
    """
    加载已训练的 WENO5 FDM MLP 模型
    优先顺序：MPS > CUDA > CPU
    """
    if device_str == 'auto':
        if torch.backends.mps.is_available():
            device = torch.device('mps')
        elif torch.cuda.is_available():
            device = torch.device('cuda')
        else:
            device = torch.device('cpu')
    else:
        device = torch.device(device_str)

    model = Weno5FDMMLP().to(device)
    ckpt = torch.load(ckpt_path, map_location=device)
    model.load_state_dict(ckpt['model_state_dict'])
    model.eval()
    return model, device


'''时间步长计算函数，U用的是尚未应用边界条件的U'''
def compute_dt(u_phys, dx, CFL, gamma):
    rho = np.maximum(u_phys[0, :], 1e-14)
    u = u_phys[1, :] / rho
    p = np.maximum((gamma - 1.0) * (u_phys[2, :] - 0.5 * rho * u ** 2), 1e-14)
    a = np.sqrt(gamma * p / rho)
    dt=CFL * dx / np.max(np.abs(u) + a)
    # print('dt=', dt)
    return dt