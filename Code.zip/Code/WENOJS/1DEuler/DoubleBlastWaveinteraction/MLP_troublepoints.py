import csv
import numpy as np
import matplotlib.pyplot as plt
import torch
import torch.nn as nn

# 完美对接您的专用函数模块
from BC import *
from helperfunction import *

'''
Post-process for Double Blast Wave Problem: 1x3 子图联合散点绘制 (WENO5-H-MLP 专属版)
【数据样式绝对对齐】：
  - Reference 保持黑色高对比度连续实线；
  - WENO5-H-MLP 采用纯红色空心正方形 (s, red, s=40)，无任何数值连线，内部透明。
【间断点检测判定】：基于 MLP 物理流场计算无量纲熵并外推反射边界，概率 <= P_threshold 时拉起荧光紫竖线。
【全盘锁死学术轴系】：空间区间 [0.0, 1.0]，主刻度 [0.0, 0.5, 1.0]；纵轴密度 [0.0, 6.5]，主刻度 [0.0, 3.0, 6.0]。
'''


def load_euler_csv_data(filename):
    """安全读取双爆炸波仿真输出的标准 CSV 数据"""
    x_center, rho_numerical, p_numerical = [], [], []
    try:
        with open(filename, mode='r', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            for row in reader:
                if "x_center" in row: x_center.append(float(row["x_center"]))
                elif "x" in row: x_center.append(float(row["x"]))

                if "rho_primitive" in row: rho_numerical.append(float(row["rho_primitive"]))
                elif "rho" in row: rho_numerical.append(float(row["rho"]))

                if "p_primitive" in row: p_numerical.append(float(row["p_primitive"]))
                elif "p" in row: p_numerical.append(float(row["p"]))
                else: p_numerical.append(0.0)
    except FileNotFoundError:
        print(f"❌ 警告: 未找到文件 {filename}")
        return None, None, None
    return np.array(x_center), np.array(rho_numerical), np.array(p_numerical)


def apply_reflective_bc_scalar(entropy_1d, nghost=3):
    """针对标量非线性物理熵的刚性反射墙边界条件 (镜像映射)"""
    N = len(entropy_1d)
    entropy_ext = np.zeros(N + 2 * nghost)
    entropy_ext[nghost:-nghost] = entropy_1d
    entropy_ext[:nghost] = entropy_1d[nghost - 1::-1]
    entropy_ext[-nghost:] = entropy_1d[-1:-nghost - 1:-1]
    return entropy_ext


def main():
    nx_list = [100, 200, 400]
    sub_labels = ['(a)', '(b)', '(c)']
    T_final = 0.038
    gamma = 1.4

    ckpt_path = "best_model.pth"
    P_threshold = 0.5
    nghost = 3

    try:
        model, device = get_model(ckpt_path, device_str='auto')
        print(f"✅ 成功加载神经网络权重模型，当前计算设备：{device}")
    except FileNotFoundError:
        print(f"❌ 错误: 未能在路径找到模型文件 '{ckpt_path}'")
        return

    try:
        data_riemann = np.load('DoubleBlastWaveInteractionProblem_WENO5_N4000_T0.04.npz', allow_pickle=True)
        x_riemann = data_riemann['x']
        rho_riemann = data_riemann['rho']
        print("✅ 成功加载 Double Blast Wave 强间断参考解数据")
    except FileNotFoundError:
        print("❌ 错误: 未能在当前目录找到参考解文件 'DoubleBlastWaveInteractionProblem_WENO5_N4000_T0.04.npz'")
        return

    fig, axes = plt.subplots(1, 3, figsize=(20, 7), dpi=300)
    legend_handles, legend_labels = [], []

    for idx, Nx in enumerate(nx_list):
        ax = axes[idx]
        mlp_file = f"DoubleBlastWave_WENO5MLP_Dynamic_N{Nx}_T{T_final:.3f}.csv"

        x_mlp, rho_mlp, p_mlp = load_euler_csv_data(mlp_file)
        if x_mlp is None:
            ax.text(0.5, 3.2, f'Data Missing\nN = {Nx}', ha='center', va='center', fontsize=16, color='red')
            continue

        # 特征提取与推理验证
        dx = float(x_mlp[1] - x_mlp[0])
        entropy_physical = p_mlp / np.maximum(rho_mlp ** gamma, 1e-12)
        entropy_with_bc = apply_reflective_bc_scalar(entropy_physical, nghost=nghost)
        prob_1d = predict(entropy_with_bc, dx, model, device)

        is_troubled_physical = (prob_1d <= P_threshold)[1:Nx + 1]
        total_points = len(x_mlp)
        print(f"[分辨率 N = {Nx}] MLP 坏点数量: {np.sum(is_troubled_physical)}/{total_points}")

        # 学术绘图面层
        line1, = ax.plot(x_riemann, rho_riemann, color='black', linewidth=2.5, zorder=1, label='Reference')

        # 2. 数值解采用红色连续实线绘制
        line2, = ax.plot(x_mlp, rho_mlp, color='red', linewidth=2.0, label='WENO5-H-MLP')

        for i in range(total_points):
            if is_troubled_physical[i]:
                ax.axvline(x=x_mlp[i], color='fuchsia', linestyle='-', linewidth=0.5, alpha=0.8, zorder=3)

        if idx == 0:
            legend_handles = [line1, line2]
            legend_labels = ['Reference', 'WENO5-H-MLP']

        ax.set_xlabel(f'X\n{sub_labels[idx]} N = {Nx}', fontsize=32, labelpad=3)
        if idx == 0: ax.set_ylabel('Density', fontsize=32, labelpad=5)

        ax.set_xlim(0.0, 1.0)
        ax.set_xticks([0.0, 0.5, 1.0])
        ax.set_ylim(0.0, 6.5)
        if idx == 0:
            ax.set_ylim(0.0, 6.5)
            ax.set_yticks([0.0, 3.0, 6.0])
            # 🟢 通过加入 pad=12 整体拉开刻度数字与坐标轴的间距，彻底消除原点重叠
            ax.tick_params(axis='both', labelsize=24, direction='in', top=True, right=True, length=6, width=1.2, pad=12)
        else:
            ax.set_ylim(0.0, 6.5)
            ax.set_yticks([])
            # 🟢 为了让 1x3 大图的三个子图底部 X 轴标签保持完美视觉水平对齐，中、右子图的 pad 也要同步调到 12
            ax.tick_params(axis='x', labelsize=24, direction='in', top=True, right=True, length=6, width=1.2, pad=12)
            ax.tick_params(axis='y', direction='in', left=True, right=True, length=6, width=1.2)


    plt.tight_layout(rect=[0.09, 0, 1, 1])
    fig.legend(handles=legend_handles, labels=legend_labels, loc='center left', bbox_to_anchor=(0.001, 0.85),
               ncol=1, fontsize=15, markerscale=1.2, handlelength=2.0, handletextpad=0.5, frameon=True, edgecolor='gray')

    output_pdf = "1D_DoubleBlastWave_MLP.pdf"
    plt.savefig(output_pdf, dpi=300)
    print(f"📊 MLP 专属离散对比图已成功导出至: {output_pdf}")
    plt.show()


if __name__ == "__main__":
    main()