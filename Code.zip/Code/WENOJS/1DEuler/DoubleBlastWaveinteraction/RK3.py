from RoeFlux import *
from BC import *

'''在内部应用边界条件，输入的解是真实物理界面上的解'''
def SolverWENO5RK3(u_phys, dx, dt, gamma, nghost=3):
    """
    1D Euler 方程 WENO5 + RK3 时间推进（外部处理周期边界）

    Parameters
    ----------
    u_phys : ndarray, shape (3, N)
        当前时刻的物理区守恒变量（不含 ghost cells）
    dx : float
        网格间距
    dt : float
        时间步长
    gamma : float
        比热比
    nghost : int
        ghost cell 数量，默认 3

    Returns
    -------
    u_phys_next : ndarray, shape (3, N)
        下一个时刻物理区守恒变量
    """
    # 在外部扩展 ghost cells
    u_ext = apply_reflective_bc(u_phys, nghost)

    def rhs(U_ext):
        # compute_rhs_1d 接受带 ghost cell 的 U_ext
        return compute_rhs_1d(U_ext, dx, gamma, nghost)

    # ---- RK3 第一步 ----
    k1 = rhs(u_ext)
    u1 = u_phys + dt * k1

    # ---- RK3 第二步 ----
    u_ext1 = apply_reflective_bc(u1, nghost)
    k2 = rhs(u_ext1)
    u2 = 0.75 * u_phys + 0.25 * (u1 + dt * k2)

    # ---- RK3 第三步 ----
    u_ext2 = apply_reflective_bc(u2, nghost)
    k3 = rhs(u_ext2)
    u_phys_next = (1.0 / 3.0) * u_phys + (2.0 / 3.0) * (u2 + dt * k3)

    return u_phys_next


def SolverWenoMLPRK3(u_phys, dx, dt, gamma, model, device, P=None, nghost=3):
    u_ext = apply_reflective_bc(u_phys, nghost)

    def rhs(U_ext):
        return compute_rhs_1d_with_MLP(
            U_ext=U_ext,
            dx=dx,
            model=model,
            device=device,
            gamma=gamma,
            P=P,
            nghost=nghost
        )

    # ---------- RK3 Stage 1 ----------
    k1 = rhs(u_ext)
    u1 = u_phys + dt * k1

    # ---------- RK3 Stage 2 ----------
    u_ext1 = apply_reflective_bc(u1, nghost)
    k2 = rhs(u_ext1)
    u2 = 0.75 * u_phys + 0.25 * (u1 + dt * k2)

    # ---------- RK3 Stage 3 ----------
    u_ext2 = apply_reflective_bc(u2, nghost)
    k3 = rhs(u_ext2)
    u_phys_next = (1.0 / 3.0) * u_phys + (2.0 / 3.0) * (u2 + dt * k3)

    return u_phys_next

def SolverWenoKXRCFRK3(u_phys, dx, dt, gamma, threshold=1.0, nghost=3):
    """
    动态 KXRCF-WENO5 RK3 推进器：每个子步内部都会重新调用你写的 compute_rhs_1d_with_KXRCF
    """
    # ---------- RK3 Stage 1 ----------
    u_ext = apply_reflective_bc(u_phys, nghost)  # 以双爆炸波反射边界为例
    k1 = compute_rhs_1d_with_KXRCF(u_ext, dx, gamma, threshold, nghost)
    u1 = u_phys + dt * k1

    # ---------- RK3 Stage 2 ----------
    u_ext1 = apply_reflective_bc(u1, nghost)
    k2 = compute_rhs_1d_with_KXRCF(u_ext1, dx, gamma, threshold, nghost)
    u2 = 0.75 * u_phys + 0.25 * (u1 + dt * k2)

    # ---------- RK3 Stage 3 ----------
    u_ext2 = apply_reflective_bc(u2, nghost)
    k3 = compute_rhs_1d_with_KXRCF(u_ext2, dx, gamma, threshold, nghost)
    u_phys_next = (1.0 / 3.0) * u_phys + (2.0 / 3.0) * (u2 + dt * k3)

    return u_phys_next