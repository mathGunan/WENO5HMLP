import csv
import numpy as np
import matplotlib.pyplot as plt

'''
Joint Post-process for Double Blast Wave Problem: 1x3 子图联合绘制 (N = 100, 200, 400)
【数据样式绝对对齐】：
  - Reference 保持黑色高对比度连续实线；
  - WENO5 采用纯绿色空心上三角点 (^, forestgreen, s=40)；
  - KXRCF 采用纯蓝色空心圆点 (o, blue, s=40)；
  - WENO5-H-MLP 采用纯红色空心正方形 (s, red, s=40)；
  - 全盘废除连线，内部全部透明 (facecolors='none')。
【全盘锁死学术轴系】：空间区间 [0.0, 1.0]，主刻度 [0.0, 0.5, 1.0]；纵轴密度 [0.0, 6.5]，主刻度 [0.0, 3.0, 6.0]。
'''


def load_euler_csv_data(filename):
    """
    安全读取双爆炸波仿真输出的标准 CSV 数据，返回网格中心 x_center 和原始密度 rho_primitive
    """
    x_center = []
    rho_numerical = []

    try:
        with open(filename, mode='r', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            for row in reader:
                if "x_center" in row:
                    x_center.append(float(row["x_center"]))
                elif "x" in row:
                    x_center.append(float(row["x"]))

                if "rho_primitive" in row:
                    rho_numerical.append(float(row["rho_primitive"]))
                elif "rho" in row:
                    rho_numerical.append(float(row["rho"]))
    except FileNotFoundError:
        print(f"❌ 警告: 未找到文件 {filename}")
        return None, None

    return np.array(x_center), np.array(rho_numerical)


def main():
    # 定义需要对比的三个网格分辨率
    nx_list = [100, 200, 400]
    sub_labels = ['(a)', '(b)', '(c)']
    T_final = 0.038  # 严格匹配您主程序导出的三位小数规范

    # 加载高分辨率参考解数据 (T=0.04)
    try:
        data_riemann = np.load('DoubleBlastWaveInteractionProblem_WENO5_N4000_T0.04.npz', allow_pickle=True)
        x_riemann = data_riemann['x']
        rho_riemann = data_riemann['rho']
        print("✅ 成功加载 Double Blast Wave 强间断参考解数据 (N=4000, T=0.04)")
    except FileNotFoundError:
        print("❌ 错误: 未能在当前目录找到参考解文件 'DoubleBlastWaveInteractionProblem_WENO5_N4000_T0.04.npz'")
        return

    # 初始化标准的 1x3 学术画布
    fig, axes = plt.subplots(1, 3, figsize=(20, 7), dpi=300)
    legend_handles = []
    legend_labels = []

    for idx, Nx in enumerate(nx_list):
        ax = axes[idx]

        # 数据文件名路由归一化
        weno5_file = f"DoubleBlastWave_PureWENO5_N{Nx}_T{T_final:.3f}.csv"
        kxrcf_file = f"DoubleBlastWave_WENO5KXRCF_Dynamic_N{Nx}_T{T_final:.3f}.csv"
        mlp_file   = f"DoubleBlastWave_WENO5MLP_Dynamic_N{Nx}_T{T_final:.3f}.csv"

        # 安全加载底层物理流场数据
        x_weno, rho_weno = load_euler_csv_data(weno5_file)
        x_kx,   rho_kx   = load_euler_csv_data(kxrcf_file)
        x_mlp,  rho_mlp  = load_euler_csv_data(mlp_file)

        # 健壮性检查
        if x_weno is None or x_mlp is None or x_kx is None:
            ax.text(0.5, 3.2, f'Data Missing\nN = {Nx}', ha='center', va='center', fontsize=16, color='red')
            continue

        # 1. 精确参考解：保持高对比度黑色连续实线 (Reference)
        line1, = ax.plot(x_riemann, rho_riemann, color='black', linewidth=2.5, linestyle='-', zorder=1, label='Reference')

        # 🟢 【核心逻辑注入】：严格执行您指定的 ax.scatter 学术离散散点机制
        # 2. Pure WENO5 数值解：纯绿色空心上三角点 (s=40)
        scat1 = ax.scatter(x_weno, rho_weno, marker='^', edgecolors='forestgreen', facecolors='none',
                           s=40, linewidths=1.0, zorder=2, label='WENO5')

        # 3. KXRCF 数值解：纯蓝色空心圆点 (s=40)
        scat2 = ax.scatter(x_kx, rho_kx, marker='o', edgecolors='blue', facecolors='none',
                           s=40, linewidths=1.0, zorder=3, label='KXRCF')

        # 4. WENO5-H-MLP 数值解：纯红色空心正方形 (s=40)
        scat3 = ax.scatter(x_mlp, rho_mlp, marker='s', edgecolors='red', facecolors='none',
                           s=40, linewidths=1.0, zorder=4, label='WENO5-H-MLP')

        # 严格对齐图例逻辑：仅在最左侧第一个子图中抓取核心句柄，避免重复
        if idx == 0:
            legend_handles = [line1, scat1, scat2, scat3]
            legend_labels = ['Reference', 'WENO5', 'KXRCF', 'WENO5-H-MLP']

        # 坐标轴标签与子图学术编号美化
        ax.set_xlabel(f'X\n{sub_labels[idx]} N = {Nx}', fontsize=32, labelpad=3)
        if idx == 0:
            ax.set_ylabel('Density', fontsize=32, labelpad=5)

        # =========================================================================
        # 【物理轴系控制标尺】：完美锁死双爆炸波相互作用问题的标准物理区间
        # =========================================================================
        ax.set_xlim(0.0, 1.0)
        ax.set_xticks([0.0, 0.5, 1.0])

        if idx == 0:
            ax.set_ylim(0.0, 6.5)
            ax.set_yticks([0.0, 3.0, 6.0])
            # 🟢 通过加入 pad=12 整体拉开刻度数字与坐标轴的间距，彻底消除原点重叠
            ax.tick_params(axis='both', labelsize=24, direction='in', top=True, right=True, length=6, width=1.2, pad=12)
        else:
            ax.set_ylim(0.0, 6.5)
            ax.set_yticks([])
            # 🟢 为了让 1x3 大图的三个子图底部 X 轴标签保持完美视觉水平对齐，中、右子图的 pad 也要同步调到 12
            ax.tick_params(axis='x', labelsize=24, direction='in', top=True, right=True, length=6, width=1.2, pad=12)
            ax.tick_params(axis='y', direction='in', left=True, right=True, length=6, width=1.2)

    # 精密留白收缩至 0.05
    plt.tight_layout(rect=[0.09, 0, 1, 1])

    # 全局外部大图例：垂直挂靠在画布极左边缘外侧
    fig.legend(handles=legend_handles, labels=legend_labels, loc='center left', bbox_to_anchor=(0.001, 0.85),
               ncol=1, fontsize=15, markerscale=1.2, handlelength=2.0, handletextpad=0.5, frameon=True, edgecolor='gray')

    # 保存为用于 JCP 期刊论文排版的高清矢量图 PDF
    output_pdf = "1D_DoubleBlastWave_Compare.pdf"
    plt.savefig(output_pdf, dpi=300)
    print(f"\n物理图层与不同散点Marker完全吻合！高清对比 PDF 已成功导出至: {output_pdf}")
    plt.show()


if __name__ == "__main__":
    main()