import numpy as np
#反射边界条件，ok
def apply_reflective_bc(U, nghost=3):
    n_vars, N = U.shape
    U_ext = np.zeros((n_vars, N + 2 * nghost))
    # 内部区
    U_ext[:, nghost:-nghost] = U

    # 左边界反射: mirror about x=0
    U_ext[0, :nghost] = U[0, nghost-1::-1]        # 密度对称
    U_ext[1, :nghost] = -U[1, nghost-1::-1]       # 动量反对称
    U_ext[2, :nghost] = U[2, nghost-1::-1]        # 能量对称

    # 右边界反射: mirror about x=L
    U_ext[0, -nghost:] = U[0, -1:-nghost-1:-1]    # 密度对称
    U_ext[1, -nghost:] = -U[1, -1:-nghost-1:-1]   # 动量反对称
    U_ext[2, -nghost:] = U[2, -1:-nghost-1:-1]    # 能量对称

    return U_ext

