from RK3 import *
from IC import *
from helperfunction import *

gamma = 1.4

def compute_single_run(N, T_final=0.038, CFL=0.5,gamma = 1.4):
    x = np.linspace(0,1, N + 1)     # 网格端点
    dx = float(x[1] - x[0])                 #空间步长
    x_center = 0.5 * (x[1:] + x[:-1])     # 网格中心
    U_center = IC(x_center)               # 初始守恒量
    t = 0.0
    iteration = 0
    dt=compute_dt(U_center, dx, CFL, gamma)
    # 时间推进
    while t < T_final:
        if t + dt > T_final:
            dt = T_final - t
        U_center = SolverWENO5RK3(U_center,dx, dt, gamma)
        t += dt
        iteration += 1
        dt = compute_dt(U_center, dx, CFL, gamma)

        if iteration % 50 == 0:
            progress = t / T_final * 100
            print(f"迭代 {iteration:4d} | 进度 {progress:5.1f}% | t = {t:.4f}/{T_final} | dt = {dt:.4e}")

    rho_num, u_num, p_num = convert_to_primitive(U_center, gamma)

    return x_center, rho_num, u_num, p_num


def main():
    print("=== 开始 1D WENO5 DoubleBlastWaveInteraction problem ===")
    T_final = 0.038
    N=4000
    CFL = 0.5

    # 获取最终时刻的密度、速度、压力
    x_center, rho_num, u_num, p_num = compute_single_run(N, T_final, CFL)

    # 保存所有数据
    filename = f"DoubleBlastWaveInteractionProblem_WENO5_N{N}_T{T_final:.2f}.npz"
    np.savez(
        filename,
        x=x_center,
        rho=rho_num,
        u=u_num,
        p=p_num,
    )
    print(f"✅ 最终时刻解已保存至 {filename}")


if __name__ == "__main__":
    main()





