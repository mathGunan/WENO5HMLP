import numpy as np


def IC(x):
    """
    双爆轰波相互作用问题初始条件
    计算域: [0, 1]

    参数:
        x: 网格中心坐标数组，范围 [0, 1]

    返回:
        U: 守恒变量数组 (3, N)
    """
    n = len(x)
    U = np.zeros((3, n))
    gamma = 1.4

    for i in range(n):
        if x[i] < 0.1:
            # 左端高压区: x ∈ [0, 0.1)
            rho = 1.0
            u = 0.0
            P = 1000.0
        elif x[i] < 0.9:
            # 中间低压区: x ∈ [0.1, 0.9)
            rho = 1.0
            u = 0.0
            P = 0.01
        else:
            # 右端中压区: x ∈ [0.9, 1]
            rho = 1.0
            u = 0.0
            P = 100.0

        # 总能量
        E = P / (gamma - 1) + 0.5 * rho * u ** 2

        U[0, i] = rho  # 密度
        U[1, i] = rho * u  # 动量
        U[2, i] = E  # 总能量

    return U