import csv
import numpy as np
import matplotlib.pyplot as plt
import torch
import torch.nn as nn

# 完美对接您的专用函数模块与边界条件
from BC import *
from helperfunction import *


def load_euler_csv_data(filename):
    """
    安全读取标准 CSV 数据，返回网格中心坐标 x、密度 rho 和压力 p
    """
    x_center = []
    rho_numerical = []
    p_numerical = []
    try:
        with open(filename, mode='r', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            for row in reader:
                if "x" in row:
                    x_center.append(float(row["x"]))
                elif "x_center" in row:
                    x_center.append(float(row["x_center"]))

                if "rho" in row:
                    rho_numerical.append(float(row["rho"]))
                elif "Exact_solution_T" in row:
                    rho_numerical.append(float(row["Exact_solution_T"]))

                if "p" in row:
                    p_numerical.append(float(row["p"]))
                else:
                    p_numerical.append(0.0)
    except FileNotFoundError:
        print(f"❌ 警告: 未找到文件 {filename}")
        return None, None, None
    return np.array(x_center), np.array(rho_numerical), np.array(p_numerical)


def main():
    # 三种目标网格分辨率
    nx_list = [100, 200, 400]
    # 3x3 子图的学术标签 (a) 到 (i)
    sub_labels = [
        ['(a)', '(b)', '(c)'],  # Row 1: SLMC
        ['(d)', '(e)', '(f)'],  # Row 2: Lax
        ['(g)', '(h)', '(i)']  # Row 3: Sod
    ]
    gamma = 1.4

    # 🟢 神经网络模型核心配置项
    ckpt_path = "best_model.pth"
    P_threshold = 0.5  # 划分光滑与间断的临界阈值
    nghost = 3

    try:
        model, device = get_model(ckpt_path, device_str='auto')
        print(f"✅ 成功加载神经网络权重模型，当前计算设备：{device}")
    except FileNotFoundError:
        print(f"❌ 错误: 未能在路径找到模型文件 '{ckpt_path}'，请检查工作路径。")
        return

    # 创建 3x3 超高清晰度学术画布
    fig, axes = plt.subplots(3, 3, figsize=(20, 18))

    legend_handles = []
    legend_labels = []

    # =========================================================================
    # ROW 1: SLMC Problem
    # =========================================================================
    T_slmc = 2.0000
    for idx, Nx in enumerate(nx_list):
        ax = axes[0, idx]
        exact_file = f"Slowlymovingcontactdiscontinuity/Exact_Density_Solution_N{Nx}.csv"
        mlp_file = f"Slowlymovingcontactdiscontinuity/SMCDProblem_WENO5MLP_N{Nx}_T{T_slmc:.4f}.csv"

        x_exact, rho_exact, _ = load_euler_csv_data(exact_file)
        x_mlp, rho_mlp, p_mlp = load_euler_csv_data(mlp_file)

        if x_exact is not None and x_mlp is not None:
            line1, = ax.plot(x_exact, rho_exact, color='black', linewidth=2.5, label='Reference')
            line2, = ax.plot(x_mlp, rho_mlp, color='red', linewidth=2.0, label='WENO5-H-MLP')

            # 特征提取与特征模型推理检测
            dx = float(x_mlp[1] - x_mlp[0])
            entropy_physical = p_mlp / np.maximum(rho_mlp ** gamma, 1e-12)
            entropy_ext_2d = apply_outflow_bc(entropy_physical[np.newaxis, :], nghost=nghost)
            prob_1d = predict(entropy_ext_2d[0, :], dx, model, device)

            is_troubled_physical = (prob_1d <= P_threshold)[1:Nx + 1]

            # 🟢 统计问题点数量与百分比
            troubled_count = np.sum(is_troubled_physical)
            troubled_percentage = (troubled_count / Nx) * 100
            print(f"🔍 [SLMC] N = {Nx} -> 问题点识别数量: {troubled_count}, 占比: {troubled_percentage:.2f}%")

            # 动态绘制荧光紫间断检测竖线
            for i in range(len(x_mlp)):
                if is_troubled_physical[i]:
                    ax.axvline(x=x_mlp[i], color='fuchsia', linestyle='-', linewidth=0.9, alpha=0.8)

            if not legend_handles:
                legend_handles = [line1, line2]
                legend_labels = ['Reference', 'WENO5-H-MLP']

        # 轴系区间锁定
        ax.set_xlim(0.0, 1.0)
        ax.set_xticks([0.0, 0.5, 1.0])
        ax.set_ylim(0.9, 1.5)

        ax.set_xlabel(f'X\n{sub_labels[0][idx]} SLMC (N = {Nx})', fontsize=30, labelpad=5)
        if idx == 0:
            ax.set_ylabel('Density', fontsize=30, labelpad=5)
            ax.set_yticks([1.0, 1.2, 1.4])
            ax.tick_params(axis='both', labelsize=28, direction='in', top=True, right=True, length=6, width=1.2, pad=12)
        else:
            ax.set_yticks([])
            ax.tick_params(axis='both', labelsize=28, direction='in', top=True, right=True, left=True, length=6,
                           width=1.2, pad=12)
            ax.tick_params(axis='y', labelleft=False)

    # =========================================================================
    # ROW 2: LAX Problem
    # =========================================================================
    T_lax = 1.30
    try:
        data_lax = np.load('Laxproblem/riemann_solution.npz')
        x_lax_ref = data_lax['x']
        rho_lax_ref = data_lax['rho']
    except FileNotFoundError:
        print("❌ 错误: 未找到 Lax 参考解 'Laxproblem/riemann_solution.npz'")
        x_lax_ref, rho_lax_ref = None, None

    for idx, Nx in enumerate(nx_list):
        ax = axes[1, idx]
        # 🟢 文件名内部前缀完美对齐为 LaxProblem_...
        mlp_file = f"Laxproblem/LaxProblem_WENO5MLP_N{Nx}_T{T_lax:.2f}.csv"

        x_mlp, rho_mlp, p_mlp = load_euler_csv_data(mlp_file)

        if x_lax_ref is not None and x_mlp is not None:
            ax.plot(x_lax_ref, rho_lax_ref, color='black', linewidth=2.5)
            ax.plot(x_mlp, rho_mlp, color='red', linewidth=2.0)

            # 特征提取与模型推理检测
            dx = float(x_mlp[1] - x_mlp[0])
            entropy_physical = p_mlp / np.maximum(rho_mlp ** gamma, 1e-12)
            entropy_ext_2d = apply_outflow_bc(entropy_physical[np.newaxis, :], nghost=nghost)
            prob_1d = predict(entropy_ext_2d[0, :], dx, model, device)

            is_troubled_physical = (prob_1d <= P_threshold)[1:Nx + 1]

            # 🟢 统计问题点数量与百分比
            troubled_count = np.sum(is_troubled_physical)
            troubled_percentage = (troubled_count / Nx) * 100
            print(f"🔍 [Lax]  N = {Nx} -> 问题点识别数量: {troubled_count}, 占比: {troubled_percentage:.2f}%")

            for i in range(len(x_mlp)):
                if is_troubled_physical[i]:
                    ax.axvline(x=x_mlp[i], color='fuchsia', linestyle='-', linewidth=0.9, alpha=0.8)

        # 轴系区间锁定
        ax.set_xlim(-5.0, 5.0)
        ax.set_xticks([-5.0, 0.0, 5.0])
        ax.set_ylim(0.2, 1.4)

        ax.set_xlabel(f'X\n{sub_labels[1][idx]} Lax (N = {Nx})', fontsize=30, labelpad=5)
        if idx == 0:
            ax.set_ylabel('Density', fontsize=30, labelpad=5)
            ax.set_yticks([0.4, 0.8, 1.2])
            ax.tick_params(axis='both', labelsize=28, direction='in', top=True, right=True, length=6, width=1.2, pad=12)
        else:
            ax.set_yticks([])
            ax.tick_params(axis='both', labelsize=28, direction='in', top=True, right=True, left=True, length=6,
                           width=1.2, pad=12)
            ax.tick_params(axis='y', labelleft=False)

    # =========================================================================
    # ROW 3: SOD Problem
    # =========================================================================
    T_sod = 2.00
    try:
        data_sod = np.load('Sodproblem/riemann_solution.npz')
        x_sod_ref = data_sod['x']
        rho_sod_ref = data_sod['rho']
    except FileNotFoundError:
        print("❌ 错误: 未找到 Sod 参考解 'Sodproblem/riemann_solution.npz'")
        x_sod_ref, rho_sod_ref = None, None

    for idx, Nx in enumerate(nx_list):
        ax = axes[2, idx]
        # 🟢 文件名内部前缀完美对齐为 SodProblem_...
        mlp_file = f"Sodproblem/SodProblem_WENO5MLP_N{Nx}_T{T_sod:.2f}.csv"

        x_mlp, rho_mlp, p_mlp = load_euler_csv_data(mlp_file)

        if x_sod_ref is not None and x_mlp is not None:
            ax.plot(x_sod_ref, rho_sod_ref, color='black', linewidth=2.5)
            ax.plot(x_mlp, rho_mlp, color='red', linewidth=2.0)

            # 特征提取与模型推理检测
            dx = float(x_mlp[1] - x_mlp[0])
            entropy_physical = p_mlp / np.maximum(rho_mlp ** gamma, 1e-12)
            entropy_ext_2d = apply_outflow_bc(entropy_physical[np.newaxis, :], nghost=nghost)
            prob_1d = predict(entropy_ext_2d[0, :], dx, model, device)

            is_troubled_physical = (prob_1d <= P_threshold)[1:Nx + 1]

            # 🟢 统计问题点数量与百分比
            troubled_count = np.sum(is_troubled_physical)
            troubled_percentage = (troubled_count / Nx) * 100
            print(f"🔍 [Sod]  N = {Nx} -> 问题点识别数量: {troubled_count}, 占比: {troubled_percentage:.2f}%")

            for i in range(len(x_mlp)):
                if is_troubled_physical[i]:
                    ax.axvline(x=x_mlp[i], color='fuchsia', linestyle='-', linewidth=0.9, alpha=0.8)

        # 轴系区间锁定
        ax.set_xlim(-5.0, 5.0)
        ax.set_xticks([-5.0, 0.0, 5.0])
        ax.set_ylim(0.0, 1.1)

        ax.set_xlabel(f'X\n{sub_labels[2][idx]} Sod (N = {Nx})', fontsize=30, labelpad=5)
        if idx == 0:
            ax.set_ylabel('Density', fontsize=30, labelpad=5)
            ax.set_yticks([0.2, 0.6, 1.0])
            ax.tick_params(axis='both', labelsize=28, direction='in', top=True, right=True, length=6, width=1.2, pad=14)
        else:
            ax.set_yticks([])
            ax.tick_params(axis='both', labelsize=28, direction='in', top=True, right=True, left=True, length=6,
                           width=1.2, pad=14)
            ax.tick_params(axis='y', labelleft=False)

    # =========================================================================
    # 全局排版优化与最左侧外挂垂直大图例
    # =========================================================================
    plt.tight_layout(rect=[0.14, 0, 1, 1])

    fig.legend(
        handles=legend_handles,
        labels=legend_labels,
        loc='center left',
        bbox_to_anchor=(0.005, 0.7),  # 居中垂直卡在大图最左侧外边缘
        ncol=1,  # 1列纵向垂直堆叠
        fontsize=20,
        handlelength=2.5,
        handletextpad=0.5,
        frameon=True,
        edgecolor='gray'
    )

    output_pdf = "1D_Euler_Riemann3_discontinuty_MLP.pdf"
    plt.savefig(output_pdf, dpi=300)
    print(f"\n📊 完美契合前缀的 3x3 间断检测全景矩阵已成功保存至: {output_pdf}")
    plt.show()


if __name__ == "__main__":
    main()