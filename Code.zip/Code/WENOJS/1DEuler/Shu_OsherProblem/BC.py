import numpy as np

def apply_shu_osher_bc(U, nghost=3):
    """
    Shu-Osher 问题边界条件：
    左边固定流入，右边自由流出
    U: shape = (3, N)
    返回扩展数组 U_ext: shape = (3, N + 2*nghost)
    """
    n_vars, N = U.shape
    U_ext = np.zeros((n_vars, N + 2*nghost))

    # 内部区域
    U_ext[:, nghost:-nghost] = U

    # --- 左边界 (固定流入) ---
    rho_L, u_L, p_L = 3.857143, 2.629369, 10.3333
    E_L = p_L / (1.4 - 1.0) + 0.5 * rho_L * u_L ** 2
    U_L = np.array([rho_L, rho_L * u_L, E_L])
    for i in range(nghost):
        U_ext[:, i] = U_L

    # --- 右边界 (自由流出) ---
    for i in range(nghost):
        U_ext[:, -nghost + i] = U[:, -1]

    return U_ext
