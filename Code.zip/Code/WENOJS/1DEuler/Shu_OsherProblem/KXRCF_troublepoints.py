import csv
import numpy as np
import matplotlib.pyplot as plt

'''
Post-process for Shu-Osher Problem: 1x3 子图联合散点绘制 (WENO5-KXRCF 文件名对齐版)
【文件名对齐】：完全匹配您的真实文件名格式 Shu_OsherProblem_WENO5KXRCF_N{Nx}_T1.80.csv
【参考解数据对齐】：完美匹配 np.load('Shu_OsherProblem_WENO5_N2000_T1.80.npz') 及其内 ['rho'] 键名。
【核心阈值绝对归位】：严格遵循您的设计规范，将 KXRCF 的判定门槛锁死为 1.0。
【边界条件硬核对齐】：同步您的求解器逻辑——左端鬼细胞采用固定流入状态标量熵，右端鬼细胞采用自由流出（零阶外推）。
【原点防撞击排版】：第一张子图 X 轴 pad=14, Y 轴 pad=8 彻底错开；中、右子图 X 轴同步平移 pad=14 锁死对齐。
'''


def load_euler_csv_data(filename):
    """安全读取标准 CSV 数据，返回网格中心坐标 x、密度 rho 和压力 p"""
    x_center, rho_numerical, p_numerical = [], [], []
    try:
        with open(filename, mode='r', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            for row in reader:
                x_center.append(float(row["x"]))
                if "rho" in row: rho_numerical.append(float(row["rho"]))
                if "p" in row:
                    p_numerical.append(float(row["p"]))
                else:
                    p_numerical.append(0.0)
    except FileNotFoundError:
        print(f"❌ 警告: 未找到文件 {filename}")
        return None, None, None
    return np.array(x_center), np.array(rho_numerical), np.array(p_numerical)


def apply_shu_osher_bc_scalar(entropy_1d, gamma=1.4, nghost=3):
    """针对 Shu-Osher 问题标量物理熵的定制边界条件：左边固定流入熵，右边自由流出（零阶外推）"""
    N = len(entropy_1d)
    entropy_ext = np.zeros(N + 2 * nghost)
    entropy_ext[nghost:-nghost] = entropy_1d

    # --- 左边界：固定流入状态的熵值 p_L / (rho_L ** gamma) ---
    rho_L, p_L = 3.857143, 10.3333
    entropy_L = p_L / (rho_L ** gamma)
    for i in range(nghost):
        entropy_ext[i] = entropy_L

    # --- 右边界：自由流出（零阶外推） ---
    for i in range(nghost):
        entropy_ext[-nghost + i] = entropy_1d[-1]

    return entropy_ext


def detect_troubled_points_only_kxrcf(x_center, rho, p, gamma=1.4, threshold=1.0, nghost=3):
    """基于物理边界条件闭环重构的 KXRCF 检测器（阈值刚性对齐为 1.0）"""
    N = len(rho)
    dx = x_center[1] - x_center[0]

    entropy_physical = p / np.maximum(rho ** gamma, 1e-12)
    entropy_ext = apply_shu_osher_bc_scalar(entropy_physical, gamma=gamma, nghost=nghost)

    prob_length = N + 2
    is_troubled_full = np.zeros(prob_length, dtype=bool)

    for i in range(prob_length):
        idx_ext = i + (nghost - 1)

        u0_l = (entropy_ext[idx_ext - 2] + 22 * entropy_ext[idx_ext - 1] + entropy_ext[idx_ext]) / 24.0
        u1_l = (entropy_ext[idx_ext] - entropy_ext[idx_ext - 2]) / 2.0
        u2_l = (entropy_ext[idx_ext - 2] - 2 * entropy_ext[idx_ext - 1] + entropy_ext[idx_ext]) / 2.0

        u0_c = (entropy_ext[idx_ext - 1] + 22 * entropy_ext[idx_ext] + entropy_ext[idx_ext + 1]) / 24.0
        u1_c = (entropy_ext[idx_ext + 1] - entropy_ext[idx_ext - 1]) / 2.0
        u2_c = (entropy_ext[idx_ext - 1] - 2 * entropy_ext[idx_ext] + entropy_ext[idx_ext + 1]) / 2.0

        u0_r = (entropy_ext[idx_ext] + 22 * entropy_ext[idx_ext + 1] + entropy_ext[idx_ext + 2]) / 24.0
        u1_r = (entropy_ext[idx_ext + 2] - entropy_ext[idx_ext]) / 2.0
        u2_r = (entropy_ext[idx_ext] - 2 * entropy_ext[idx_ext + 1] + entropy_ext[idx_ext + 2]) / 2.0

        edge_R_of_L = u0_l + 0.5 * u1_l + (1.0 / 6.0) * u2_l
        edge_L_of_C = u0_c - 0.5 * u1_c + (1.0 / 6.0) * u2_c

        edge_R_of_C = u0_c + 0.5 * u1_c + (1.0 / 6.0) * u2_c
        edge_L_of_R = u0_r - 0.5 * u1_r + (1.0 / 6.0) * u2_r

        delta_left = np.abs(edge_L_of_C - edge_R_of_L)
        delta_right = np.abs(edge_L_of_R - edge_R_of_C)
        max_jump = np.max([delta_left, delta_right])

        denominator = (dx ** 2.5) * (np.abs(entropy_ext[idx_ext]) + 1e-10)
        kappa_val = max_jump / denominator

        if kappa_val > threshold:
            is_troubled_full[i] = True

    return is_troubled_full[1:N + 1]


def main():
    nx_list = [100, 200, 400]
    sub_labels = ['(a)', '(b)', '(c)']
    T_final = 1.80
    gamma = 1.4
    KXRCF_THRESHOLD = 1.0  # 🟢 刚性锁死为 1.0

    try:
        data_riemann = np.load('Shu_OsherProblem_WENO5_N2000_T1.80.npz')
        x_riemann = data_riemann['x']
        rho_riemann = data_riemann['rho']
        print("✅ 成功加载 Shu-Osher 高分辨率 N2000 参考解数据")
    except FileNotFoundError:
        print("❌ 错误: 未能在当前目录找到参考解文件 'Shu_OsherProblem_WENO5_N2000_T1.80.npz'")
        return

    fig, axes = plt.subplots(1, 3, figsize=(20, 7), dpi=300)
    legend_handles, legend_labels = [], []

    for idx, Nx in enumerate(nx_list):
        ax = axes[idx]
        # 🟢 精准调整为您的实际 KXRCF 文件名格式（去除了旧版残余的 _Dynamic）
        kxrcf_file = f"Shu_OsherProblem_WENO5KXRCF_N{Nx}_T{T_final:.2f}.csv"

        x_kx, rho_kx, p_kx = load_euler_csv_data(kxrcf_file)
        if x_kx is None:
            ax.text(0.0, 2.5, f'Data Missing\nN = {Nx}', ha='center', va='center', fontsize=16, color='red')
            continue

        is_troubled = detect_troubled_points_only_kxrcf(x_kx, rho_kx, p_kx, gamma, KXRCF_THRESHOLD, nghost=3)
        total_points = len(x_kx)
        print(f"[KXRCF N = {Nx}, 门槛 = {KXRCF_THRESHOLD}] 捕捉到的间断坏点数量: {np.sum(is_troubled)}/{total_points}")

        # 1. 参考解（黑色高对比度实线）
        line1, = ax.plot(x_riemann, rho_riemann, color='black', linewidth=2.5, zorder=1, label='Reference')

        # 2. 数值解采用蓝色实线绘制
        line2, = ax.plot(x_kx, rho_kx, color='blue', linewidth=2.0, label='KXRCF')

        # 3. 标记线（荧光紫竖线）
        for i in range(total_points):
            if is_troubled[i]:
                ax.axvline(x=x_kx[i], color='fuchsia', linestyle='-', linewidth=0.8, alpha=0.8, zorder=3)

        if idx == 0:
            legend_handles = [line1, line2]
            legend_labels = ['Reference', 'KXRCF']

        ax.set_xlabel(f'X\n{sub_labels[idx]} N = {Nx}', fontsize=32, labelpad=3)
        if idx == 0: ax.set_ylabel('Density', fontsize=32, labelpad=5)

        ax.set_xlim(-5.0, 5.0)
        ax.set_xticks([-5.0, 0, 5.0])
        ax.set_ylim(0.5, 5.0)

        if idx == 0:
            ax.set_yticks([1.0, 3.0, 5.0])
            ax.tick_params(axis='y', labelsize=24, direction='in', left=True, right=True, length=6, width=1.2, pad=8)
            ax.tick_params(axis='x', labelsize=24, direction='in', top=True, right=True, length=6, width=1.2, pad=14)
        else:
            ax.set_yticks([])
            ax.tick_params(axis='x', labelsize=24, direction='in', top=True, right=True, length=6, width=1.2, pad=14)
            ax.tick_params(axis='y', direction='in', left=True, right=True, length=6, width=1.2)

    plt.tight_layout(rect=[0.09, 0, 1, 1])
    fig.legend(handles=legend_handles, labels=legend_labels, loc='center left', bbox_to_anchor=(0.001, 0.85),
               ncol=1, fontsize=15, markerscale=1.2, handlelength=2.0, handletextpad=0.5, frameon=True,
               edgecolor='gray')

    plt.savefig("1D_ShuOsher_KXRCF.pdf", dpi=300)
    plt.show()


if __name__ == "__main__":
    main()