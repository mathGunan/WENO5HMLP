import numpy as np


def IC(x_center):
    n = len(x_center)
    U = np.zeros((3, n))
    gamma = 1.4

    # 左侧状态 (激波)
    rho_L, u_L, p_L = 3.857143, 2.629369, 10.333333
    # 右侧状态 (密度波区域)

    for i, x in enumerate(x_center):
        if x < -4.0:
            rho, u, p = rho_L, u_L, p_L
        else:
            rho = 1.0 + 0.2 * np.sin(5.0 * x)
            u = 0.0
            p = 1.0

        U[0, i] = rho
        U[1, i] = rho * u
        U[2, i] = p / (gamma - 1) + 0.5 * rho * u ** 2

    return U