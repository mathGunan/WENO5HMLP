import csv
import numpy as np
import matplotlib.pyplot as plt
import torch
import torch.nn as nn

from BC import *
from helperfunction import *

'''
Post-process for Shu-Osher Problem: 1x3 子图联合散点绘制 (WENO5-H-MLP 文件名对齐版)
【文件名对齐】：完全匹配您的真实文件名格式 Shu_OsherProblem_WENO5MLP_N{Nx}_T1.80.csv
【参考解数据对齐】：完美匹配 np.load('Shu_OsherProblem_WENO5_N2000_T1.80.npz') 及其内 ['rho'] 键名。
【核心阈值绝对归位】：严格遵循神经网络预测反转判定，将 MLP 的智能门槛锁死为 0.5。
【边界条件硬核对齐】：同步您的求解器逻辑——左端鬼细胞采用固定流入状态标量熵，右端鬼细胞采用自由流出（零阶外推）。
【原点防撞击排版】：第一张子图 X 轴 pad=14, Y 轴 pad=8 彻底错开；中、右子图 X 轴同步平移 pad=14 锁死对齐。
'''


def load_euler_csv_data(filename):
    """安全读取标准 CSV 数据，返回网格中心坐标 x、密度 rho 和压力 p"""
    x_center, rho_numerical, p_numerical = [], [], []
    try:
        with open(filename, mode='r', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            for row in reader:
                x_center.append(float(row["x"]))
                if "rho" in row: rho_numerical.append(float(row["rho"]))
                if "p" in row:
                    p_numerical.append(float(row["p"]))
                else:
                    p_numerical.append(0.0)
    except FileNotFoundError:
        print(f"❌ 警告: 未找到文件 {filename}")
        return None, None, None
    return np.array(x_center), np.array(rho_numerical), np.array(p_numerical)


def apply_shu_osher_bc_scalar(entropy_1d, gamma=1.4, nghost=3):
    """针对 Shu-Osher 问题标量物理熵的定制边界条件：左边固定流入熵，右边自由流出（零阶外推）"""
    N = len(entropy_1d)
    entropy_ext = np.zeros(N + 2 * nghost)
    entropy_ext[nghost:-nghost] = entropy_1d

    # --- 左边界：固定流入状态的熵值 p_L / (rho_L ** gamma) ---
    rho_L, p_L = 3.857143, 10.3333
    entropy_L = p_L / (rho_L ** gamma)
    for i in range(nghost):
        entropy_ext[i] = entropy_L

    # --- 右边界：自由流出（零阶外推） ---
    for i in range(nghost):
        entropy_ext[-nghost + i] = entropy_1d[-1]

    return entropy_ext


def main():
    nx_list = [100, 200, 400]
    sub_labels = ['(a)', '(b)', '(c)']
    T_final = 1.80
    gamma = 1.4

    ckpt_path = "best_model.pth"
    P_threshold = 0.5  # 🟢 刚性锁死为 0.5
    nghost = 3

    try:
        model, device = get_model(ckpt_path, device_str='auto')
        print(f"✅ 成功加载神经网络权重模型，当前计算设备：{device}")
    except FileNotFoundError:
        print(f"❌ 错误: 未能在路径找到模型文件 '{ckpt_path}'")
        return

    try:
        data_riemann = np.load('Shu_OsherProblem_WENO5_N2000_T1.80.npz')
        x_riemann = data_riemann['x']
        rho_riemann = data_riemann['rho']
        print("✅ 成功加载 Shu-Osher 高分辨率 N2000 参考解数据")
    except FileNotFoundError:
        print("❌ 错误: 未能在当前目录找到参考解文件 'Shu_OsherProblem_WENO5_N2000_T1.80.npz'")
        return

    fig, axes = plt.subplots(1, 3, figsize=(20, 7), dpi=300)
    legend_handles, legend_labels = [], []

    for idx, Nx in enumerate(nx_list):
        ax = axes[idx]
        # 🟢 精准调整为您的实际 MLP 文件名格式（去除了旧版残余的 _Dynamic）
        mlp_file = f"Shu_OsherProblem_WENO5MLP_N{Nx}_T{T_final:.2f}.csv"

        x_mlp, rho_mlp, p_mlp = load_euler_csv_data(mlp_file)
        if x_mlp is None:
            ax.text(0.0, 2.5, f'Data Missing\nN = {Nx}', ha='center', va='center', fontsize=16, color='red')
            continue

        # 特征提取与推理
        dx = float(x_mlp[1] - x_mlp[0])
        entropy_physical = p_mlp / np.maximum(rho_mlp ** gamma, 1e-12)

        entropy_with_bc = apply_shu_osher_bc_scalar(entropy_physical, gamma=gamma, nghost=nghost)
        prob_1d = predict(entropy_with_bc, dx, model, device)

        # 概率反转逻辑判定
        is_troubled_physical = (prob_1d <= P_threshold)[1:Nx + 1]
        total_points = len(x_mlp)
        print(
            f"[MLP分辨率 N = {Nx}, 门槛 = {P_threshold}] 捕捉到的智能间断点数量: {np.sum(is_troubled_physical)}/{total_points}")

        # 1. 参考解（黑色高对比度实线）
        line1, = ax.plot(x_riemann, rho_riemann, color='black', linewidth=2.5, zorder=1, label='Reference')

        # 2. 绘制 WENO5-H-MLP 数值解：红色实线
        line2, = ax.plot(x_mlp, rho_mlp, color='red', linewidth=2.0, label='WENO5-H-MLP')

        # 3. 标记线（荧光紫竖线）
        for i in range(total_points):
            if is_troubled_physical[i]:
                ax.axvline(x=x_mlp[i], color='fuchsia', linestyle='-', linewidth=0.8, alpha=0.8, zorder=3)

        if idx == 0:
            legend_handles = [line1, line2]
            legend_labels = ['Reference', 'WENO5-H-MLP']

        ax.set_xlabel(f'X\n{sub_labels[idx]} N = {Nx}', fontsize=32, labelpad=3)
        if idx == 0: ax.set_ylabel('Density', fontsize=32, labelpad=5)

        ax.set_xlim(-5.0, 5.0)
        ax.set_xticks([-5.0, 0, 5.0])
        ax.set_ylim(0.5, 5.0)

        if idx == 0:
            ax.set_yticks([1.0, 3.0, 5.0])
            ax.tick_params(axis='y', labelsize=24, direction='in', left=True, right=True, length=6, width=1.2, pad=8)
            ax.tick_params(axis='x', labelsize=24, direction='in', top=True, right=True, length=6, width=1.2, pad=14)
        else:
            ax.set_yticks([])
            ax.tick_params(axis='x', labelsize=24, direction='in', top=True, right=True, length=6, width=1.2, pad=14)
            ax.tick_params(axis='y', direction='in', left=True, right=True, length=6, width=1.2)

    plt.tight_layout(rect=[0.09, 0, 1, 1])
    fig.legend(handles=legend_handles, labels=legend_labels, loc='center left', bbox_to_anchor=(0.001, 0.85),
               ncol=1, fontsize=15, markerscale=1.2, handlelength=2.0, handletextpad=0.5, frameon=True,
               edgecolor='gray')

    plt.savefig("1D_ShuOsher_MLP.pdf", dpi=300)
    plt.show()


if __name__ == "__main__":
    main()