import csv
import numpy as np
import matplotlib.pyplot as plt

# 完美对接您的专用函数模块与边界条件
from BC import apply_outflow_bc

'''
Joint Post-process for 1D Euler Problems: 3x3 Canvas Matrix (SLMC, Lax, Sod)
【学术规范对齐】：数值解统一为蓝色连续实线，全局图例彻底拿掉间断点(竖线)条目，仅保留 Reference 与 WENO5-KXRCF。
【路径前缀补回】：严格对齐 SLMC、Lax、Sod 各自独立的文件夹前缀与数据文件名。
'''


def load_euler_csv_data(filename):
    """
    安全读取标准 CSV 数据，返回网格中心坐标 x、密度 rho 和压力 p
    """
    x_center = []
    rho_numerical = []
    p_numerical = []

    try:
        with open(filename, mode='r', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            for row in reader:
                if "x" in row:
                    x_center.append(float(row["x"]))
                elif "x_center" in row:
                    x_center.append(float(row["x_center"]))

                if "rho" in row:
                    rho_numerical.append(float(row["rho"]))
                elif "Exact_solution_T" in row:
                    rho_numerical.append(float(row["Exact_solution_T"]))

                if "p" in row:
                    p_numerical.append(float(row["p"]))
                else:
                    p_numerical.append(0.0)
    except FileNotFoundError:
        print(f"❌ 警告: 未找到文件 {filename}")
        return None, None, None

    return np.array(x_center), np.array(rho_numerical), np.array(p_numerical)


def detect_troubled_points_only_kxrcf(x_center, rho, p, gamma=1.4, threshold=1.0, nghost=3):
    """
    基于标量非线性熵外推逻辑与双侧交界面最大跳跃的 KXRCF 问题点探测器
    """
    N = len(rho)
    dx = x_center[1] - x_center[0]

    entropy_physical = p / np.maximum(rho ** gamma, 1e-12)

    entropy_2d = entropy_physical[np.newaxis, :]
    entropy_ext_2d = apply_outflow_bc(entropy_2d, nghost=nghost)
    entropy_ext = entropy_ext_2d[0, :]

    prob_length = N + 2
    is_troubled_full = np.zeros(prob_length, dtype=bool)

    for i in range(prob_length):
        idx_ext = i + (nghost - 1)

        u0_l = (entropy_ext[idx_ext - 2] + 22 * entropy_ext[idx_ext - 1] + entropy_ext[idx_ext]) / 24.0
        u1_l = (entropy_ext[idx_ext] - entropy_ext[idx_ext - 2]) / 2.0
        u2_l = (entropy_ext[idx_ext - 2] - 2 * entropy_ext[idx_ext - 1] + entropy_ext[idx_ext]) / 2.0

        u0_c = (entropy_ext[idx_ext - 1] + 22 * entropy_ext[idx_ext] + entropy_ext[idx_ext + 1]) / 24.0
        u1_c = (entropy_ext[idx_ext + 1] - entropy_ext[idx_ext - 1]) / 2.0
        u2_c = (entropy_ext[idx_ext - 1] - 2 * entropy_ext[idx_ext] + entropy_ext[idx_ext + 1]) / 2.0

        u0_r = (entropy_ext[idx_ext] + 22 * entropy_ext[idx_ext + 1] + entropy_ext[idx_ext + 2]) / 24.0
        u1_r = (entropy_ext[idx_ext + 2] - entropy_ext[idx_ext]) / 2.0
        u2_r = (entropy_ext[idx_ext] - 2 * entropy_ext[idx_ext + 1] + entropy_ext[idx_ext + 2]) / 2.0

        edge_R_of_L = u0_l + 0.5 * u1_l + (1.0 / 6.0) * u2_l
        edge_L_of_C = u0_c - 0.5 * u1_c + (1.0 / 6.0) * u2_c

        edge_R_of_C = u0_c + 0.5 * u1_c + (1.0 / 6.0) * u2_c
        edge_L_of_R = u0_r - 0.5 * u1_r + (1.0 / 6.0) * u2_r

        delta_left = np.abs(edge_L_of_C - edge_R_of_L)
        delta_right = np.abs(edge_L_of_R - edge_R_of_C)
        max_jump = np.max([delta_left, delta_right])

        denominator = (dx ** 2.5) * (np.abs(entropy_ext[idx_ext]) + 1e-10)
        kappa_val = max_jump / denominator

        if kappa_val > threshold:
            is_troubled_full[i] = True

    return is_troubled_full[1:N + 1]


def main():
    nx_list = [100, 200, 400]
    sub_labels = [
        ['(a)', '(b)', '(c)'],  # 行1: SLMC
        ['(d)', '(e)', '(f)'],  # 行2: Lax
        ['(g)', '(h)', '(i)']  # 行3: Sod
    ]
    gamma = 1.4
    KXRCF_THRESHOLD = 1.0
    nghost = 3

    fig, axes = plt.subplots(3, 3, figsize=(20, 18))
    legend_handles = []
    legend_labels = []

    # =========================================================================
    # ROW 1: Slowly Moving Contact Discontinuity (SLMC) Problem
    # =========================================================================
    T_slmc = 2.0000
    for idx, Nx in enumerate(nx_list):
        ax = axes[0, idx]
        # 补回前缀：Slowlymovingcontactdiscontinuity/
        exact_file = f"Slowlymovingcontactdiscontinuity/Exact_Density_Solution_N{Nx}.csv"
        kxrcf_file = f"Slowlymovingcontactdiscontinuity/SMCDProblem_WENO5KXRCF_N{Nx}_T{T_slmc:.4f}.csv"

        x_exact, rho_exact, _ = load_euler_csv_data(exact_file)
        x_kx, rho_kx, p_kx = load_euler_csv_data(kxrcf_file)

        if x_exact is not None and x_kx is not None:
            line1, = ax.plot(x_exact, rho_exact, color='black', linewidth=2.5, label='Reference')
            line2, = ax.plot(x_kx, rho_kx, color='blue', linewidth=2.0, label='KXRCF')

            is_troubled = detect_troubled_points_only_kxrcf(x_kx, rho_kx, p_kx, gamma, KXRCF_THRESHOLD, nghost)
            print(f"🔍 [SLMC] N = {Nx} -> KXRCF 间断点数量: {np.sum(is_troubled)}/{len(x_kx)}")

            for i in range(len(x_kx)):
                if is_troubled[i]:
                    ax.axvline(x=x_kx[i], color='fuchsia', linestyle='-', linewidth=0.5, alpha=0.8)

            if not legend_handles:
                legend_handles = [line1, line2]
                legend_labels = ['Reference', 'KXRCF']

        ax.set_xlim(0.0, 1.0)
        ax.set_xticks([0.0, 0.5, 1.0])
        ax.set_ylim(0.9, 1.5)
        ax.set_xlabel(f'X\n{sub_labels[0][idx]} SLMC (N = {Nx})', fontsize=30, labelpad=5)

        if idx == 0:
            ax.set_ylabel('Density', fontsize=30, labelpad=5)
            ax.set_yticks([1.0, 1.2, 1.4])
            ax.tick_params(axis='both', labelsize=28, direction='in', top=True, right=True, length=6, width=1.2)
        else:
            ax.set_yticks([])
            ax.tick_params(axis='x', labelsize=28, direction='in', top=True, right=True, length=6, width=1.2)
            ax.tick_params(axis='y', direction='in', left=True, right=True, length=6, width=1.2)

    # =========================================================================
    # ROW 2: Lax Problem
    # =========================================================================
    T_lax = 1.30
    try:
        # 补回前缀：Laxproblem/
        data_lax = np.load('Laxproblem/riemann_solution.npz')
        x_lax_ref = data_lax['x']
        rho_lax_ref = data_lax['rho']
        print("✅ 成功加载 Laxproblem 目录下的 Riemann 参考解")
    except FileNotFoundError:
        print("❌ 错误: 未能在 Laxproblem 目录找到参考解文件 'riemann_solution.npz'")
        x_lax_ref, rho_lax_ref = None, None

    for idx, Nx in enumerate(nx_list):
        ax = axes[1, idx]
        # 补回前缀与对应格式：Laxproblem/LaxProblem_WENO5KXRCF_...
        kxrcf_file = f"Laxproblem/LaxProblem_WENO5KXRCF_N{Nx}_T{T_lax:.2f}.csv"

        x_kx, rho_kx, p_kx = load_euler_csv_data(kxrcf_file)

        if x_lax_ref is not None and x_kx is not None:
            ax.plot(x_lax_ref, rho_lax_ref, color='black', linewidth=2.5)
            ax.plot(x_kx, rho_kx, color='blue', linewidth=2.0)

            is_troubled = detect_troubled_points_only_kxrcf(x_kx, rho_kx, p_kx, gamma, KXRCF_THRESHOLD, nghost)
            print(f"🔍 [Lax]  N = {Nx} -> KXRCF 间断点数量: {np.sum(is_troubled)}/{len(x_kx)}")

            for i in range(len(x_kx)):
                if is_troubled[i]:
                    ax.axvline(x=x_kx[i], color='fuchsia', linestyle='-', linewidth=0.5, alpha=0.8)

        ax.set_xlim(-5.0, 5.0)
        ax.set_xticks([-5.0, 0.0, 5.0])
        ax.set_ylim(0.2, 1.4)
        ax.set_xlabel(f'X\n{sub_labels[1][idx]} Lax (N = {Nx})', fontsize=30, labelpad=5)

        if idx == 0:
            ax.set_ylabel('Density', fontsize=30, labelpad=5)
            ax.set_yticks([0.4, 0.8, 1.2])
            ax.tick_params(axis='both', labelsize=28, direction='in', top=True, right=True, length=6, width=1.2)
        else:
            ax.set_yticks([])
            ax.tick_params(axis='x', labelsize=28, direction='in', top=True, right=True, length=6, width=1.2)
            ax.tick_params(axis='y', direction='in', left=True, right=True, length=6, width=1.2)

    # =========================================================================
    # ROW 3: Sod Problem
    # =========================================================================
    T_sod = 2.00
    try:
        # 补回前缀：Sodproblem/
        data_sod = np.load('Sodproblem/riemann_solution.npz')
        x_sod_ref = data_sod['x']
        rho_sod_ref = data_sod['rho']
        print("✅ 成功加载 Sodproblem 目录下的 Riemann 参考解")
    except FileNotFoundError:
        print("❌ 错误: 未能在 Sodproblem 目录找到参考解文件 'riemann_solution.npz'")
        x_sod_ref, rho_sod_ref = None, None

    for idx, Nx in enumerate(nx_list):
        ax = axes[2, idx]
        # 补回前缀与对应格式：Sodproblem/SodProblem_WENO5KXRCF_...
        kxrcf_file = f"Sodproblem/SodProblem_WENO5KXRCF_N{Nx}_T{T_sod:.2f}.csv"

        x_kx, rho_kx, p_kx = load_euler_csv_data(kxrcf_file)

        if x_sod_ref is not None and x_kx is not None:
            ax.plot(x_sod_ref, rho_sod_ref, color='black', linewidth=2.5)
            ax.plot(x_kx, rho_kx, color='blue', linewidth=2.0)

            is_troubled = detect_troubled_points_only_kxrcf(x_kx, rho_kx, p_kx, gamma, KXRCF_THRESHOLD, nghost)
            print(f"🔍 [Sod]  N = {Nx} -> KXRCF 间断点数量: {np.sum(is_troubled)}/{len(x_kx)}")

            for i in range(len(x_kx)):
                if is_troubled[i]:
                    ax.axvline(x=x_kx[i], color='fuchsia', linestyle='-', linewidth=0.5, alpha=0.8)

        # 轴系区间与标签设置（严格匹配您原版的 [-5.0, 0, 5.0] 及 [0.0, 1.1] 标尺）
        ax.set_xlim(-5.0, 5.0)
        ax.set_xticks([-5.0, 0.0, 5.0])
        ax.set_ylim(0.0, 1.1)
        ax.set_xlabel(f'X\n{sub_labels[2][idx]} Sod (N = {Nx})', fontsize=30, labelpad=5)

        if idx == 0:
            ax.set_ylabel('Density', fontsize=30, labelpad=5)
            ax.set_yticks([0.2, 0.6, 1.0])
            ax.tick_params(axis='both', labelsize=28, direction='in', top=True, right=True, length=6, width=1.2)
        else:
            ax.set_yticks([])
            ax.tick_params(axis='x', labelsize=28, direction='in', top=True, right=True, length=6, width=1.2)
            ax.tick_params(axis='y', direction='in', left=True, right=True, length=6, width=1.2)

    # =========================================================================
    # 全局外部图例渲染（外挂于画布最左侧侧边栏，完美避开主图遮挡）
    # =========================================================================
    plt.tight_layout(rect=[0.14, 0, 1, 1])

    fig.legend(
        handles=legend_handles,
        labels=legend_labels,
        loc='center left',
        bbox_to_anchor=(0.005, 0.75),
        ncol=1,
        fontsize=18,
        markerscale=1.8,
        handlelength=2.5,
        handletextpad=0.5,
        frameon=True,
        edgecolor='gray'
    )

    output_pdf = "1D_Euler_Riemann3_discontinuity_KXRCF.pdf"
    plt.savefig(output_pdf, dpi=300)
    print(f"\n📊 具有完整文件夹前缀路径的 3x3 KXRCF 联合对比图表已成功保存至: {output_pdf}")
    plt.show()


if __name__ == "__main__":
    main()