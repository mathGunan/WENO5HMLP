import csv
import numpy as np
import matplotlib.pyplot as plt
from BC import *

'''
Joint Post-process for Sod Problem: KXRCF Troubled-Point Detector (1x3 Canvas)
【严格对齐 Lax 最新规范】：数值解更改为蓝色连续实线，全局大图例彻底拿掉间断点(竖线)条目。
【物理量严格对齐】：核心采用非线性标量熵 S = p / max(rho^gamma, 1e-12)。
【定义域/值域标尺适配】：空间区间严格限定在 [0.0, 1.0]，纵轴密度精准控制在 [0.0, 1.1]。
'''


def load_euler_csv_data(filename):
    """
    安全读取标准 CSV 数据，返回网格中心坐标 x、密度 rho 和压力 p
    """
    x_center = []
    rho_numerical = []
    p_numerical = []

    try:
        with open(filename, mode='r', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            for row in reader:
                x_center.append(float(row["x"]))
                if "rho" in row:
                    rho_numerical.append(float(row["rho"]))
                elif "Exact_solution_T" in row:
                    rho_numerical.append(float(row["Exact_solution_T"]))

                if "p" in row:
                    p_numerical.append(float(row["p"]))
                else:
                    p_numerical.append(0.0)
    except FileNotFoundError:
        print(f"❌ 警告: 未找到文件 {filename}")
        return None, None, None

    return np.array(x_center), np.array(rho_numerical), np.array(p_numerical)


def detect_troubled_points_only_kxrcf(x_center, rho, p, gamma=1.4, threshold=1.0, nghost=3):
    """
    基于标量非线性熵外推逻辑重构的 KXRCF 问题点探测器，内部完美调用 apply_outflow_bc
    """
    N = len(rho)
    dx = x_center[1] - x_center[0]

    # 严格采用非线性标量熵，引入 1e-12 截断保护
    entropy_physical = p / np.maximum(rho ** gamma, 1e-12)

    entropy_2d = entropy_physical[np.newaxis, :]
    entropy_ext_2d = apply_outflow_bc(entropy_2d, nghost=nghost)
    entropy_ext = entropy_ext_2d[0, :]

    prob_length = N + 2
    is_troubled_full = np.zeros(prob_length, dtype=bool)

    for i in range(prob_length):
        idx_ext = i + (nghost - 1)

        u0_l = (entropy_ext[idx_ext - 2] + 22 * entropy_ext[idx_ext - 1] + entropy_ext[idx_ext]) / 24.0
        u1_l = (entropy_ext[idx_ext] - entropy_ext[idx_ext - 2]) / 2.0
        u2_l = (entropy_ext[idx_ext - 2] - 2 * entropy_ext[idx_ext - 1] + entropy_ext[idx_ext]) / 2.0

        u0_c = (entropy_ext[idx_ext - 1] + 22 * entropy_ext[idx_ext] + entropy_ext[idx_ext + 1]) / 24.0
        u1_c = (entropy_ext[idx_ext + 1] - entropy_ext[idx_ext - 1]) / 2.0
        u2_c = (entropy_ext[idx_ext - 1] - 2 * entropy_ext[idx_ext] + entropy_ext[idx_ext + 1]) / 2.0

        u0_r = (entropy_ext[idx_ext] + 22 * entropy_ext[idx_ext + 1] + entropy_ext[idx_ext + 2]) / 24.0
        u1_r = (entropy_ext[idx_ext + 2] - entropy_ext[idx_ext]) / 2.0
        u2_r = (entropy_ext[idx_ext] - 2 * entropy_ext[idx_ext + 1] + entropy_ext[idx_ext + 2]) / 2.0

        edge_R_of_L = u0_l + 0.5 * u1_l + (1.0 / 6.0) * u2_l
        edge_L_of_C = u0_c - 0.5 * u1_c + (1.0 / 6.0) * u2_c

        edge_R_of_C = u0_c + 0.5 * u1_c + (1.0 / 6.0) * u2_c
        edge_L_of_R = u0_r - 0.5 * u1_r + (1.0 / 6.0) * u2_r

        delta_left = np.abs(edge_L_of_C - edge_R_of_L)
        delta_right = np.abs(edge_L_of_R - edge_R_of_C)
        max_jump = np.max([delta_left, delta_right])

        denominator = (dx ** 2.5) * (np.abs(entropy_ext[idx_ext]) + 1e-10)
        kappa_val = max_jump / denominator

        if kappa_val > threshold:
            is_troubled_full[i] = True

    return is_troubled_full[1:N + 1]


def main():
    nx_list = [100, 200, 400]
    sub_labels = ['(a)', '(b)', '(c)']
    T_final = 2.00
    gamma = 1.4
    KXRCF_THRESHOLD = 1.0

    try:
        data_riemann = np.load('riemann_solution.npz')
        x_riemann = data_riemann['x']
        rho_riemann = data_riemann['rho']
        print("✅ 成功加载 Riemann 参考解数据")
    except FileNotFoundError:
        print("❌ 错误: 未能在当前目录找到参考解文件 'riemann_solution.npz'")
        return

    fig, axes = plt.subplots(1, 3, figsize=(20, 7))
    legend_handles = []
    legend_labels = []

    for idx, Nx in enumerate(nx_list):
        ax = axes[idx]
        kxrcf_file = f"SodProblem_WENO5KXRCF_N{Nx}_T{T_final:.2f}.csv"

        x_kx, rho_kx, p_kx = load_euler_csv_data(kxrcf_file)
        if x_kx is None:
            ax.text(0.5, 0.5, f'Data Missing\nN = {Nx}', ha='center', va='center', fontsize=16)
            continue

        is_troubled = detect_troubled_points_only_kxrcf(x_kx, rho_kx, p_kx, gamma, KXRCF_THRESHOLD, nghost=3)

        total_points = len(x_kx)
        print(f"[KXRCF N = {Nx}] 间断点数量: {np.sum(is_troubled)}/{total_points}")

        # 1. 绘制高对比度黑色精确解实线
        line1, = ax.plot(x_riemann, rho_riemann, color='black', linewidth=2.5, label='Reference')

        # 2. 严格对齐您的 Lax 规范：数值解采用蓝色实线绘制
        line2, = ax.plot(x_kx, rho_kx, color='blue', linewidth=2.0, label='KXRCF')

        # 3. 绘制荧光紫竖线
        for i in range(total_points):
            if is_troubled[i]:
                ax.axvline(x=x_kx[i], color='fuchsia', linestyle='-', linewidth=0.9, alpha=0.8)

        # 严格对齐您的图例逻辑：仅在最左侧第一个子图中抓取 Reference 与 数值解，彻底拿掉竖线条目
        if idx == 0:
            legend_handles = [line1, line2]
            legend_labels = ['Reference', 'KXRCF']

        ax.set_xlabel(f'X\n{sub_labels[idx]} N = {Nx}', fontsize=32, labelpad=3)
        if idx == 0:
            ax.set_ylabel('Density', fontsize=32, labelpad=5)

        # Sod 物理标尺锁死
        ax.set_xticks([-5.0,0,5.0])

        if idx == 0:
            ax.set_yticks([0.2, 0.6, 1.0])
            # 全体刻度数字放大至 24 号大字，方向朝内
            ax.tick_params(axis='both', labelsize=24, direction='in', top=True, right=True, length=6, width=1.2)
        else:
            # 🟢 3. 第二、三张子图完全隐藏 Y 轴纵轴数字，但保留相同的 X 轴朝内 24 号大字样式
            ax.set_yticks([])
            ax.tick_params(axis='x', labelsize=24, direction='in', top=True, right=True, length=6, width=1.2)
            ax.tick_params(axis='y', direction='in', left=True, right=True, length=6, width=1.2)

    plt.tight_layout(rect=[0.05, 0, 1, 1])
    fig.legend(handles=legend_handles, labels=legend_labels, loc='center left', bbox_to_anchor=(0.001, 0.85),
               ncol=1, fontsize=15, markerscale=1.8, handlelength=2.0, handletextpad=0.5, frameon=True,
               edgecolor='gray')

    plt.savefig("1D_Sod_KXRCF.pdf", dpi=300)
    print("📊 KXRCF 间断点图表已成功保存（实线纯净图例版）。")
    plt.show()


if __name__ == "__main__":
    main()