import csv
import numpy as np
import matplotlib.pyplot as plt
import torch
import torch.nn as nn
from BC import *
from helperfunction import *

'''
Joint Post-process for Sod Problem: MLP Troubled-Point Detector (1x3 Canvas)
【全盘对齐最新设置】：严格对齐坐标轴刻度、竖线线宽 linewidth=0.9 以及 plt.tight_layout(rect=[0.05, 0, 1, 1])。
【硬核反转逻辑】：预测概率 <= 阈值 P 时判定为 Troubled Point 间断点。
【图层纯净规范】：Reference 黑色实线 + WENO5-H-MLP 红色实线 + 荧光紫竖线，大图例彻底拿掉竖线条目。
'''


def load_euler_csv_data(filename):
    """
    安全读取标准 CSV 数据，返回网格中心坐标 x、密度 rho 和压力 p
    """
    x_center = []
    rho_numerical = []
    p_numerical = []

    try:
        with open(filename, mode='r', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            for row in reader:
                x_center.append(float(row["x"]))
                if "rho" in row:
                    rho_numerical.append(float(row["rho"]))
                elif "Exact_solution_T" in row:
                    rho_numerical.append(float(row["Exact_solution_T"]))

                if "p" in row:
                    p_numerical.append(float(row["p"]))
                else:
                    p_numerical.append(0.0)
    except FileNotFoundError:
        print(f"❌ 警告: 未找到文件 {filename}")
        return None, None, None

    return np.array(x_center), np.array(rho_numerical), np.array(p_numerical)


def main():
    nx_list = [100, 200, 400]
    sub_labels = ['(a)', '(b)', '(c)']
    T_final = 2.00
    gamma = 1.4

    P_threshold = 0.5
    nghost = 3
    ckpt_path = "best_model.pth"

    try:
        model, device = get_model(ckpt_path, device_str='auto')
        print(f"✅ 成功加载神经网络权重模型，设备：{device}")
    except FileNotFoundError:
        print(f"❌ 错误: 未能在路径找到模型文件 '{ckpt_path}'")
        return

    try:
        data_riemann = np.load('riemann_solution.npz')
        x_riemann = data_riemann['x']
        rho_riemann = data_riemann['rho']
        print("✅ 成功加载 Riemann 参考解数据")
    except FileNotFoundError:
        print("❌ 错误: 未能在当前目录找到参考解文件 'riemann_solution.npz'")
        return

    fig, axes = plt.subplots(1, 3, figsize=(20, 7), dpi=300)
    legend_handles = []
    legend_labels = []

    for idx, Nx in enumerate(nx_list):
        ax = axes[idx]
        mlp_file = f"SodProblem_WENO5MLP_N{Nx}_T{T_final:.2f}.csv"

        x_mlp, rho_mlp, p_mlp = load_euler_csv_data(mlp_file)
        if x_mlp is None:
            ax.text(0.5, 0.5, f'Data Missing\nN = {Nx}', ha='center', va='center', fontsize=16)
            continue

        dx = float(x_mlp[1] - x_mlp[0])
        entropy_physical = p_mlp / np.maximum(rho_mlp ** gamma, 1e-12)

        entropy_2d = entropy_physical[np.newaxis, :]
        entropy_ext_2d = apply_outflow_bc(entropy_2d, nghost=nghost)
        entropy_with_bc = entropy_ext_2d[0, :]

        prob_1d = predict(entropy_with_bc, dx, model, device)
        is_troubled_full = prob_1d <= P_threshold
        is_troubled_physical = is_troubled_full[1:Nx + 1]

        total_points = len(x_mlp)
        print(f"[MLP N = {Nx}] 间断点数量: {np.sum(is_troubled_physical)}/{total_points}")

        # 1. 绘制高对比度黑色精确解实线
        line1, = ax.plot(x_riemann, rho_riemann, color='black', linewidth=2.5, label='Reference')

        # 2. 数值解采用红色连续实线绘制
        line2, = ax.plot(x_mlp, rho_mlp, color='red', linewidth=2.0, label='WENO5-H-MLP')

        # 3. 严格同步线宽：绘制高亮荧光紫竖线标记 (linewidth=0.9)
        for i in range(total_points):
            if is_troubled_physical[i]:
                ax.axvline(x=x_mlp[i], color='fuchsia', linestyle='-', linewidth=0.9, alpha=0.8)

        # 严格对齐您的最新图例逻辑：大图例仅保留这两个核心物理流场条目
        if idx == 0:
            legend_handles = [line1, line2]
            legend_labels = ['Reference', 'WENO5-H-MLP']

        ax.set_xlabel(f'X\n{sub_labels[idx]} N = {Nx}', fontsize=32, labelpad=3)
        if idx == 0:
            ax.set_ylabel('Density', fontsize=32, labelpad=5)

        # 🟢 严格同步设置：Sod 问题刻度标尺控制
        ax.set_xticks([-5.0, 0, 5.0])

        if idx == 0:
            ax.set_yticks([0.2, 0.6, 1.0])
            ax.tick_params(axis='both', labelsize=24, direction='in', top=True, right=True, length=6, width=1.2)
        else:
            ax.set_yticks([])
            ax.tick_params(axis='x', labelsize=24, direction='in', top=True, right=True, length=6, width=1.2)
            ax.tick_params(axis='y', direction='in', left=True, right=True, length=6, width=1.2)

    # 🟢 严格同步设置：精密留白收缩至 0.05
    plt.tight_layout(rect=[0.09, 0, 1, 1])

    fig.legend(handles=legend_handles, labels=legend_labels, loc='center left', bbox_to_anchor=(0.001, 0.85),
               ncol=1, fontsize=15, markerscale=1.8, handlelength=2.0, handletextpad=0.5, frameon=True,
               edgecolor='gray')

    plt.savefig("1D_Sod_MLP.pdf", dpi=300)
    print("📊 MLP 间断点图表已成功保存（与最新 KXRCF 美术配置全盘对齐）。")
    plt.show()


if __name__ == "__main__":
    main()