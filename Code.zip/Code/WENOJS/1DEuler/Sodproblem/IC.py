import numpy as np
#输出的是张量，并且是守恒量，而不是底层变量
#Sod problem
def IC(x_center):
    '''初始化正弦波扰动条件'''
    n = len(x_center)
    U = np.zeros((3, n))
    gamma = 1.4

    # 左侧/右侧常数状态
    rho_L, u_L, p_L = 1, 0, 1
    rho_R, u_R, p_R = 0.125, 0, 0.1

    # 初始间断位置
    for i, x in enumerate(x_center):
        if x < 0.0:
            rho, u, p = rho_L, u_L, p_L
        else:
            rho, u, p = rho_R, u_R, p_R

        U[0, i] = rho
        U[1, i] = rho * u
        U[2, i] = p / (gamma - 1) + 0.5 * rho * u**2
    return U