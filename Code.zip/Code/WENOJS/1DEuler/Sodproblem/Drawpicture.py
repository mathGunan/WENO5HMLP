import csv
import numpy as np
import matplotlib.pyplot as plt

'''
Joint Post-process for Sod Problem: 1x3 子图联合绘制 (N = 100, 200, 400)
横向对比 1D Euler Sod 问题的解析解 (Reference)、Pure WENO5、WENO5-KXRCF 以及 WENO5-H-MLP 的密度 (rho) 剖面
【完全对齐 Lax 绘图配置】：Reference 黑色实线 + Pure WENO5 绿色空心上三角 + KXRCF 蓝色空心圆点 + WENO5-H-MLP 红色空心正方形。
【定义域/值域标尺适配】：空间区间强制压缩在 [0.0, 1.0]，纵轴密度精准控制在 [0.0, 1.1]。
'''


def load_euler_csv_data(filename):
    """
    安全读取 Euler 方程仿真输出的标准 CSV 数据，返回网格中心和密度 rho
    """
    x_center = []
    rho_numerical = []

    try:
        with open(filename, mode='r', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            for row in reader:
                x_center.append(float(row["x"]))
                # 提取密度场物理量
                if "rho" in row:
                    rho_numerical.append(float(row["rho"]))
    except FileNotFoundError:
        print(f"❌ 警告: 未找到文件 {filename}")
        return None, None

    return np.array(x_center), np.array(rho_numerical)


def main():
    # 定义需要对比的三个网格点数
    nx_list = [100, 200, 400]
    # 定义对应的子图学术编号字母
    sub_labels = ['(a)', '(b)', '(c)']
    T_final = 2.00  # Sod 问题的最终终止时刻

    # 🟢 【统一参考解】：严格按照您的要求，从工作目录下加载标准一维 Sod 问题的 Riemann 精确解
    try:
        data_riemann = np.load('riemann_solution.npz')
        x_riemann = data_riemann['x']
        rho_riemann = data_riemann['rho']
        print("✅ 成功加载 Riemann 参考解数据 (riemann_solution.npz)")
    except FileNotFoundError:
        print("❌ 错误: 未能在当前目录找到参考解文件 'riemann_solution.npz'，无法继续绘图。")
        return

    # 初始化 1x3 学术画布，控制高分辨率矢量输出
    fig, axes = plt.subplots(1, 3, figsize=(20, 7))

    # 用于在全局外部图例中统一收集线条和散点句柄的临时变量
    legend_handles = []
    legend_labels = []

    # 循环控制绘制每一个子图
    for idx, Nx in enumerate(nx_list):
        ax = axes[idx]  # 获取当前子图的控制句柄

        # =========================================================================
        # 【全盘动态对齐】：数值解文件名与方案映射严格对应当前子图的分辨率 Nx
        # =========================================================================
        weno5_file = f"SodProblem_WENO5_N{Nx}_T{T_final:.2f}.csv"
        kxrcf_file = f"SodProblem_WENO5KXRCF_N{Nx}_T{T_final:.2f}.csv"
        mlp_file = f"SodProblem_WENO5MLP_N{Nx}_T{T_final:.2f}.csv"

        # 加载数据
        x_weno, rho_weno = load_euler_csv_data(weno5_file)
        x_kx, rho_kx = load_euler_csv_data(kxrcf_file)
        x_mlp, rho_mlp = load_euler_csv_data(mlp_file)

        # 健壮性检查：确保文件都存在再画图
        if x_weno is None or x_kx is None or x_mlp is None:
            ax.text(0.5, 0.5, f'Data Missing\nN = {Nx}', ha='center', va='center', fontsize=16, color='red')
            continue

        # 1. 绘制全局统一的高对比度黑色实线精准精确解（Reference）
        line1, = ax.plot(x_riemann, rho_riemann, color='black', linewidth=2.5, label='Reference')

        # 2. 绘制纯 WENO5 数值解：纯绿色空心上三角点 (彻底拿掉连线，s=40)
        scat1 = ax.scatter(x_weno, rho_weno, marker='^', edgecolors='forestgreen', facecolors='none', s=40, label='WENO5')

        # 3. 绘制 KXRCF 数值解：纯蓝色空心圆点 (彻底拿掉连线，s=40)
        scat2 = ax.scatter(x_kx, rho_kx, marker='o', edgecolors='blue', facecolors='none', s=40, label='KXRCF')

        # 4. 绘制 WENO5-H-MLP 数值解：纯红色空心正方形 (彻底拿掉连线，s=40)
        scat3 = ax.scatter(x_mlp, rho_mlp, marker='s', edgecolors='red', facecolors='none', s=40, label='WENO5-H-MLP')

        # 只在第一张图中收集全局句柄，避免图例中条目重复
        if idx == 0:
            legend_handles = [line1, scat1, scat2, scat3]
            legend_labels = ['Reference', 'WENO5', 'KXRCF', 'WENO5-H-MLP']

        # 5. 坐标轴标签美化（最简方式控制单个 \n 换行，文本紧凑靠上）
        ax.set_xlabel(f'X\n{sub_labels[idx]} N = {Nx}', fontsize=32, labelpad=3)

        if idx == 0:
            ax.set_ylabel('Density', fontsize=32, labelpad=5)  # 仅在最左侧图加 Y 轴标签

        # =========================================================================
        # 【核心刻度控制】：完美契合一维 Sod 问题的定义域与值域范围
        # =========================================================================

        ax.set_xticks([-5.0,0,5.0])

        if idx == 0:
            ax.set_yticks([0.2, 0.6, 1.0])
            # 全体刻度数字放大至 24 号大字，方向朝内
            ax.tick_params(axis='both', labelsize=24, direction='in', top=True, right=True, length=6, width=1.2)
        else:
            # 🟢 3. 第二、三张子图完全隐藏 Y 轴纵轴数字，但保留相同的 X 轴朝内 24 号大字样式
            ax.set_yticks([])
            ax.tick_params(axis='x', labelsize=24, direction='in', top=True, right=True, length=6, width=1.2)
            ax.tick_params(axis='y', direction='in', left=True, right=True, length=6, width=1.2)

    # =========================================================================
    # 【极致外侧版面优化】：精密留白收缩至 0.09
    # =========================================================================
    plt.tight_layout(rect=[0.09, 0, 1, 1])

    # =========================================================================
    # 【全局外部大图例调节控制】：垂直死死卡在整张 1x3 大图的最左侧外边缘
    # =========================================================================
    fig.legend(
        handles=legend_handles,
        labels=legend_labels,
        loc='center left',
        bbox_to_anchor=(0.001, 0.85),  # 紧贴画布极左边缘外侧
        ncol=1,  # 1列纵向垂直堆叠
        fontsize=15,  # 精致学术大字号
        markerscale=2.0,  # 确保图例里的空心散点图标清晰、容易辨认
        handlelength=2.0,
        handletextpad=0.5,
        frameon=True,
        edgecolor='gray'
    )

    # 保存为论文通用的高清矢量图 PDF
    output_pdf = "1DSod_compare.pdf"
    plt.savefig(output_pdf, dpi=300)
    print(f"\n📊 完美的 1x3 欧拉方程 Sod 问题多方案密度对比图表已成功保存至: {output_pdf}")
    plt.show()


if __name__ == "__main__":
    main()