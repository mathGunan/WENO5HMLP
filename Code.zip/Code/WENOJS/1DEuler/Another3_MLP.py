import csv
import numpy as np
import matplotlib.pyplot as plt
import torch
import torch.nn as nn

# 完美对接您的专用函数模块 (包含边界与网络推理)
from BC import *
from helperfunction import *

'''
Joint Post-process for 3 Hyperbolic Conservation Laws Problems (3x3 Canvas)
【特征与边界硬核对齐】：
  - Row 0 (Sedov) & Row 1 (Double Blast): 输入神经网络的物理熵经过 apply_reflective_bc_scalar 的镜像反射拓扑。
  - Row 2 (Shu-Osher): 输入神经网络的物理熵经过 apply_shu_osher_bc_scalar 的左固定流入、右零阶外推拓扑。
【图例规范严格闭锁】：全局图例有且仅有两个标签：'Reference' 与 'WENO5-H-MLP'，不掺杂任何多余符号。
【新增高阶指标统计】：控制台深度打印每个算例及对应网格分辨率下智能捕捉的坏点总数与高精度百分比。
'''


def load_euler_csv_data_generic(filename):
    """
    通用安全读取标准 CSV 数据，自适应兼容三种经典问题的列名
    """
    x_center, rho_numerical, p_numerical = [], [], []
    try:
        with open(filename, mode='r', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            for row in reader:
                # 兼容 x 坐标轴列名
                if "x" in row:
                    x_center.append(float(row["x"]))
                elif "x_center" in row:
                    x_center.append(float(row["x_center"]))

                # 兼容密度列名
                if "rho" in row:
                    rho_numerical.append(float(row["rho"]))
                elif "Exact_solution_T" in row:
                    rho_numerical.append(float(row["Exact_solution_T"]))
                elif "rho_primitive" in row:
                    rho_numerical.append(float(row["rho_primitive"]))

                # 兼容压力列名
                if "p" in row:
                    p_numerical.append(float(row["p"]))
                elif "p_primitive" in row:
                    p_numerical.append(float(row["p_primitive"]))
                else:
                    p_numerical.append(0.0)
    except FileNotFoundError:
        print(f"❌ 警告: 未找到文件 {filename}")
        return None, None, None
    return np.array(x_center), np.array(rho_numerical), np.array(p_numerical)


def apply_reflective_bc_scalar(entropy_1d, nghost=3):
    """针对标量非线性物理熵的刚性反射墙边界条件 (镜像映射)"""
    N = len(entropy_1d)
    entropy_ext = np.zeros(N + 2 * nghost)
    entropy_ext[nghost:-nghost] = entropy_1d
    entropy_ext[:nghost] = entropy_1d[nghost - 1::-1]
    entropy_ext[-nghost:] = entropy_1d[-1:-nghost - 1:-1]
    return entropy_ext


def apply_shu_osher_bc_scalar(entropy_1d, gamma=1.4, nghost=3):
    """针对 Shu-Osher 问题标量物理熵的定制边界条件：左边固定流入熵，右边自由流出（零阶外推）"""
    N = len(entropy_1d)
    entropy_ext = np.zeros(N + 2 * nghost)
    entropy_ext[nghost:-nghost] = entropy_1d

    rho_L, p_L = 3.857143, 10.3333
    entropy_L = p_L / (rho_L ** gamma)
    for i in range(nghost):
        entropy_ext[i] = entropy_L

    for i in range(nghost):
        entropy_ext[-nghost + i] = entropy_1d[-1]

    return entropy_ext


def main():
    nx_list = [100, 200, 400]
    # 3x3 矩阵子图学术标签规范分配
    sub_labels = [
        ['(a)', '(b)', '(c)'],  # Row 0: Sedov
        ['(d)', '(e)', '(f)'],  # Row 1: Double Blast
        ['(g)', '(h)', '(i)']  # Row 2: Shu-Osher
    ]
    gamma = 1.4
    P_threshold = 0.5
    nghost = 3
    ckpt_path = "best_model.pth"

    try:
        model, device = get_model(ckpt_path, device_str='auto')
        print(f"✅ 成功加载神经网络权重模型，当前计算设备：{device}")
    except FileNotFoundError:
        print(f"❌ 错误: 未能在路径找到模型文件 '{ckpt_path}'")
        return

    # --- 锁死加载三组高分辨率参考解数据 ---
    try:
        ref_sedov = np.load('Sedov’sblastwaveproblem/Sedov’s blast  WaveProblem_WENO5_N4000_T0.0010.npz')
        ref_double = np.load('DoubleBlastWaveinteraction/DoubleBlastWaveInteractionProblem_WENO5_N4000_T0.04.npz', allow_pickle=True)
        ref_shu = np.load('Shu_OsherProblem/Shu_OsherProblem_WENO5_N2000_T1.80.npz')
        print("✅ 成功加载所有经典算例的参考解数据\n")
    except FileNotFoundError as e:
        print(f"❌ 错误: 核心参考解数据缺失 ({e})")
        return

    # 创建标准 3x3 学术大图画布
    fig, axes = plt.subplots(3, 3, figsize=(20, 18))
    legend_handles = []

    print("=================== ⏳ 开始统计间断点 (Troubled Points) ⏳ ===================")

    # ==========================================
    # ROW 0: Sedov Problem (输入特征：熵 + 反射边界条件)
    # ==========================================
    print("\n📌 [算例 1: Sedov Blast Wave 问题]")
    for idx, Nx in enumerate(nx_list):
        ax = axes[0, idx]
        mlp_file = f"Sedov’sblastwaveproblem/Sedov_blastwaveProblem_WENO5MLP_N{Nx}_T0.0010.csv"
        x_mlp, rho_mlp, p_mlp = load_euler_csv_data_generic(mlp_file)

        if x_mlp is not None:
            dx = float(x_mlp[1] - x_mlp[0])
            entropy_physical = p_mlp / np.maximum(rho_mlp ** gamma, 1e-12)
            # 🟢 严格注入反射边界条件外推拓扑
            entropy_with_bc = apply_reflective_bc_scalar(entropy_physical, nghost=nghost)
            prob_1d = predict(entropy_with_bc, dx, model, device)
            is_troubled_physical = (prob_1d <= P_threshold)[1:Nx + 1]

            # 🛠️ 坏点统计打印
            total_points = len(x_mlp)
            num_troubled = np.sum(is_troubled_physical)
            percentage_troubled = (num_troubled / total_points) * 100
            print(f"   -> 网格 N = {Nx:3d} | 间断点个数: {num_troubled:3d} / {total_points:3d} | 占比: {percentage_troubled:6.2f}%")

            line1, = ax.plot(ref_sedov['x'], ref_sedov['rho'], color='black', linewidth=2.5, zorder=1)
            line2, = ax.plot(x_mlp, rho_mlp, color='red', linewidth=2.0, zorder=2)

            for i in range(len(x_mlp)):
                if is_troubled_physical[i]:
                    ax.axvline(x=x_mlp[i], color='fuchsia', linestyle='-', linewidth=0.9, alpha=0.8, zorder=3)

            # 只在第一个子图抓取句柄，用于全局纯净图例
            if idx == 0 and len(legend_handles) == 0:
                legend_handles = [line1, line2]
        else:
            ax.text(0.5, 0.5, f'Data Missing\nN = {Nx}', ha='center', va='center', fontsize=16)

        # 轴系约束与标签对齐
        ax.set_xlabel(f'X\n{sub_labels[0][idx]}Sedov blast (N = {Nx})', fontsize=30, labelpad=3)
        if idx == 0:
            ax.set_ylabel('Density', fontsize=30, labelpad=5)
            ax.set_yticks([0.0, 3.0, 6.0])
            ax.tick_params(axis='both', labelsize=28, direction='in', top=True, right=True, length=6, width=1.2)
        else:
            ax.set_yticks([])
            ax.tick_params(axis='x', labelsize=28, direction='in', top=True, right=True, length=6, width=1.2)
            ax.tick_params(axis='y', direction='in', left=True, right=True, length=6, width=1.2)
        ax.set_xlim(-2.0, 2.0)
        ax.set_xticks([-2.0, 0, 2.0])
        ax.set_ylim(0.0, 6.5)

    # ==========================================
    # ROW 1: Double Blast Wave Problem (输入特征：熵 + 反射边界条件)
    # ==========================================
    print("\n📌 [算例 2: Double Blast Wave 问题]")
    for idx, Nx in enumerate(nx_list):
        ax = axes[1, idx]
        mlp_file = f"DoubleBlastWaveinteraction/DoubleBlastWave_WENO5MLP_Dynamic_N{Nx}_T0.038.csv"
        x_mlp, rho_mlp, p_mlp = load_euler_csv_data_generic(mlp_file)

        if x_mlp is not None:
            dx = float(x_mlp[1] - x_mlp[0])
            entropy_physical = p_mlp / np.maximum(rho_mlp ** gamma, 1e-12)
            # 🟢 严格注入反射边界条件外推拓扑
            entropy_with_bc = apply_reflective_bc_scalar(entropy_physical, nghost=nghost)
            prob_1d = predict(entropy_with_bc, dx, model, device)
            is_troubled_physical = (prob_1d <= P_threshold)[1:Nx + 1]

            # 🛠️ 坏点统计打印
            total_points = len(x_mlp)
            num_troubled = np.sum(is_troubled_physical)
            percentage_troubled = (num_troubled / total_points) * 100
            print(f"   -> 网格 N = {Nx:3d} | 间断点个数: {num_troubled:3d} / {total_points:3d} | 占比: {percentage_troubled:6.2f}%")

            ax.plot(ref_double['x'], ref_double['rho'], color='black', linewidth=2.5, zorder=1)
            ax.plot(x_mlp, rho_mlp, color='red', linewidth=2.0, zorder=2)

            for i in range(len(x_mlp)):
                if is_troubled_physical[i]:
                    ax.axvline(x=x_mlp[i], color='fuchsia', linestyle='-', linewidth=0.5, alpha=0.8, zorder=3)
        else:
            ax.text(0.5, 3.2, f'Data Missing\nN = {Nx}', ha='center', va='center', fontsize=16, color='red')

        ax.set_xlabel(f'X\n{sub_labels[1][idx]}Double blast (N = {Nx})', fontsize=30, labelpad=3)
        if idx == 0:
            ax.set_ylabel('Density', fontsize=30, labelpad=5)
            ax.set_yticks([0.0, 3.0, 6.0])
            ax.tick_params(axis='both', labelsize=28, direction='in', top=True, right=True, length=6, width=1.2, pad=12)
        else:
            ax.set_yticks([])
            ax.tick_params(axis='x', labelsize=28, direction='in', top=True, right=True, length=6, width=1.2, pad=12)
            ax.tick_params(axis='y', direction='in', left=True, right=True, length=6, width=1.2)
        ax.set_xlim(0.0, 1.0)
        ax.set_xticks([0.0, 0.5, 1.0])
        ax.set_ylim(0.0, 6.5)

    # ==========================================
    # ROW 2: Shu-Osher Problem (输入特征：熵 + 独立流入/流出边界条件)
    # ==========================================
    print("\n📌 [算例 3: Shu-Osher 问题]")
    for idx, Nx in enumerate(nx_list):
        ax = axes[2, idx]
        mlp_file = f"Shu_OsherProblem/Shu_OsherProblem_WENO5MLP_N{Nx}_T1.80.csv"
        x_mlp, rho_mlp, p_mlp = load_euler_csv_data_generic(mlp_file)

        if x_mlp is not None:
            dx = float(x_mlp[1] - x_mlp[0])
            entropy_physical = p_mlp / np.maximum(rho_mlp ** gamma, 1e-12)
            # 🟢 严格注入 Shu-Osher 定制边界条件拓扑（左流入右流出）
            entropy_with_bc = apply_shu_osher_bc_scalar(entropy_physical, gamma=gamma, nghost=nghost)
            prob_1d = predict(entropy_with_bc, dx, model, device)
            is_troubled_physical = (prob_1d <= P_threshold)[1:Nx + 1]

            # 🛠️ 坏点统计打印
            total_points = len(x_mlp)
            num_troubled = np.sum(is_troubled_physical)
            percentage_troubled = (num_troubled / total_points) * 100
            print(f"   -> 网格 N = {Nx:3d} | 间断点个数: {num_troubled:3d} / {total_points:3d} | 占比: {percentage_troubled:6.2f}%")

            ax.plot(ref_shu['x'], ref_shu['rho'], color='black', linewidth=2.5, zorder=1)
            ax.plot(x_mlp, rho_mlp, color='red', linewidth=2.0, zorder=2)

            for i in range(len(x_mlp)):
                if is_troubled_physical[i]:
                    ax.axvline(x=x_mlp[i], color='fuchsia', linestyle='-', linewidth=0.8, alpha=0.8, zorder=3)
        else:
            ax.text(0.0, 2.5, f'Data Missing\nN = {Nx}', ha='center', va='center', fontsize=16, color='red')

        ax.set_xlabel(f'X\n{sub_labels[2][idx]}Shu-Osher (N = {Nx})', fontsize=30, labelpad=3)
        if idx == 0:
            ax.set_ylabel('Density', fontsize=30, labelpad=5)
            ax.set_yticks([1.0, 3.0, 5.0])
            ax.tick_params(axis='y', labelsize=28, direction='in', left=True, right=True, length=6, width=1.2, pad=8)
            ax.tick_params(axis='x', labelsize=28, direction='in', top=True, right=True, length=6, width=1.2, pad=14)
        else:
            ax.set_yticks([])
            ax.tick_params(axis='x', labelsize=28, direction='in', top=True, right=True, length=6, width=1.2, pad=14)
            ax.tick_params(axis='y', direction='in', left=True, right=True, length=6, width=1.2)
        ax.set_xlim(-5.0, 5.0)
        ax.set_xticks([-5.0, 0, 5.0])
        ax.set_ylim(0.5, 5.0)

    print("\n=============================================================================")

    # ==========================================
    # 顶层整体排版与全局图例对齐
    # ==========================================
    plt.tight_layout(rect=[0.14, 0, 1, 1])
    fig.legend(
        handles=legend_handles,
        labels=['Reference', 'WENO5-H-MLP'],
        loc='center left',
        bbox_to_anchor=(0.005, 0.7),  # 居中垂直卡在大图最左侧外边缘
        ncol=1,  # 1列纵向垂直堆叠
        fontsize=20,
        handlelength=2.5,
        handletextpad=0.5,
        frameon=True,
        edgecolor='gray'
    )

    output_pdf = "1D_Euler_Another3_MLP.pdf"
    plt.savefig(output_pdf, dpi=300)
    print(f"\n📊 完美修正边界条件与图例的 3x3 学术矢量图已成功导出至: {output_pdf}")
    plt.show()


if __name__ == "__main__":
    main()